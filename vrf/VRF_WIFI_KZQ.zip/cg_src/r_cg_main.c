/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2013, 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_main.c
* Version      : Code Generator for RL78/L13 V1.03.01.03 [30 Jan 2015]
* Device(s)    : R5F10WMG
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 2018/6/4
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
#define _EXTERN_MAIN_H_
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_cgc.h"
#include "r_cg_port.h"
#include "r_cg_tau.h"
#include "r_cg_pclbuz.h"
#include "r_cg_wdt.h"
#include "r_cg_sau.h"
#include "r_cg_lcd.h"
#include "r_cg_intp.h"
/* Start user code for include. Do not edit comment generated here */
#include "Common.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

void R_MAIN_UserInit(void);
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
    R_MAIN_UserInit();
    /* Start user code. Do not edit comment generated here */
	while (1U)
	{
		WDT_Process();
		System_ScanProcess();
	}
	/* End user code. Do not edit comment generated here */
}
/***********************************************************************************************************************
* Function Name: R_MAIN_UserInit
* Description  : This function adds user code before implementing main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_UserInit(void)
{
	uint8_t temp;
    /* Start user code. Do not edit comment generated here */
	
	R_LCD_Voltage_On();
	R_LCD_Start();
	
	R_UART0_Start();				// UART0ʹ��(WIFI�շ�)    
	R_UART1_Start();				// UART1ʹ��(VRFͨѶ�շ�)   
	
	R_TAU0_Channel0_Start();		// LED�� PWM server��ʱ������ʹ��   
	Led_RegInit();  				// LED��  PWM slave��ʱ������ʹ��  
	
	R_TAU0_Channel2_Start();  	// 1ms��ʱ��ʹ��   
	R_INTC0_Start();				// ��������ⲿ����    
	R_WDT_Restart();
    EI();
	
	System_RamInit();				// ������ʼ��     
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/**************************************************************/
/**
*	@brief	ϵͳɨ�躯��    
*/
/**************************************************************/
void System_ScanProcess(void)
{

	Wifi_RecDatDeal();					// wifi����    
	Wifi_Send();						// wifi����    
	System_EepromWriteProcess();		// eeprom����д��    

	Vrf_InitCommunication();			// VRF����ͨѶ   
	Vrf_OutdoorInitCom();				// VRF���������ͨѶ  
	Vrf_DataSend();					// ���ݷ���   
	Vrf_RecDataDeal();					// VRF���ݽ���   

	AutoAddr_Process();				// �Զ���ַ���ݷ���   
	ManualAddr_Process();				// �ֶ���ַ��������   
	// 1msɨ�躯�����ô�     
	if (G_SystemScanFlag & SYSTEM_SCAN_FLAG_1MS)
	{
		G_SystemScanFlag &= ~SYSTEM_SCAN_FLAG_1MS;
		Ir_DataDeal();					// �������������ݽ���    
		Vrf_SendList();				// VRFָ���ȡ   
		Vrf_Count1msDeal();			// VRF1ms��ؼ�ʱ     
		Pro_EnterOrExitSet();			// ��Ŀ���ù��ܳ�ʼ�����л�ȡ       
	}
	// 10msɨ�躯�����ô�     
	if (G_SystemScanFlag & SYSTEM_SCAN_FLAG_10MS)
	{
		G_SystemScanFlag &= ~SYSTEM_SCAN_FLAG_10MS;
		
		Key_DealProgram();			// ��������      
		//Key_ConfWrite();				// ������������    
		Led_Process();				// LED��ʾ    
		Lcd_Process();				// LCD��ʾ     
		Lcd_FlashCount();			// LCD��˸��ʱ   
		BL_Count();				// ���������ʱ    
		Wifi_10msRelatedCount();	// wifi�¶� ��ʱ����    
		Vrf_TempSendDeal();			// Vrf�¶���ʱ����   
		Key_PressCount();			// ��������5s�ڲ�����81״̬����  
		Wifi_NetKeyCount();		
		Pro_InitStepCount();		// ��Ŀ��ʼ�����ͼ�ʱ   
		TestMode_Process();		// ����ģʽ   
		AutoAddr_FitSend();		// �Զ���ַ�趨ʱ�����   
		ManualAddr_FitSend();
	}
	
	// 500msɨ�躯�����ô�     
	if (G_SystemScanFlag & SYSTEM_SCAN_FLAG_500MS)
	{
		G_SystemScanFlag &= ~SYSTEM_SCAN_FLAG_500MS;
		WindDir_AutoSwingDeal();			// ����ڶ�    
		SystemSet_AutoExitCount();			// �趨�Զ��˳���ʱ   
		Timer_Process();					// ��ʱ����   
		Wifi_1sRelatedCount();					// wifi ��ؼ���   
		Vrf_RegularCommunication();			//VRF����ͨѶ   
		Vrf_OutdoorRegCom();				// ���������ͨѶ    
		Vrf_ScRegularCom();					// serverģʽ��5s����ͨѶ   
		Nanoe_AbnormalCount();				// nanoe�쳣����   
		Wifi_FuncCheckDeal();				// ��WIFI���    
		CentralCtl_FlashCount();				// ������˸��ʱ           
	}
}

void WDT_Process(void)
{
	if (G_WdtReset)
	{
		
	}
	else
		R_WDT_Restart();
}


/**************************************************************/
/**
*	@brief	ϵͳɨ���ʱ    
*/
/**************************************************************/
void System_ScanCount(void)
{
	static uint8_t count_1ms_temp = 0;
	static uint8_t count_10ms_temp = 0;

	G_SystemScanFlag |= SYSTEM_SCAN_FLAG_1MS;
	count_1ms_temp++;
	if (count_1ms_temp >= 10)
	{
		count_1ms_temp = 0;
		G_SystemScanFlag |= SYSTEM_SCAN_FLAG_10MS;
		count_10ms_temp++;
		if (count_10ms_temp >= 50)
		{
			count_10ms_temp = 0;
			G_SystemScanFlag |= SYSTEM_SCAN_FLAG_500MS;
		}
	}
}

/* End user code. Do not edit comment generated here */
