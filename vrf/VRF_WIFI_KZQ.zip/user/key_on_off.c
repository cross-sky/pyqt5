#include "Common.h"

/**************************************************************/
/**
*	@brief	���ػ�����������   
*/
/**************************************************************/
void Key_OnOffDeal(void)
{
	
	switch (GuiTaskMode)
	{
		case NORMAL_TAST:				/* ���ڻ�����ģʽ   */
			if (G_KeyDownType == KEY_TYPE_SHORT)
			{
				if (G_SendFlag & SEND_FLAG_INIT)		// ���ڻ�   
					return;
				
				G_KeyCount = KEY_COUNT_5S;

				// ���п��ƽ�ֹ��         
				if (G_CentralCtrBanFlag & POWER_SW_BAN)
				{
					G_CtlBanSwAction = CTL_BAN_SW_ACT;
					G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
					return;
				}
				
				if (G_SystemStatus)
				{
					SystemStatus_OffDeal();
					Buzzer_LongSoundEnable();
				}
				else
				{
					SystemStatus_OnDeal();
					Buzzer_KeySoundEnable();

					if (G_SystemStatus == SYSTEM_STATUS_ON)
					{
						// ��������nanoe���ͷ�ģʽҪ��������   
						if ((G_SystemMode==SYSTEM_MODE_WIND)&&(G_NanoeUnion==1))
						{
							if (G_NanoeFunc==1)
							{
								G_NanoeStatus = 1;
								Vrf_CmdJoinQueue(CMD_TYPE_5C, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
							}
							else
								G_NanoeStatus = 0;
						}
					}
				}
			}
			break;
		case OUTDOOR_NORMAL_TAST:			/*	���������  */
			if (G_KeyDownType == KEY_TYPE_SHORT)
			{
				if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT)		// ���ڻ�   
					return;
					
				G_8BKeyValue = KEY_8B_ON_OFF;
				Vrf_CmdJoinQueue(CMD_TYPE_8B_KEY,CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				Vrf_CmdJoinQueue(CMD_TYPE_19_KEY,CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				Buzzer_LongSoundEnable();
				break;
			}
	}
}


