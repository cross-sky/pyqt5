#define _EXTERN_EEPROM_H_

#include "Common.h"

void System_EepromDataInit(void)
{
	uint8_t i;
	eeprom_Read_String(0xa0,eeprom_init_enable_dress,1,&G_SystemDataInit);
	if (G_SystemDataInit>1)
		G_SystemDataInit = 0;
	if (G_SystemDataInit == 0)
	{
		G_WifiState = 0;
		wifi_match_enable_write = 1;
		G_RemoRole = REMO_ROLE_MASTER;
		remo_role_write = 1;
		G_ServerRole = SERVER_ROLE_OUTDOOR;
		server_role_write = 1;
		G_BLTimeLevel = 0;
		bl_time_level_write = 1;
		G_BL.level = BL_LIGHT_LEVEL_MID;
		bl_level_write = 1;
		G_Led.level =  LED_LIGHT_LEVEL5;
		led_level_write = 1;
		G_BzMode = BZ_ENABLE;
		bz_mode_write = 1;
		// �쳣������Ϊֱ�Ӷ�ȡ27ָ���ȡ            ZHQ-200415   
		#if 0			
		G_ErrorIndex = 0x00;
		error_code_write = 1;
		#endif
		while (1)
		{
			System_EepromWriteProcess();
			R_WDT_Restart();
			if (G_EepromWriteFlag1==0x00)
			{
				G_SystemDataInit = 1;
				eeprom_Write_String(0xa0,eeprom_init_enable_dress,1,&G_SystemDataInit);
				break;
			}
		}
	}
	System_EepromReadProcess();
}

/**************************************************************/
/**
*	@brief	eeprom����д�빦��       
*/
/**************************************************************/
void System_EepromWriteProcess(void)
{
	if (G_TestMode == 1)
		return;
	
	if (eeprom_init_enable_write)
	{
		eeprom_init_enable_write = 0;
		eeprom_Write_String(0xa0,eeprom_init_enable_dress,1,&G_SystemDataInit);
	}
	else if (wifi_match_enable_write)
	{
		wifi_match_enable_write = 0;
		eeprom_Write_String(0xa0,wifi_match_enable_dress,1,&G_WifiState);
	}
	else if (remo_role_write)
	{
		remo_role_write = 0;
		eeprom_Write_String(0xa0,remo_role_dress,1,&G_RemoRole);
	}
	else if (server_role_write)
	{
		server_role_write = 0;
		eeprom_Write_String(0xa0,server_role_dress,1,&G_ServerRole);
	}
	else if (bl_time_level_write)
	{
		bl_time_level_write = 0;
		eeprom_Write_String(0xa0,bl_time_dress,1,&G_BLTimeLevel);
	}
	else if (bl_level_write)
	{
		bl_level_write = 0;
		eeprom_Write_String(0xa0,bl_level_dress,1,&G_BL.level);
	}
	else if (led_level_write)
	{
		led_level_write = 0;
		eeprom_Write_String(0xa0,led_level_dress,1,&G_Led.level);
	}
	else if (bz_mode_write)
	{
		bz_mode_write = 0;
		eeprom_Write_String(0xa0,bz_mode_dresss,1,&G_BzMode);
	}
	// �쳣������Ϊֱ�Ӷ�ȡ27ָ���ȡ            ZHQ-200415   
	#if 0
	else if (error_code_write)
	{
		error_code_write = 0;
		eeprom_Write_String(0xa0,error_code_dress,4,G_ErrorIndex);
	}
	#endif
}

/**************************************************************/
/**
*	@brief	eeprom�����ȡ����       
*/
/**************************************************************/
void System_EepromReadProcess(void)
{
	eeprom_Read_String(0xa0,wifi_match_enable_dress,1,&G_WifiState);
	if (G_WifiState>1)
		G_WifiState = 1;
	
	eeprom_Read_String(0xa0,remo_role_dress,1,&G_RemoRole);
	if (G_RemoRole>1)
		G_RemoRole = 1;
	if (G_RemoRole == REMO_ROLE_MASTER)
		G_RemoAdd.add16 = 0x0040;
	else
		G_RemoAdd.add16 = 0x0041;
	
	eeprom_Read_String(0xa0,server_role_dress,1,&G_ServerRole);
	if (G_ServerRole>1)
		G_ServerRole = SERVER_ROLE_INDOOR;

	eeprom_Read_String(0xa0,bl_time_dress,1,&G_BLTimeLevel);
	if (G_BLTimeLevel >= 4)
	{
		G_BLTimeLevel = 4;
		G_BL.lightTime = 0;
	}
	else
	{
		G_BL.lightTime = (G_BLTimeLevel+1) * 5;
	}

	eeprom_Read_String(0xa0,bl_level_dress,1,&G_BL.level);
	if (G_BL.level > BL_LIGHT_LEVEL_HIGH)
		G_BL.level = BL_LIGHT_LEVEL_MID;

	eeprom_Read_String(0xa0,led_level_dress,1,&G_Led.level);
	if (G_Led.level > LED_LIGHT_LEVEL10)
		G_Led.level = LED_LIGHT_LEVEL5;

	eeprom_Read_String(0xa0,bz_mode_dresss,1,&G_BzMode);
	if (G_BzMode > BZ_ENABLE)
		G_BzMode = BZ_ENABLE;

	// �쳣������Ϊֱ�Ӷ�ȡ27ָ���ȡ            ZHQ-200415   
	//eeprom_Read_String(0xa0,error_code_dress,4,G_ErrorIndex);
}



