#define _EXTERN_WIFI_H_

#include "Common.h"

const uint8_t slink_error_table[]={
/*  ������쳣  */
0x59,0x5D,0x5E,0x5F,0x64,0x66,0x67,0x68,0x71,0x70,
0x77,0x78,0x79,0x7A,0x81,0x82,0x83,0x86,0x89,0xF0,
0x9F,0x85,0x99,0x9B,0x7F,0xCA,0xD2,0xE2,0xE3,0xF4,
0xE5,0xE4,0xE2,0xF6,0xFD,
/*  ���ڻ��쳣  */
0x43,0x44,0x48,0x52,0x61,0x62,0x63,0x6A,0x6B,0x7D,
0xC2,0xC3,0xC7,0xC8,0xC9,0xE1,0xE9,0xEA,0xEB,0xEC,
0xFF,
};

const uint8_t wifi_error_table[]={
/*  ������쳣  */
0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,
0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,
0x40,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,
0x50,0x51,0x52,0x53,0x54,
/*  ���ڻ��쳣  */
0x60,0x61,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,
0x70,0x71,0x72,0x73,0x74,0x75,0x76,0x77,0x78,0x79,
0x80,
};


/**************************************************************/
/**
*	@brief	wifi UART����
*/
/**************************************************************/
void Wifi_Send(void)
{	
	if (G_TestMode)
		return;
	if (G_WifiSendEnable)
		return;
	if (G_SendFlag & SEND_FLAG_INIT)
	{
		G_WifiSendEnable = 0;
		return;
	}
	
	if (!Wifi_GetSendDat())
		return;
	R_UART0_Send(Uart0SendBuffer,RX0_DAT_LENGTH);
	
}

/**************************************************************/
/**
*	@brief	wifi��ȡ������Ϣ  
*/
/**************************************************************/
uint8_t Wifi_GetSendDat(void)
{
	uint8_t i;
	uint8_t temp;
	uint16_t temp_16bit;
	
	if (G_WifiOTA == 1)
		return 0;

	if  (G_Rx0SendFlag==0)
		return 0;
	
	Uart0SendBuffer[0] = 0x70;
	Uart0SendBuffer[1] = 0x20;

	temp = 0;
	if (G_SystemStatus == 1)
		temp |= BIT2;
	switch (G_SystemMode)
	{
		case SYSTEM_MODE_AUTO:
			break;
		case SYSTEM_MODE_WARM:
			temp |= (uint8_t)(4<<4);
			break;
		case SYSTEM_MODE_COLD:
			temp |= (uint8_t)(3<<4);
			break;
		case SYSTEM_MODE_WET:
			temp |= (uint8_t)(2<<4);
			break;
		case SYSTEM_MODE_WIND:
			temp |= (uint8_t)(6<<4);
			break;
	}
	Uart0SendBuffer[2] = temp;
	
	temp = G_SystemTemp[G_SystemMode] * 2;
	Uart0SendBuffer[3] = temp;

	Uart0SendBuffer[4] = 0;

	temp = 0;
	if (G_SpecWindSpeed!=WIND_SPEED_SPEC_NORMAL)
		temp |= (uint8_t)(0x03<<4);
	else
	{
		switch (G_WindSpeed[G_SystemMode])
		{
			case WIND_SPEED_AUTO:
				temp |= (uint8_t)(0x0A<<4);
				break;
			case WIND_SPEED_LEVEL1:
				temp |= (uint8_t)(0x03<<4);
				break;
			case WIND_SPEED_LEVEL2:
				temp |= (uint8_t)(0x04<<4);
				break;
			case WIND_SPEED_LEVEL3:
				temp |= (uint8_t)(0x05<<4);
				break;
			case WIND_SPEED_LEVEL4:
				temp |= (uint8_t)(0x06<<4);
				break;
			case WIND_SPEED_LEVEL5:
				temp |= (uint8_t)(0x07<<4);
				break;
		}
	}
	Uart0SendBuffer[5] = temp;

	temp = 0;
	switch (G_WindDirUd[G_SystemMode])
	{
		case WIND_DIR_UD_AUTO:
			temp |= (uint8_t)(0x0f<<4);
			break;
		case WIND_DIR_UD_LEVEL1:
			temp |= (uint8_t)(0x01<<4);
			break;
		case WIND_DIR_UD_LEVEL2:
			temp |= (uint8_t)(0x02<<4);
			break;
		case WIND_DIR_UD_LEVEL3:
			temp |= (uint8_t)(0x03<<4);
			break;
		case WIND_DIR_UD_LEVEL4:
			temp |= (uint8_t)(0x04<<4);
			break;
		case WIND_DIR_UD_LEVEL5:
			temp |= (uint8_t)(0x05<<4);
			break;
	}
	switch (G_WindDirLr[G_SystemMode])
	{
		case WIND_DIR_LR_AUTO:
			temp |= 0x0D;
			break;
		case WIND_DIR_LR_LEVEL1:
			temp |= 0x09;
			break;
		case WIND_DIR_LR_LEVEL2:
			temp |= 0x0a;
			break;
		case WIND_DIR_LR_LEVEL3:
			temp |= 0x06;
			break;
		case WIND_DIR_LR_LEVEL4:
			temp |= 0x0b;
			break;
		case WIND_DIR_LR_LEVEL5:
			temp |= 0x0c;
			break;
	}
	Uart0SendBuffer[6] = temp;

	temp = 0;
	if (G_SpecWindSpeed == WIND_SPEED_SPEC_MUTE)
		temp |= BIT2;
	else if (G_SpecWindSpeed == WIND_SPEED_SPEC_STRONG)
		temp |= BIT1;

	if (G_EconaviFunc&&G_EconaviStatus)
		temp |= BIT4;
	
	if (G_NanoeFunc&&G_NanoeStatus)
		temp |=(BIT6+BIT7);
	

	Uart0SendBuffer[7] = temp;
	Uart0SendBuffer[8] = 0;
	
	if (G_Rx0SendFlag & RX0_SEND_FLAG_WIFI)
	{
		G_Rx0SendFlag &= ~RX0_SEND_FLAG_WIFI;
		Uart0SendBuffer[9] = 0x1F;
		
		temp = G_WifiState;	
		temp |= (G_WifiConnectNetState<<1);
		temp |= (G_WifiResetState << 3);
		Uart0SendBuffer[10] = temp;
		

		temp = 0;
		temp |= (G_WifiOTAState<<2);
		temp |= (G_WifiLANState<<5);
		temp |= (G_WifiCheckState<<6);
		Uart0SendBuffer[11] = temp;
		
	}
	else if (G_Rx0SendFlag & RX0_SEND_FLAG_NORMAL)
	{
		G_Rx0SendFlag &= ~RX0_SEND_FLAG_NORMAL;
		Uart0SendBuffer[9] = 0x30;

		temp = 0;
		if (G_FreshAir)
			temp |= BIT1;
		Uart0SendBuffer[10] = temp;
		
		Uart0SendBuffer[11] = 0;
	}

	
	Uart0SendBuffer[13] = 0x32;
	
	Uart0SendBuffer[14] = (G_Defrost<<1) + (G_FilterRstSign); // ��˪�������ź�             
	Uart0SendBuffer[15] = 0;


	if (G_ErrorCode)
	{
		for (i=0;i<ERROR_LENGTH;i++)
		{
			if (G_ErrorCode == slink_error_table[i])
			{
				Uart0SendBuffer[16] = 0x30;
				Uart0SendBuffer[17] = wifi_error_table[i];
				Uart0SendBuffer[12] = BIT1;
				break;
			}
		}
		if ((i==ERROR_LENGTH)&&(G_ErrorCode!=slink_error_table[ERROR_LENGTH-1]))
		{
			Uart0SendBuffer[16] = 0x02;
			Uart0SendBuffer[17] = 0x00;
			Uart0SendBuffer[12] = 0;
		}
		
	}
	else
	{
		Uart0SendBuffer[16] = 0x02;
		Uart0SendBuffer[17] = 0x00;
		Uart0SendBuffer[12] = 0;
	}
	
	Uart0SendBuffer[18] = 0x00;
	Uart0SendBuffer[19] = 0x00;
	Uart0SendBuffer[20] = 0x00;
	
	Uart0SendBuffer[21] = G_SucTempe;					// �����¶�    
	
	Uart0SendBuffer[22] = 0x00;
	Uart0SendBuffer[23] = 0x00;
	
	Uart0SendBuffer[24] = G_TupingTempe1;				// ����¶�1   
	Uart0SendBuffer[25] = G_TupingTempe2;				// ����¶�2    
	
	Uart0SendBuffer[26] = 0x00;
	Uart0SendBuffer[27] = 0x00;
	Uart0SendBuffer[28] = 0x00;
	Uart0SendBuffer[29] = 0x00;
	Uart0SendBuffer[30] = 0x00;
	Uart0SendBuffer[31] = 0x80;
	Uart0SendBuffer[32] = eeprom_no_l;
	Uart0SendBuffer[33] = eeprom_no_h;


	Uart0SendBuffer[34] = 0;
	for (i=0; i<34; i++)
		Uart0SendBuffer[34] += Uart0SendBuffer[i];
	Uart0SendBuffer[34] = ~Uart0SendBuffer[34];
	Uart0SendBuffer[34] += 1;

	//G_Rx0SendFlag = 0;
	G_WifiSendEnable = 1;		
	Uart0SendBufferCount = 0;

	return 1;
}


/*************************************************************************/
/*	һ��connectivityЭ�飬���ձ�����ź�ʱ    */ 
/*	(1)cc=0x70��0xf0    
*	(2)bc=0x20			 
*/
/*************************************************************************/
void Wifi_DatParse(void)
{
	uint8_t dat_temp;
	static uint8_t rx0_check_data[2]={0,0};
	static uint8_t rx0_nuber = 0;
	static uint8_t rx0_cnt = 0;

	if (G_WifiRecFinishFlag)
		return;
	
	if (!GetUartReceiveDat(&dat_temp,&G_Rx0RecDat))
		return;

	

	rx0_check_data[1] = rx0_check_data[0];
    	rx0_check_data[0] = dat_temp;

	if (G_WifiRecStartFlag == 0)
	{
		if (((rx0_check_data[1]==0xF0)||(rx0_check_data[1]==0x70)) && (rx0_check_data[0]==0x0A))
		{
			G_WifiRecStartFlag = 1;
			
			G_WifiRecDat[0] = rx0_check_data[1];
			G_WifiRecDat[1] = rx0_check_data[0];
			rx0_nuber = 2;
			rx0_cnt = 13;
		}
	}
	else 
	{
		G_WifiRecDat[rx0_nuber] = dat_temp;
		rx0_nuber++;
		if (rx0_nuber >= rx0_cnt)
		{
			G_WifiRecFinishFlag = 1;
		}
	}
}

/**************************************************************/
/**
*	@brief	wifi���ݽ�����ɴ���     
*/
/**************************************************************/
void Wifi_RecDatDeal(void)
{
	uint8_t sum,i;
	uint8_t temp1,temp2,temp3;

	static uint8_t wifi_dat_temp[2] = {0,0};
	
	Wifi_DatParse();

	if (G_WifiRecFinishFlag == 0)
		return;

	if (G_Rx0SendFlag)
		return;
	
	G_WifiRecFinishFlag = 0;
	G_WifiRecStartFlag = 0;

	sum = 0;
	for(i=0; i<12; i++)
	{
		sum += G_WifiRecDat[i];
	}
	sum = ~sum;
	sum += 1;
	
	if ((G_WifiRecDat[12]==sum)&&(G_Rx0SendFlag==0))
	{

		G_WifiPass = 1;
		G_WifiErrCheCount = 0;
		G_WifiErrFlag = 0;

		G_WifiConnctNetCount = 0;
		G_WifiConnctNetError = 0;

		// wifi�Ѿ�����     
		G_WifiFunc = 1;
		G_WifiFuncCount = 0;
		
		if (G_WifiRecDat[0]==0xF0)
		{
			if ((G_WifiConnectNet == 2) &&(G_NetStatus !=4) && G_WifiState)
			{
				
				/* ��ת */ 
				temp1 = (G_WifiRecDat[2]&BIT2)>>2;
				if (temp1 != G_SystemStatus)
				{
					G_KeyCount = KEY_COUNT_5S;
					if (temp1==SYSTEM_STATUS_OFF)
					{
						SystemStatus_OffDeal();
						//Buzzer_LongSoundEnable();
					}
					else
					{
						SystemStatus_OnDeal();
						//Buzzer_KeySoundEnable();
					}
				}


				/* ��תģʽ */
				temp1 = (G_WifiRecDat[2]>>4)&0x0f;
				Wifi_SystemModeRec(temp1);


				temp1 = G_WifiRecDat[3];					// �¶�    
				/* �¶� */
				if (G_TempSendCount >= TEMP_SEND_COUNT)
					Wifi_TempeRec(temp1);


				
				/* ���� */ 
				temp1 = (G_WifiRecDat[7] & BIT2)>>2;
				temp2 = (G_WifiRecDat[7] & BIT1)>>1;
				temp3 = (G_WifiRecDat[5]>>4)&0x0f;
				Wifi_WindSpeedRec(temp1,temp2,temp3);
				
				
			
				
				/* ���º����ҷ��� */   
				temp1 = (G_WifiRecDat[6]>>4)&0x0f;
				temp2 = G_WifiRecDat[6] & 0x0f;
				Wifi_WindBoardRec(temp1,temp2);

				// eco
				temp2= (G_WifiRecDat[7]&(BIT4+BIT5))>>4;
				if ((temp2==1)&&G_EconaviFunc)
					temp1 = 1;
				else
					temp1 = 0;
				if (temp1!=G_EconaviStatus)
				{
					G_EconaviStatus = temp1;
					Vrf_CmdJoinQueue(CMD_TYPE_58, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
					//Buzzer_KeySoundEnable();
					G_KeyCount = KEY_COUNT_5S;
				}

				//nanoe  
				if ((G_WifiRecDat[7]&(BIT7+BIT6))&&G_NanoeFunc)
					temp1 = 1;
				else 
					temp1 = 0;
				if (temp1 != G_NanoeStatus)
				{
					G_NanoeStatus = temp1;
					Vrf_CmdJoinQueue(CMD_TYPE_5C, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
					//Buzzer_KeySoundEnable();
					G_KeyCount = KEY_COUNT_5S;
				}
				
			}

			if (G_WifiRecDat[9]==0x30)
			{
				if ((G_WifiConnectNet == 2) && (G_NetStatus != 4) && (G_WifiState))
				{
					// ����  
					temp1 = (G_WifiRecDat[10] & BIT1) ? 1 : 0;
					if (G_FreshAirFunc == 0)
						temp1 = 0;
					if (temp1 != G_FreshAir)
					{
						G_FreshAir = temp1;
						Vrf_CmdJoinQueue(CMD_TYPE_52, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						//Buzzer_KeySoundEnable();
						G_KeyCount = KEY_COUNT_5S;
					}
				}
			}
			else if (G_WifiRecDat[9] == 0x1F)
			{

				// WIFI ����      
				G_WifiState = G_WifiRecDat[10] & BIT0;
					
				// WIFI ����    
				G_WifiConnectNet = (G_WifiRecDat[10] & (BIT1+BIT2))>>1;

				switch (G_WifiConnectNet)
				{
					case 0:
						G_WifiConnectNetState = CONNECT_NET_OFF;
						break;
					case 1:
						G_WifiConnectNetState = CONNECT_NET_WAIT;
						break;
					case 2:
					case 3:
						G_WifiConnectNetState = CONNECT_NET_OFF;
						break;
					default:
						G_WifiConnectNetState = CONNECT_NET_OFF;
						break;
				}

				// WIFI ��λ   
				G_WifiReset = (G_WifiRecDat[10] & (BIT3+BIT4))>>3;
				if (G_WifiConnectNet == 2)
				{
					switch (G_WifiReset)
					{
						case 0:
							G_WifiResetState = 0;
							break;
						case 1:
							G_WifiResetState = 2;
							break;
						case 2:
							G_WifiResetState = 0;
							break;
						case 3:
							break;
					}
				}
				if ((G_NetStatus==0) && (G_WifiReset==0))
				{
					G_WifiResetState = 0;
				}

				// ��������״̬  
				G_NetStatus = (G_WifiRecDat[10] & (BIT7+BIT6+BIT5))>>5;
				if (G_NetStatus==4)
				{
					if (ConnectAbCountStart==0)
					{
						G_WifiLANState = 1;
						ConnectAbCountStart = 1;
						G_WifiConnectAbCount = WIFI_CONNECT_AB_COUNT;
					}
					else
						G_WifiLANState = 0;
				}
				else
				{
					G_WifiLANState = 0;
					ConnectAbCountStart = 0;
				}

				// wifiǿ��   
				G_WifiSign = G_WifiRecDat[11] & (BIT0+BIT1);

				// wifi APP����   
				G_WifiOTA = (G_WifiRecDat[11] & (BIT2+BIT3+BIT4)) >> 2;
				switch (G_WifiOTA)
				{
					case 0:
						G_WifiOTAState = 0;
						break;
					case 1:
						G_WifiOTAState = 1;
						break;
					case 2:
						G_WifiOTAState = 1;
						break;
					case 3:
						G_WifiOTAState = 0;
						break;
					case 4:
						G_WifiOTAState = 0;
						break;
				}

				G_WifiCheck = (G_WifiRecDat[11] & (BIT6+BIT7))>>6;
				switch(G_WifiCheck)
				{
					case 0:
						G_WifiCheckState = 0;
						break;
					case 1:
						G_WifiCheckState = 2;
						G_WifiCheckResult = WIFI_IS_CHECKING;
						break;
					case 2:
						G_WifiCheckState = 0;
						G_WifiCheckResult = WIFI_CHECK_FINISH;
						break;
					case 3:
						G_WifiCheckState = 0;
						G_WifiCheckResult = WIFI_CHECK_FAIL;
						break;
				}
					
				temp1 = G_WifiRecDat[10];
				temp2 = G_WifiRecDat[11];
				if ((temp1 != wifi_dat_temp[0])||(temp2 != wifi_dat_temp[1]))
				{
					wifi_dat_temp[0] = temp1;
					wifi_dat_temp[1] = temp2;
				}
				if (G_WifiOTA != 1)
				{
					G_Rx0SendFlag |= RX0_SEND_FLAG_WIFI;
				}
			}
			
		}
		else if (G_WifiRecDat[0]==0x70)
		{
			if (G_WifiRecDat[9]==0x1F)
			{
				if (G_WifiOTA != 1)
				{
					G_Rx0SendFlag |= RX0_SEND_FLAG_WIFI;
				}
			}
			else if (G_WifiRecDat[9] == 0x30)
			{
				if (G_WifiOTA != 1)
				{
					G_Rx0SendFlag |= RX0_SEND_FLAG_NORMAL;
				}
			}
		}
	}
	
}


/********************************************************************************/
/*
*	@brief ����connectivity�ķ���   
*/
/********************************************************************************/     
void Wifi_WindSpeedRec(uint8_t mute_dat, uint8_t strong_dat, uint8_t wind_dat)
{
	uint8_t i;
	/* ���� */

	if (mute_dat)		// ����: ������־λ�ͷ����Զ�    
	{
		i = WIND_SPEED_MUTE; 
	}
	else if (strong_dat)   
	{
		i = WIND_SPEED_STRONG; 
	}
	else
	{
		switch (wind_dat)
		{
			case 0x0A:	i=WIND_SPEED_AUTO;  break;
			case 3: 	i=WIND_SPEED_LEVEL1;break;
			case 4: 	i=WIND_SPEED_LEVEL2;break;
			case 5: 	i=WIND_SPEED_LEVEL3;break;
			case 6: 	i=WIND_SPEED_LEVEL4;break;
			case 7: 	i=WIND_SPEED_LEVEL5;break;
		}
	}
	if ((i==WIND_SPEED_MUTE)&&(G_SpecWindSpeed!=WIND_SPEED_SPEC_MUTE))
	{
		G_SpecWindSpeed = WIND_SPEED_SPEC_MUTE;
		G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
		Vrf_CmdJoinQueue(CMD_TYPE_5F,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		//Buzzer_KeySoundEnable();
		G_KeyCount = KEY_COUNT_5S;
	}
	else if ((i==WIND_SPEED_STRONG)&&(G_SpecWindSpeed!=WIND_SPEED_SPEC_STRONG))
	{
		G_SpecWindSpeed = WIND_SPEED_SPEC_STRONG;
		G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
		Vrf_CmdJoinQueue(CMD_TYPE_5F,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		//Buzzer_KeySoundEnable();
		G_KeyCount = KEY_COUNT_5S;
	}
	else if (i<WIND_SPEED_MUTE)
	{
		
		if (i!=G_WindSpeed[G_SystemMode])
		{
			
			G_WindSpeed[G_SystemMode] = i;
			Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			if (G_SpecWindSpeed==WIND_SPEED_SPEC_MUTE)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			else if (G_SpecWindSpeed==WIND_SPEED_SPEC_STRONG)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			//Buzzer_KeySoundEnable();
			G_KeyCount = KEY_COUNT_5S;
		}
		else
		{
			if (G_SpecWindSpeed==WIND_SPEED_SPEC_MUTE)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				//Buzzer_KeySoundEnable();
				G_KeyCount = KEY_COUNT_5S;
			}
			else if (G_SpecWindSpeed==WIND_SPEED_SPEC_STRONG)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				//Buzzer_KeySoundEnable();
				G_KeyCount = KEY_COUNT_5S;
			}
			
		}
	}
	
}


/********************************************************************************/
/*
*	@brief ����G_Mode��connectivity������ģʽ    
*/
/********************************************************************************/
void Wifi_SystemModeRec(uint8_t dat)
{
	uint8_t i;
	/* ��תģʽ */
	i = G_SystemMode;

	// ȥ��ң���������������������������
	//if (((G_RemoRole == REMO_ROLE_MASTER) && (G_PrioIndoor == PRIO_INDOOR_ON)) || (G_ModeFit == MODE_FIT_NONE))
	if ((G_PrioIndoor == PRIO_INDOOR_ON) || (G_ModeFit == MODE_FIT_NONE))
	{
		switch (dat)
		{
			case 0x0: 
				if (G_AllowMode & ALLOW_AUTO)
					i=SYSTEM_MODE_AUTO;
				break;
			case 0x2: 
				if (G_AllowMode & ALLOW_WET)
					i=SYSTEM_MODE_WET; 
				break;
			case 0x3: 
				if (G_AllowMode & ALLOW_COLD)
					i=SYSTEM_MODE_COLD; 
				break;
			case 0x4:
				if (G_AllowMode & ALLOW_WARM)
					i=SYSTEM_MODE_WARM; 
				break;
			case 0x6: 
				if (G_AllowMode & ALLOW_WIND)
					i=SYSTEM_MODE_WIND;
				break;
		}
	}
	else
	{
		switch (dat)
		{
			case 0x0: 
				if (G_AllowMode & ALLOW_AUTO)
					i=SYSTEM_MODE_AUTO;
				break;
			case 0x2: 
				if ((G_AllowMode & ALLOW_WET) && (G_ModeFit == MODE_FIT_COLD_PRIO))
					i=SYSTEM_MODE_WET; 
				break;
			case 0x3: 
				if ((G_AllowMode & ALLOW_COLD) && (G_ModeFit == MODE_FIT_COLD_PRIO))
					i=SYSTEM_MODE_COLD; 
				break;
			case 0x4:
				if ((G_AllowMode & ALLOW_WARM) && (G_ModeFit == MODE_FIT_WARM_PRIO))
					i=SYSTEM_MODE_WARM; 
				break;
			case 0x6: 
				if (G_AllowMode & ALLOW_WIND)
					i=SYSTEM_MODE_WIND;
				break;
		}
	}
	if (i!=G_SystemMode)
	{
		G_SystemMode = i;
		if ((G_SystemMode==SYSTEM_MODE_WIND)&&(G_NanoeUnion==1))
		{
			if (G_NanoeStatus == 0)
			{
				G_NanoeStatus = 1;
				Vrf_CmdJoinQueue(CMD_TYPE_5C, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
			}
		}
		Vrf_CmdJoinQueue(CMD_TYPE_42,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		//Buzzer_KeySoundEnable();
		G_KeyCount = KEY_COUNT_5S;
	}
}

/********************************************************************************/
/*
*	@brief ����connectivity�ķ���  
*/
/********************************************************************************/
void Wifi_WindBoardRec(uint8_t ud_dat,uint8_t lr_dat)
{   
	uint8_t i;
	if (G_SystemStatus == 1)
	{
		i = G_WindDirUd[G_SystemMode];
		if (G_UdWindDirGroup[G_SystemMode] == UD_WIND_DIR_GROUP_5)
		{
			switch (ud_dat)
			{
				case 1:
					i = WIND_DIR_UD_LEVEL1;
					break;
				case 2:
					i = WIND_DIR_UD_LEVEL2;
					break;
				case 3:
					i = WIND_DIR_UD_LEVEL3;
					break;
				case 4:
					i = WIND_DIR_UD_LEVEL4;
						
					break;
				case 5:
					i = WIND_DIR_UD_LEVEL5;
					break;
				case 0x0E:
				case 0x0F:
					i = WIND_DIR_UD_AUTO;
					break;
				default:
					i = G_WindDirUd[G_SystemMode];
					break;
			}
		}
		else if (G_UdWindDirGroup[G_SystemMode] == UD_WIND_DIR_GROUP_3)
		{
			switch (ud_dat)
			{
				case 1:
					i = WIND_DIR_UD_LEVEL1;
					break;
				case 2:
					i = WIND_DIR_UD_LEVEL2;
					break;
				case 3:
					i = WIND_DIR_UD_LEVEL3;
					break;
				case 0x0E:
				case 0x0F:
					i = WIND_DIR_UD_AUTO;
					break;
			}
		}
		else if (G_UdWindDirGroup[G_SystemMode] == UD_WIND_DIR_GROUP_ONLY_AUTO)
		{
			if ((ud_dat==0x0E)||(ud_dat==0x0F))
				i = WIND_DIR_UD_AUTO;
				
		}
		if (i!=G_WindDirUd[G_SystemMode])
		{
			G_WindDirUd[G_SystemMode] = i;
			
			Vrf_CmdJoinQueue(CMD_TYPE_4C_UP_WIND_DIR,CMD_NO_REPLY, CMD_FORMAT_SETTING);
			//Buzzer_KeySoundEnable();
			G_KeyCount = KEY_COUNT_5S;
		}

		i = G_WindDirLr[G_SystemMode];
		if (G_LrWindDirGroup == LR_WIND_DIR_GROUP_5)
		{
			switch (lr_dat)
			{
				case 0x06:
					i = WIND_DIR_LR_LEVEL3;
					break;
				case 0x09:
					i = WIND_DIR_LR_LEVEL1;
					break;
				case 0x0a:
					i = WIND_DIR_LR_LEVEL2;
					break;
				case 0x0b:
					i = WIND_DIR_LR_LEVEL4;
					break;
				case 0x0c:
					i = WIND_DIR_LR_LEVEL5;
					break;
				case 0x0D:
					i = WIND_DIR_LR_AUTO;
					break;
			}
		}
		else if (G_LrWindDirGroup == LR_WIND_DIR_GROUP_3)
		{
			switch (lr_dat)
			{
				case 0x06:
					i = WIND_DIR_LR_LEVEL3;
					break;
				case 0x09:
					i = WIND_DIR_LR_LEVEL1;
					break;
				case 0x0c:
					i = WIND_DIR_LR_LEVEL5;
					break;
				case 0x0D:
					i = WIND_DIR_LR_AUTO;
					break;
			}
		}
		
		else if (G_LrWindDirGroup== LR_WIND_DIR_GROUP_ONLY_AUTO)
		{
			if (lr_dat==0x0D)
				i = WIND_DIR_LR_AUTO;
		}

		if (i!=G_WindDirLr[G_SystemMode])
		{
			G_WindDirLr[G_SystemMode] = i;
			
			Vrf_CmdJoinQueue(CMD_TYPE_4C_LR_WIND_DIR, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			//Buzzer_KeySoundEnable();
			G_KeyCount = KEY_COUNT_5S;
		}
	}
}

/********************************************************************************/
/*
*	@brief ����connectivity���¶�  
*/
/********************************************************************************/
void Wifi_TempeRec(uint8_t dat)
{
	uint8_t i;

	i = G_SystemTemp[G_SystemMode];
	i = dat/2;	
	if(i!=G_SystemTemp[G_SystemMode])
	{
		G_SystemTemp[G_SystemMode]=i;	

		Vrf_CmdJoinQueue(CMD_TYPE_4C_TEMPE,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		//Buzzer_KeySoundEnable();
		G_KeyCount = KEY_COUNT_5S;
	}
}

/**************************************************************/
/**
*	@brief	wifi ������غ�������   
*	@note	0.5s����һ��   
*/
/**************************************************************/
void Wifi_1sRelatedCount(void)
{
	static uint8_t count_500ms_temp = 0;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;

	// wifi �����쳣���   40sδ���յ�ͨѶ����Ϊ�쳣   
	if (G_WifiOTA == 2)
	{
		G_WifiOTAWaitCount++;
		if (G_WifiOTAWaitCount>=WIFI_OTA_WAIT_COUNT)
		{
			G_WifiOTAWaitCount = WIFI_OTA_WAIT_COUNT;
		}
	}
	if ((G_WifiState)&&(((G_WifiOTA==2)&&(G_WifiOTAWaitCount>=WIFI_OTA_WAIT_COUNT))||(G_WifiOTA!=2)))
	{
		G_WifiErrCheCount++;
		if (G_WifiErrCheCount>=WIFI_ERR_CHE_COUNT)
		{
			G_WifiErrFlag = 1;
		}
	}

	// wifi����ͼ����ʾ5s   
	if (G_WifiNetShowCount > WIFI_NET_SHOW_COUNT)
		G_WifiNetShowCount = 0;
	else if (G_WifiNetShowCount > 0)
		G_WifiNetShowCount--;

	// wifi��λͼ����ʾ5s   
	if (G_WifiResetShowCnt > WIFI_RESET_SHOW_COUNT)
		G_WifiResetShowCnt = 0;
	else if (G_WifiResetShowCnt > 0)
		G_WifiResetShowCnt--;

	// ���Ӵ���    
	if ((G_NetStatus==3) && (G_WifiConnectNet==2))
	{
		G_WifiConnctNetCount++;
		if (G_WifiConnctNetCount >= WIFI_CONNECT_NET_COUNT)
		{
			G_WifiConnctNetError = 1;
		}
	}


	// wifi �����쳣��ʱ    
	if (ConnectAbCountStart == 1)
	{
		if (G_WifiConnectAbCount>0)
			G_WifiConnectAbCount--;
		else
		{
			ConnectAbCountStart = 0;
			G_WifiConnectAbCount = 0;
			G_WifiLANState = 1;
			G_Rx0SendFlag |= RX0_SEND_FLAG_WIFI;
			
		}
	}
	
}

/**************************************************************/
/**
*	@brief	wifi �¶ȷ��ͼ�ʱ    
*	@note	
*/
/**************************************************************/
void Wifi_10msRelatedCount(void)
{

	//connectivity�¶ȷ��ͼ�ʱ    
	if (G_TempSendCount<TEMP_SEND_COUNT)
		G_TempSendCount++;
	else
	{
		G_WifiTemp[G_SystemMode] = G_SystemTemp[G_SystemMode];
	}

}


/**************************************************************/
/**
*	@brief	�Ƿ���Сwifi���   
*	@note	
*/
/**************************************************************/
void Wifi_FuncCheckDeal(void)
{
	static uint8_t count_500ms_temp = 0;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;
	
	if (G_WifiFunc == 0)
		return;
	G_WifiFuncCount++;
	if (G_WifiFuncCount >= WIFI_FUNC_COUNT)
	{
		G_WifiFuncCount = 0;
		G_WifiFunc = 0;
	}
}

