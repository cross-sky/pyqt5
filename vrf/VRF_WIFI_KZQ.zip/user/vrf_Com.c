#define _EXTERN_VRF_CMD_H_

#include "Common.h"

uint16_t const G_ErrorTimeTable[8] = {40,80,120,160,200,240,280,320};



uint8_t uart1_send(uint8_t const dat)
{
	if (SSR02 & BIT6)
		return 0;
	TXD1 = dat;
	
	return 1;
}

/**********************************************************/
/*
*	@brief 	���ݷ���
*/
/**********************************************************/
void Vrf_DataSend(void)
{

	if (G_CmdSendEnable == 1)
	{

		if (G_SendSelfCheck==0)
			return;
		
		if (uart1_send(G_SendData[G_SendCount]))
		{
			G_SendSelfCheck = 0;
			G_SendNowData = G_SendData[G_SendCount];
			G_SendCount++;
			G_SendTimeoutCount = SEND_TIMEOUT_COUNT;
			G_SendFlag |= SEND_FLAG_BUSY;
			if (G_SendCount >= G_SendDataLength)
			{
				G_CmdSendEnable = 0;
			}
		}

		
	}

}

/**********************************************************/
/*
*	@brief 		��շ���
*	@detials	������еķ���״̬   
*/
/**********************************************************/
void Vrf_ClearSend(void)
{
	G_SendFlag = 0;			// �뷢����ر�־    
	G_CmdSendEnable = 0;		// ���Ͳ�ʹ��
	G_SendSelfCheck = 0;		// δ�Լ�   
	ClearRecBuffer();			// ��ջ���  	
	Vrf_CmdClearQueue();		// ��շ��Ͷ���   
}


/**********************************************************/
/*
*	@brief 	���ڻ����ݷ��ʹ���       
*	@note 	1msɨ��һ�δ˺���      
*/
/**********************************************************/
void Vrf_InitCommunication(void)
{
	static uint8_t send_count = 0;
	
	if (!(G_SendFlag & SEND_FLAG_INIT))
		return;
	if (G_TestMode)
		return;
	if (G_ProSetting != PRO_NO_SET)
		return;

	if (G_InitSendRequest == 0)
		return;
	G_InitSendRequest = 0;
		
	switch (G_InitCmdLevel)
	{
		case INIT_CMD_LEVEL0:
			Vrf_CmdJoinQueue(CMD_TYPE_06_REQ, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			send_count++;
			if (send_count >= 8)
			{
				send_count = 0;
				G_InitCmdLevel = INIT_CMD_LEVEL1;
			}
			break;
		case INIT_CMD_LEVEL1:
			Vrf_CmdJoinQueue(CMD_TYPE_0D, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL2;
			break;
		case INIT_CMD_LEVEL2:
			Vrf_CmdJoinQueue(CMD_TYPE_0A, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL3;
			break;
		case INIT_CMD_LEVEL3:
			Vrf_CmdJoinQueue(CMD_TYPE_81, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL4;
			break;
		case INIT_CMD_LEVEL4:
			Vrf_CmdJoinQueue(CMD_TYPE_0F, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL5;
			break;
		case INIT_CMD_LEVEL5:
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL6;
			break;
		case INIT_CMD_LEVEL6:
			Vrf_CmdJoinQueue(CMD_TYPE_10, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL7;
			break;
		case INIT_CMD_LEVEL7:
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x48, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL8;
			break;
		case INIT_CMD_LEVEL8:
			G_Cmd54Resend = 1;
			Vrf_CmdJoinQueue(CMD_TYPE_54, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL9;
			break;
		case INIT_CMD_LEVEL9:
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x4E, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL10;
			break;
		
		case INIT_CMD_LEVEL10:
			Vrf_CmdJoinQueue(CMD_TYPE_08, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL11;
			break;
		
		case INIT_CMD_LEVEL11:
			Vrf_CmdJoinQueue(CMD_TYPE_13, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL12;
			break;
		case INIT_CMD_LEVEL12:
			Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL13;
			break;
		case INIT_CMD_LEVEL13:
			Vrf_CmdJoinQueue(CMD_TYPE_51, CMD_NO_REPLY, CMD_FORMAT_SETTING);
			G_InitCmdLevel = INIT_CMD_FINISH;
			G_SendFlag &= ~SEND_FLAG_INIT;
			Buzzer_KeySoundEnable();
			break;
		case INIT_CMD_FINISH:
			G_SendFlag &= ~SEND_FLAG_INIT;
			break;
	}
}

/**********************************************************/
/*
*	@brief 	���������ͨѶ     
*	@note 	1msɨ��һ�δ˺���      
*/
/**********************************************************/
void Vrf_OutdoorInitCom(void)
{
	if (!(G_SendFlag & SEND_FLAG_OUTDOOR_INIT))
		return;

	if (G_InitSendRequest == 0)
		return;
	G_InitSendRequest = 0;

	switch (G_InitCmdLevel)
	{
		case INIT_CMD_LEVEL1:
			Vrf_CmdJoinQueue(CMD_TYPE_18, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL2;
			break;
		case INIT_CMD_LEVEL2:
			Vrf_CmdJoinQueue(CMD_TYPE_0E, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL3;
			break;
		case INIT_CMD_LEVEL3:
			Vrf_CmdJoinQueue(CMD_TYPE_19_REG, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL4;
			break;
		case INIT_CMD_LEVEL4:
			Vrf_CmdJoinQueue(CMD_TYPE_8B_REG, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			G_InitCmdLevel = INIT_CMD_LEVEL5;
			break;
		case INIT_CMD_LEVEL5:
			G_SendFlag &= ~SEND_FLAG_OUTDOOR_INIT;
			break;
	}
}

void Vrf_OutdoorRegCom(void)
{
	static uint8_t count_500ms_temp = 0;
	
	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;

	if (GuiTaskMode != OUTDOOR_NORMAL_TAST)
		return;
	
	if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT)
		return;
	
	G_RegularComCnt++;
	if (G_RegularComCnt >= REG_COM_COUNT_5S)
	{
		G_RegularComCnt = 0;
		if (G_SendFlag & SEND_FLAG_WAIT_RES)
			return;

		Vrf_CmdJoinQueue(CMD_TYPE_8B_REG, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		Vrf_CmdJoinQueue(CMD_TYPE_19_REG, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
	}
}


/**********************************************************/
/*
*	@brief 	����ͨѶ    
*	@detail 
*/
/**********************************************************/
void Vrf_RegularCommunication(void)
{
	static uint8_t count_500ms_temp = 0;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;

	if ((GuiTaskMode!=NORMAL_TAST)&&(GuiTaskMode!=REMO_SET_TAST)&&(GuiTaskMode!=ERROR_INDEX_TAST))
		return;
	
	if (G_SendFlag & SEND_FLAG_INIT)
		return;
	
	
	G_RegularComCnt++;
	if (G_RegularComCnt>=REG_COM_COUNT_30S)
	{
		G_RegularComCnt = 0;
		if (G_SendFlag & SEND_FLAG_WAIT_RES)
			return;
		if (G_Cmd54Resend == 1)
		{
			Vrf_CmdJoinQueue(CMD_TYPE_54, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		}
		Vrf_CmdJoinQueue(CMD_TYPE_81,CMD_HAVE_REPLY,CMD_FORMAT_REQUEST);
		Vrf_CmdJoinQueue(CMD_TYPE_5F,CMD_HAVE_REPLY,CMD_FORMAT_REQUEST);
		
		if (G_RegularCmd0cLevel == REGULAR_CMD_OC_40)
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x40, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		else if (G_RegularCmd0cLevel == REGULAR_CMD_OC_48)
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x48, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		else
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x4E, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		G_RegularCmd0cLevel++;
		G_RegularCmd0cLevel %= 3;
		
		Vrf_CmdJoinQueue(CMD_TYPE_49, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		
	}
}

/**********************************************************/
/*
*	@brief 	������ģʽ����ͨѶ   
*/
/**********************************************************/
void Vrf_ScRegularCom(void)
{
	static uint8_t count_500ms_temp = 0;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;

	if (G_ServerCheck==0)
		return;

	if (G_ServerObj!=0x00)
	{
		G_ScComCnt++;
		if (G_ScComCnt>=SC_COM_CNT)
		{
			G_ScComCnt = 0;
			if (GuiTaskMode == SERVER_INDEX_TAST)
			{
				Vrf_CmdJoinQueue(CMD_TYPE_2C_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			}
			else 
			{
				Vrf_CmdJoinQueue(CMD_TYPE_2C, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			}
		}
	}
}


/**********************************************************/
/*
*	@brief 	VRFͨѶ��� 1ms����    
*	@note 	
*/
/**********************************************************/
void Vrf_Count1msDeal(void)
{
	Vrf_SendDataWaitCount();	// δ���յ������źŵ���ʱ    
	SendDat_TimeoutCount();		
	FitTimeClearRecBuffer();		// �̶�ʱ��δ�����建��    
}

/**********************************************************/
/*
*	@brief 	�������ݵȴ����ż�ʱ      
*	@note 	1msɨ��һ�δ˺���     
*/
/**********************************************************/
void Vrf_SendDataWaitCount(void)
{
	static uint8_t cmd_type_temp = 0;
	if (!(G_SendFlag & SEND_FLAG_WAIT_RES))
		return;

	G_SendErrorCount--;
	if (G_SendErrorCount == 0)
	{
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;
		G_CmdNeedResponse = 0;

		switch (GuiTaskMode)
		{
			case NORMAL_TAST:
				if (G_SendFlag & SEND_FLAG_INIT) 
				{
					if (G_SendState.cmdType == CMD_TYPE_06_REQ)
					{
						G_InitSendRequest = 1;
					}
					else
					{
						Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
					}
				}
				else
				{
					G_ResendCount++;
					if (cmd_type_temp == G_SendState.cmdType)
					{
						if (G_ResendCount<10)
							Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
						else
						{
							G_ResendCount = 0;
						}
					}
					else
					{
						G_ResendCount = 1;
						cmd_type_temp = G_SendState.cmdType;
						Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
					}
				}
				break;
			case PRO_TAST:
				if (G_ProSetting)
				{
					if (G_SendState.cmdType==CMD_TYPE_64_START)
					{
						G_ProCmdCount++;
						if (G_ProCmdCount<=30)
							Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
						else
							G_ProCmdCount = 0;
					}
					else
					{
						Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
					}
				}
				break;
			case SERVER_INDEX_TAST:
			case OUTDOOR_SERVER_INDEX_TAST:
				if (G_ServerCheck)
				{
					if ((G_ServerObj!=0)&&(G_ServerRecFeedBack==0))
						Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
				}
				break;
			case AUTO_ADDR_TAST:
				break;
			case MANUAL_ADDR_TAST:
				Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
				break;
			case OUTDOOR_NORMAL_TAST:
				if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT)
					Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
				break;
			default :
				Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
				break;
		}
	}
}


/**********************************************************/
/*
*	@brief 	����һ֡������������֮���ʱ����    
*	@note 	
*/
/**********************************************************/
void SendDat_TimeoutCount(void)
{
	if (G_SendFlag & SEND_FLAG_BUSY)
	{
		if (G_SendTimeoutCount > 0)
			G_SendTimeoutCount--;
		else
		{
			G_CmdSendEnable = 0;
			G_SendFlag &= ~(SEND_FLAG_BUSY+SEND_FLAG_WAIT_RES);
			Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
			G_CmdNeedResponse = 0;
		}
	}
}



/**********************************************************/
/*
*	@brief 	���ݷ���
*/
/**********************************************************/
#if 0
void Vrf_DataSend(void)
{
	Vrf_GetCmdData();

	if (G_CmdSendEnable == 1)
	{
		if (G_SendFlag == SEND_FLAG_BUSY)
			return;

		G_CmdSendEnable = 0;
		R_UART1_Send(G_SendData,G_SendDataLength);
		G_SendFlag |= SEND_FLAG_BUSY;
	}

}
#endif


/**********************************************************/
/*
*	@brief 	ָ���ȡ    
*/
/**********************************************************/
void Vrf_GetCmdData(void)
{
	
	switch (G_SendState.cmdType)
	{
		case CMD_TYPE_06_REQ:
		case CMD_TYPE_06_REQ_EXPAND:
		case CMD_TYPE_06_SET_EXPAND:
			cmd06();
			break;
		case CMD_TYPE_0D:
			cmd0D();
			break;
		case CMD_TYPE_0A:
			cmd0A();
			break;
		case CMD_TYPE_81:
			cmd81();
			break;
		case CMD_TYPE_0F:
			cmd0F();
			break;
		case CMD_TYPE_0C_0x30:
		case CMD_TYPE_0C_0x40:
		case CMD_TYPE_0C_0x48:
		case CMD_TYPE_0C_0x4E:
			cmd0C();
			break;
		case CMD_TYPE_10:
			cmd10();
			break;
		case CMD_TYPE_54:
			cmd54();
			break;
		case CMD_TYPE_08:
			cmd08();
			break;
		case CMD_TYPE_13:
			cmd13();
			break;
		case CMD_TYPE_45:
			cmd45();
			break;
		case CMD_TYPE_55:
			cmd55();
			break;
		case CMD_TYPE_51:
			cmd51();
			break;		
		case CMD_TYPE_41_ON_OFF:
		case CMD_TYPE_41_TRY_RUN:
			cmd41();
			break;
		case CMD_TYPE_42:
			cmd42();
			break;
		case CMD_TYPE_4C_TEMPE:
		case CMD_TYPE_4C_WINDSPEED:
		case CMD_TYPE_4C_UP_WIND_DIR:
		case CMD_TYPE_4C_LR_WIND_DIR:
			cmd4C();
			break;
		case CMD_TYPE_5C:
			cmd5C();
			break;
		case CMD_TYPE_52:
			cmd52();
			break;
		case CMD_TYPE_58:
			cmd58();
			break;
		case CMD_TYPE_61:
		case CMD_TYPE_61_EXPAND:
			cmd61();
			break;
		case CMD_TYPE_64_START:
		case CMD_TYPE_64_STOP:
		case CMD_TYPE_64_START_EXPAND:
		case CMD_TYPE_64_STOP_EXPAND:
			cmd64();
			break;
		case CMD_TYPE_02_F1:
			cmd02();
			break;
		case CMD_TYPE_02_F2:
			cmd02();
			break;
		case CMD_TYPE_02_F3:
			cmd02();
			break;
		case CMD_TYPE_02_F4:
			cmd02();
			break;
		case CMD_TYPE_02_F5:
			cmd02();
			break;
		case CMD_TYPE_02_F7:
			cmd02();
			break;
		case CMD_TYPE_07:
			cmd07();
			break;
		case CMD_TYPE_62_EEP_EX:
		case CMD_TYPE_62:
		case CMD_TYPE_62_EXPAND:
			cmd62();
			break;
		case CMD_TYPE_4B:
			cmd4B();
			break;
		case CMD_TYPE_49:
			cmd49();
			break;
		case CMD_TYPE_2C_EXPAND:
		case CMD_TYPE_2C:
			cmd2C();
			break;
		case CMD_TYPE_67_START:
		case CMD_TYPE_67_COMFIRM:
			cmd67();
			break;
		case CMD_TYPE_0E:
		case CMD_TYPE_0E_EXPAND:
			cmd0E();
			break;
		case CMD_TYPE_63_EXPAND:
			cmd63();
			break;
		case CMD_TYPE_5F:
			cmd5F();
			break;
		case CMD_TYPE_27:
			cmd27();
			break;
		case  CMD_TYPE_18:
			cmd18();
			break;
		case CMD_TYPE_19_KEY:
		case CMD_TYPE_19_REG:
			cmd19();
			break;
		case CMD_TYPE_8B_REG:
		case CMD_TYPE_8B_KEY:
			cmd8B();
			break;
		case CMD_TYPE_16_INIT:
		case CMD_TYPE_16_F1_F5:
		case CMD_TYPE_16_F2_F5:
		case CMD_TYPE_16_F5_F1:
		case CMD_TYPE_16_F5_F2:
			cmd16();
			break;
		case CMD_TYPE_17:
			cmd17();
			break;
			
	}

	if (G_CmdNeedResponse == CMD_HAVE_REPLY)
	{
		G_SendFlag |= SEND_FLAG_WAIT_RES;
		G_SendErrorCount = INIT_CMD_TIME_500MS;
	}
	else
	{
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;
		G_SendErrorCount = INIT_CMD_TIME_500MS;
	}
	
	G_CmdSendEnable = 1;
	G_SendCount = 0;
	G_SendSelfCheck = 1;
}

void cmd06(void)
{
	uint8_t i;
	uint16_t temp;

	// �Ƿ���Ҫ����    
		G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdType == CMD_TYPE_06_REQ)
	{
		
		// ���ݳ���  
		G_SendDataLength = 8;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xF1;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = 0x00;
		G_SendData[DATA_CMD] = 0x06;
		G_SendData[6] = 0x00;
	}
	else if (G_SendState.cmdType == CMD_TYPE_06_REQ_EXPAND)
	{
		// ���ݳ���  
		G_SendDataLength = 11;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xF0;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = 0x00;
		temp = ((uint16_t)G_ManualSystemNum)<<6;
		temp += 0x0800;
		temp +=(uint16_t)G_LicIndoorNum[G_ManualIndoorNum];
		G_SendData[DATA_SA+5] = (uint8_t)temp;
		G_SendData[DATA_DA+5] = 0xEF;
		G_SendData[DATA_EA+3] =  (uint8_t)((temp&0x0f00)>>4);
		G_SendData[DATA_CMD+3] = 0x06;
		G_SendData[9] = 0x01;
	}
	else if (G_SendState.cmdType == CMD_TYPE_06_SET_EXPAND)
	{
		// ���ݳ���  
		G_SendDataLength = 13;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xF0;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = 0x00;
		temp = ((uint16_t)G_ManualSystemNum)<<6;
		temp += 0x0800;
		temp +=(uint16_t)G_LicIndoorNum[G_ManualIndoorNum];
		G_SendData[DATA_SA+5] = (uint8_t)temp;
		G_SendData[DATA_DA+5] = 0xEF;
		G_SendData[DATA_EA+3] =  (uint8_t)((temp&0x0f00)>>4);
		G_SendData[DATA_CMD+3] = 0x06;
		temp = ((uint16_t)G_ManualSystemNum)<<6;
		temp += 0x0800;
		temp +=(uint16_t)G_ManualAddr;
		G_SendData[9] =  (uint8_t)(temp>>8);
		G_SendData[10] = (uint8_t)temp;
		G_SendData[11] = 0xFF;
	}
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
	
}

void cmd0D(void)
{
	uint8_t i;

	// ��Ҫ����
	G_CmdNeedResponse = G_SendState.cmdReply;
	
	// ���ݳ���  
	G_SendDataLength = 7;
	
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = 0xF0;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = 0x00;
	G_SendData[DATA_CMD] = 0x0D;
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;

}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd0A(void)
{
	cmdxx(0x0A);
}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd81(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_ErrorCode==0x49)
	{
		G_SendDataLength = 10;
		G_SendData[8] = G_ErrorCode;
	}
	else
	{
		G_SendDataLength = 9;
	}
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x81;

	
	G_SendData[6] = 0x00;
	G_SendData[7] = 0x00;				// �����¶���ʲô��˼   
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;

}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd0F(void)
{
	cmdxx(0x0F);
}

/****************************************************/
/*
	@param		G_SendState.cmdformat:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd0C(void)
{
	uint8_t i;

	if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		if (G_SendState.cmdType == CMD_TYPE_0C_0x30)
		{
			G_SendDataLength = 14;
			G_SendData[6] = 0x82;
			G_SendData[7] = 0x00;
			G_SendData[8] = 0x00;
			G_SendData[9] = 0x30;
			if (G_TimerType == TIMER_TYPE_NO_SET)
				G_SendData[10] = 0x00;
			else if (G_TimerType == TIMER_TYPE_ONCE_OFF)
				G_SendData[10] = 0x05;
			else if (G_TimerType == TIMER_TYPE_CYCLE_OFF)
				G_SendData[10] = 0x06;
			else if (G_TimerType == TIMER_TYPE_ONCE_ON)
				G_SendData[10] = 0x07;
			G_SendData[11] = (uint8_t)(G_TimerHour*2/10);
			G_SendData[12] = (uint8_t)(G_TimerRemainHour*2/10);
			
		}
		else if (G_SendState.cmdType == CMD_TYPE_0C_0x40)
		{
			G_SendDataLength = 12;
			G_SendData[6] = 0x80;
			G_SendData[9] = 0x40;
		}
		else if (G_SendState.cmdType == CMD_TYPE_0C_0x48)
		{
			G_SendDataLength = 12;
			G_SendData[6] = 0x81;
			G_SendData[9] = 0x48;
		}
		else if (G_SendState.cmdType == CMD_TYPE_0C_0x4E)
		{
			G_SendDataLength = 12;
			G_SendData[6] = 0x80;
			G_SendData[9] = 0x4E;
		}
		// �Ƿ���Ҫ����    
	 	G_CmdNeedResponse = G_SendState.cmdReply;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x0C;

		G_SendData[G_SendDataLength-1] = 0;
		for (i=0;i<G_SendDataLength-1;i++)
			G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
	}
	else if (G_SendState.cmdformat == CMD_FORMAT_REQUEST)
	{
		// �Ƿ���Ҫ����    
	 	G_CmdNeedResponse = G_SendState.cmdReply;
		
		G_SendDataLength = 12;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x0C;
		if (G_SendState.cmdType == CMD_TYPE_0C_0x30)
		{
			G_SendData[6] = 0x82;
			G_SendData[9] = 0x30;
		}
		else if (G_SendState.cmdType == CMD_TYPE_0C_0x40)
		{
			G_SendData[6] = 0x80;
			G_SendData[9] = 0x40;
		}
		else if (G_SendState.cmdType == CMD_TYPE_0C_0x48)
		{
			G_SendData[6] = 0x81;
			G_SendData[9] = 0x48;
		}
		else if (G_SendState.cmdType == CMD_TYPE_0C_0x4E)
		{
			G_SendData[6] = 0x80;
			G_SendData[9] = 0x4E;
		}
		
		G_SendData[7] = 0x00;
		G_SendData[8] = 0x00;
		
		G_SendData[10] = 0x00;
		
		G_SendData[G_SendDataLength-1] = 0;
		for (i=0;i<G_SendDataLength-1;i++)
			G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
	}
}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd10(void)
{
	cmdxx(0x10);
}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd08(void)
{
	cmdxx(0x08);
}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd13(void)
{
	cmdxx(0x13);
}
/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd45(void)
{
	cmdxx(0x45);
}
/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd55(void)
{
	cmdxx(0x55);
}
/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmd51(void)
{
	uint8_t i;
	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 8;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = 0xF0;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  G_RemoAdd.add8.addH<<4;
	G_SendData[DATA_CMD] = 0x51;
	G_SendData[6] = 0;
	
	G_SendData[7] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[7] ^= G_SendData[i] ;
}

/****************************************************/
/*
	@param		send_data_type:
				00: �趨    01: Ҫ��  
				02: Ӧ��    03: ״̬�ı�   
*/
/****************************************************/
void cmdxx(uint8_t cmd_temp)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 7;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = cmd_temp;
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd41(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 8;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x41;

	G_SendData[6] = 0;
	if (G_SendState.cmdType == CMD_TYPE_41_TRY_RUN)
	{
		if (G_TryRun == 1)
			G_SendData[6] |= (BIT6+BIT7);
		else
			G_SendData[6] |= BIT7;
	}
	else
	{
		if (G_SystemStatus == SYSTEM_STATUS_ON)
			G_SendData[6] |= BIT0;
		if (G_SystemStatusFunc == 1)
			G_SendData[6] |= BIT1;
	}
	
	
	
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd42(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 8;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x42;
	
	switch (G_SystemMode)
	{
		case SYSTEM_MODE_AUTO:
			G_SendData[6] = 0x05;
			break;
		case SYSTEM_MODE_WARM:
			G_SendData[6] = 0x01;
			break;
		case SYSTEM_MODE_COLD:
			G_SendData[6] = 0x02;
			break;
		case SYSTEM_MODE_WET:
			G_SendData[6] = 0x04;
			break;
		case SYSTEM_MODE_WIND:
			G_SendData[6] = 0x03;
			break;
	}
	
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd4C(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_LrWindDirGroup != LR_WIND_DIR_GROUP_NO)
		G_SendDataLength = 11;
	else
		G_SendDataLength = 10;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x4C;
	
	switch (G_SystemMode)
	{
		case SYSTEM_MODE_AUTO:
			if (G_AutoCold == AUTO_WARM)
				G_SendData[6] = 0x05;
			else
				G_SendData[6] = 0x06;
			break;
		case SYSTEM_MODE_WARM:
			G_SendData[6] = 0x01;
			break;
		case SYSTEM_MODE_COLD:
			G_SendData[6] = 0x02;
			break;
		case SYSTEM_MODE_WET:
			G_SendData[6] = 0x04;
			break;
		case SYSTEM_MODE_WIND:
			G_SendData[6] = 0x03;
			break;
	}
	if (G_SendState.cmdType == CMD_TYPE_4C_TEMPE)
		G_SendData[6] |= BIT3;
	else if (G_SendState.cmdType == CMD_TYPE_4C_WINDSPEED)
		G_SendData[6] |= BIT4;
	else if (G_SendState.cmdType == CMD_TYPE_4C_UP_WIND_DIR)
	{
		G_SendData[6] |= BIT5;
		G_SendData[DATA_DA] = 0xFE;
		G_SendData[DATA_EA] = 0x00;
	}
	else if (G_SendState.cmdType == CMD_TYPE_4C_LR_WIND_DIR)
		G_SendData[6] |= (BIT6+BIT7);

	G_SendData[7] = 0;
	if (G_WindSpeed[G_SystemMode] == WIND_SPEED_AUTO)
		G_SendData[7] |= 2;
	else if (G_WindSpeed[G_SystemMode] == WIND_SPEED_LEVEL5)
		G_SendData[7] |= 3;
	else if (G_WindSpeed[G_SystemMode] == WIND_SPEED_LEVEL4)
		G_SendData[7] |= (BIT6+4);
	else if (G_WindSpeed[G_SystemMode] == WIND_SPEED_LEVEL3)
		G_SendData[7] |= 4;
	else if (G_WindSpeed[G_SystemMode] == WIND_SPEED_LEVEL2)
		G_SendData[7] |= (BIT6+5);
	else if (G_WindSpeed[G_SystemMode] == WIND_SPEED_LEVEL1)
		G_SendData[7] |= 5;

	switch (G_WindDirUd[G_SystemMode])
	{
		case WIND_DIR_UD_AUTO_STOP:
			G_SendData[7] |= (7<<3);
			break;
		case WIND_DIR_UD_LEVEL1:
			G_SendData[7] |= (2<<3);
			break;
		case WIND_DIR_UD_LEVEL2:
			G_SendData[7] |= (3<<3);
			break;
		case WIND_DIR_UD_LEVEL3:
			G_SendData[7] |= (4<<3);
			break;
		case WIND_DIR_UD_LEVEL4:
			G_SendData[7] |= (5<<3);
			break;
		case WIND_DIR_UD_LEVEL5:
			G_SendData[7] |= (6<<3);
			break;
		case WIND_DIR_UD_AUTO:
			G_SendData[7] |= (1<<3);
			break;
	}

	G_SendData[8] = G_SystemTemp[G_SystemMode] * 2 +70;

	if (G_LrWindDirGroup != LR_WIND_DIR_GROUP_NO)
	{
		G_SendData[9] = 0;
		switch (G_WindDirLr[G_SystemMode])
		{
			case WIND_DIR_LR_AUTO_STOP:
				G_SendData[9] |=(7+ (7<<3));
				break;
			case WIND_DIR_LR_LEVEL1:
				G_SendData[9] |=(2+ (2<<3));
				break;
			case WIND_DIR_LR_LEVEL2:
				G_SendData[9] |=(3+ (3<<3));
				break;
			case WIND_DIR_LR_LEVEL3:
				G_SendData[9] |=(4+ (4<<3));
				break;
			case WIND_DIR_LR_LEVEL4:
				G_SendData[9] |=(5+ (5<<3));
				break;
			case WIND_DIR_LR_LEVEL5:
				G_SendData[9] |=(6+ (6<<3));
				break;
			case WIND_DIR_LR_AUTO:
				G_SendData[9] |=(1+ (1<<3));
				break;
		}
	}
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	��������ȷ��   
*	@detail 
*/
/**********************************************************/
void cmd54(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	
	if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		G_SendData[6] = 0x08 +(G_SaveEnergyFunc)+(G_SaveEnergy<<1);
		G_SendDataLength = 8;
	}
	else
	{
		G_SendDataLength = 7;
	}
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x54;

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
	
}

/**********************************************************/
/*
*	@brief 	��������ȷ��   
*	@detail 
*/
/**********************************************************/
void cmd5C(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	
	if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		G_SendDataLength = 9;
		G_SendData[6] = 0x00;
		G_SendData[7] = G_NanoeStatus + (G_NanoeFunc<<1);
	}
	else
	{
		G_SendDataLength = 8;
		G_SendData[6] = 0x00;
	}
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x5C;

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
	
}

void cmd52(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdformat == CMD_FORMAT_REQUEST)
	{
		G_SendDataLength = 7;
	}
	else if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		G_SendDataLength = 8;
		G_SendData[6] = G_FreshAir;
	}
	
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x52;


	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd58(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdformat == CMD_FORMAT_REQUEST)
	{
		G_SendDataLength = 9;
		G_SendData[6] = 0x00;
		G_SendData[7] = 0x00;
	}
	else if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		G_SendDataLength = 10;
		G_SendData[6] = 0x00;
		G_SendData[7] = 0x00;
		G_SendData[8] = G_EconaviStatus;
	}
	
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x58;


	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd61(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdformat == CMD_FORMAT_REQUEST)
	{
		G_SendDataLength = 8;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x61;
		G_SendData[6] = 0x00;
	}
	else if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		if (G_SendState.cmdType == CMD_TYPE_61)
		{
			G_SendDataLength = 8;
			G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
			G_SendData[DATA_DA] = 0xFE;
			G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
			G_SendData[DATA_BC] = G_SendDataLength - 5;
			G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
			G_SendData[DATA_CMD] = 0x61;
			G_SendData[6] = 0x00;
		}
		else if (G_SendState.cmdType == CMD_TYPE_61_EXPAND)
		{
			G_SendDataLength = 11;
			G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
			G_SendData[DATA_DA] = 0xFD;
			G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
			G_SendData[DATA_BC] = G_SendDataLength - 5;
			G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
			G_SendData[DATA_SA+5] = 0xFD;			// SA'
			G_SendData[DATA_DA+5] = 0xF2;			// DA'
			G_SendData[DATA_EA+3] = 0x00;			// EA'
			G_SendData[DATA_CMD+3] = 0x61;
			G_SendData[9] = 0x00;
		}
	}
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd64(void)
{
	uint8_t i;
	uint16_t temp;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	switch (G_SendState.cmdType)
	{
		case CMD_TYPE_64_START:
			G_SendDataLength = 8;
			G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
			G_SendData[DATA_DA] = G_MainAdd.add8.addL;
			G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
			G_SendData[DATA_BC] = G_SendDataLength - 5;
			G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
			G_SendData[DATA_CMD] = 0x64;
			G_SendData[6] = 0x01;
			break;
		case CMD_TYPE_64_STOP:
			G_SendDataLength = 8;
			G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
			G_SendData[DATA_DA] = 0xFE;
			G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
			G_SendData[DATA_BC] = G_SendDataLength - 5;
			G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+0;
			G_SendData[DATA_CMD] = 0x64;
			G_SendData[6] = 0x00;
			break;
		case CMD_TYPE_64_START_EXPAND:
			G_SendDataLength = 11;
			G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
			G_SendData[DATA_DA] = 0xF0;
			G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
			G_SendData[DATA_BC] = G_SendDataLength - 5;
			G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
			temp = ((uint16_t)G_ManualSystemNum)<<6;
			temp += 0x0800;
			temp +=(uint16_t)G_LicIndoorNum[G_ManualIndoorNum];
			G_SendData[DATA_SA+5] = (uint8_t)temp;
			G_SendData[DATA_DA+5] = 0xEF;
			G_SendData[DATA_EA+3] =  (uint8_t)((temp&0x0f00)>>4);
			G_SendData[DATA_CMD+3] = 0x64;
			G_SendData[9] = 0x01;
			break;
		case CMD_TYPE_64_STOP_EXPAND:
			G_SendDataLength = 11;
			G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
			G_SendData[DATA_DA] = 0xFD;
			G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
			G_SendData[DATA_BC] = G_SendDataLength - 5;
			G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
			G_SendData[DATA_SA+5] = 0xFD;
			G_SendData[DATA_DA+5] = 0xF2;
			G_SendData[DATA_EA+3] =  0x00;
			G_SendData[DATA_CMD+3] = 0x64;
			G_SendData[9] = 0x00;
			break;
	}
	
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i];
	
}

void cmd02(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdformat == CMD_FORMAT_REQUEST)
	{
		G_SendDataLength = 9;
		
	}
	else if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		G_SendDataLength = 9;
	}

	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x02;
	
	if (G_SendState.cmdType == CMD_TYPE_02_F1)
	{
		G_SendData[6] = 0xF1;
	}
	else if (G_SendState.cmdType == CMD_TYPE_02_F2)
	{
		G_SendData[6] = 0xF2;
	}
	else if (G_SendState.cmdType == CMD_TYPE_02_F3)
	{
		G_SendData[6] = 0xF3;
	}
	else if (G_SendState.cmdType == CMD_TYPE_02_F4)
	{
		G_SendData[6] = 0xF4;
	}
	else if (G_SendState.cmdType == CMD_TYPE_02_F5)
	{
		G_SendData[6] = 0xF5;
	}
	else if (G_SendState.cmdType == CMD_TYPE_02_F7)
	{
		G_SendData[6] = 0xF7;
	}
	G_SendData[7] = G_ProCode;
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd07(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 9;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	
	G_SendData[DATA_CMD] = 0x07;
	if (G_ProType == PRO_TYPE_DETAIL)
	{
		if (G_ProSendObj == PRO_SEND_OBJ_SINGLE)
		{
			G_SendData[DATA_DA] = G_MainAdd.add8.addL;
			G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		}
		else
		{
			G_SendData[DATA_DA] = 0xF0;
			G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+0;
		}
	}
	else if (G_ProType == PRO_TYPE_SIMPLE)
	{
		G_SendData[DATA_DA] = 0xF0;
		G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+0;
	}
	else if (G_ProType == PRO_TYPE_OUTDOOR_DETAIL)
	{
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	}
	
	G_SendData[6] = G_ProCode;
	G_SendData[7] = G_ProData;
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd62(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdType == CMD_TYPE_62)
	{
		G_SendDataLength = 7;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xFE;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+0;
		G_SendData[DATA_CMD] = 0x62;
	}
	else if (G_SendState.cmdType == CMD_TYPE_62_EXPAND)
	{
		G_SendDataLength = 10;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xFD;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+0;
		G_SendData[DATA_SA+5] = 0xFD;			// SA'
		G_SendData[DATA_DA+5] = 0xF2;			// DA'
		G_SendData[DATA_EA+3] = 0x00;			// EA'
		G_SendData[DATA_CMD+3] = 0x62;
	}
	else if (G_SendState.cmdType == CMD_TYPE_62_EEP_EX)
	{
		G_SendDataLength = 10;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x80+G_SystemNumbel;
		
		G_SendData[6] = 0xFE;
		G_SendData[7] = 0x00;
		G_SendData[8] = 0x62;
	}
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i];

}

void cmd4B(void)
{
	cmdxx(0x4B);
}

void cmd49(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 7;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x50+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x49;
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	����ģʽ���ݼ���     
*	@detail 
*/
/**********************************************************/
void cmd2C(void)
{
	uint8_t i;

	union_add_type addr_temp;


	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;
	if (G_SendState.cmdType == CMD_TYPE_2C_EXPAND)
	{
		G_SendDataLength = 13;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_SA+5] = 0x80+G_SystemNumbel;			// SA'
		G_SendData[DATA_DA+5] = 0xEF;			// DA'
		G_SendData[DATA_EA+3] = 0x00;			// EA'
		G_SendData[DATA_CMD+3] = 0x2C;		// ����ָ��������data8    
		
		G_SendData[9] = G_MainAdd.add8.addH;
		G_SendData[10] = G_MainAdd.add8.addL;
		G_SendData[11] = G_ServerObj;

		
	}
	else if (G_SendState.cmdType == CMD_TYPE_2C)
	{
		G_SendDataLength = 10;
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x2C;		

		addr_temp.add16 = G_SystemNumbel;
		addr_temp.add16 = (uint16_t)(((addr_temp.add16+0x20)<<6)+(uint16_t)G_IndoorNumbel);	// ������ϲ���ַ  
		
		G_SendData[6] = addr_temp.add8.addH;
		G_SendData[7] = addr_temp.add8.addL;
		G_SendData[8] = G_ServerObj;
	}

	G_SendData[G_SendDataLength-1] = 0;
		for (i=0;i<G_SendDataLength-1;i++)
			G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	�Զ���ַ�趨    
*	@detail 
*/
/**********************************************************/
void cmd67(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdType == CMD_TYPE_67_START)
	{
		G_SendDataLength = 11;
		G_SendData[9] = 0x01;
	}
	else if (G_SendState.cmdType == CMD_TYPE_67_COMFIRM)
	{
		G_SendDataLength = 10;
	}
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = 0xF0;
	G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
	G_SendData[DATA_SA+5] = 0x80+G_SystemType;			// SA'
	G_SendData[DATA_DA+5] = 0xEF;			// DA'
	G_SendData[DATA_EA+3] = 0x00;			// EA'
	G_SendData[DATA_CMD+3] = 0x67;

	

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	�ֶ���ַ�趨���   
*	@detail ��ȡ���ڻ��ṹ    
*/
/**********************************************************/
void cmd0E(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdType == CMD_TYPE_0E_EXPAND)
	{
		G_SendDataLength = 10;
	
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xF0;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
		G_SendData[DATA_SA+5] = 0x80+G_ManualSystemNum;			// SA'
		G_SendData[DATA_DA+5] = 0xEF;			// DA'
		G_SendData[DATA_EA+3] = 0x00;			// EA'
		G_SendData[DATA_CMD+3] = 0x0E;
	}
	else if (G_SendState.cmdType == CMD_TYPE_0E)
	{
		G_SendDataLength = 7;
	
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x0E;
		
	}
	

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd63(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	if (G_SendState.cmdType == CMD_TYPE_63_EXPAND)
	{
		G_SendDataLength = 10;
	
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = 0xF0;
		G_SendData[DATA_CC] = 0x12+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  ((G_RemoAdd.add8.addH<<4)+0);
		G_SendData[DATA_SA+5] = 0xA0+G_ManualSystemNum;			// SA'
		G_SendData[DATA_DA+5] = 0xEF;			// DA'
		G_SendData[DATA_EA+3] = 0x00;			// EA'
		G_SendData[DATA_CMD+3] = 0x63;
	}
	

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd5F(void)
{
	uint8_t i;
	G_CmdNeedResponse = G_SendState.cmdReply;
	if (G_SendState.cmdformat == CMD_FORMAT_SETTING)
	{
		
		switch (G_Cmd5FFnc)
		{
			case CMD_5F_FNC_WIND_STRONG:
				G_SendDataLength = 9;
				G_SendData[6] = 1;
				if (G_SpecWindSpeed==WIND_SPEED_SPEC_STRONG)
					G_SendData[7] = 1;
				else
					G_SendData[7] = 0;
				break;
			case CMD_5F_FNC_WIND_MUTE:
				G_SendDataLength = 9;
				G_SendData[6] = 2;
				if (G_SpecWindSpeed==WIND_SPEED_SPEC_MUTE)
					G_SendData[7] = 1;
				else
					G_SendData[7] = 0;
				break;
			case CMD_5F_FNC_LED_DUTY:
				G_SendDataLength = 9;
				G_SendData[6] = 3;
				G_SendData[7] = G_LedDuty;
				break;
			case CMD_5F_FNC_WIFI:
				G_SendDataLength = 10;
				G_SendData[6] = 4;
				G_SendData[7] = G_WifiCmd5F;
				if (G_WifiCmd5F == WIFI_CMD_5F_ON_OFF)
					G_SendData[8] = G_WifiState;
				else
					G_SendData[8] = 0;
				break;
		}
		
		
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x5F;
		
	}
	else if (G_SendState.cmdformat == CMD_FORMAT_REQUEST)
	{
		G_SendDataLength = 8;
		
		G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
		G_SendData[DATA_DA] = G_MainAdd.add8.addL;
		G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
		G_SendData[DATA_BC] = G_SendDataLength - 5;
		G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
		G_SendData[DATA_CMD] = 0x5F;
		G_SendData[6] = 0x00;
		
	}
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	�쳣���뱨��ָ��             
*	@detail 	�쳣����           
*/
/**********************************************************/
void cmd27(void)
{
	uint8_t i;
	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 8;
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x27;

	G_SendData[DATA_CMD+1] = G_ErrorObj+1;

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
	
	
}

/**********************************************************/
/*
*	@brief 	�������ͨѶ   
*	@detail 	ȷ�������ϵͳ    
*/
/**********************************************************/
void cmd18(void)
{
	uint8_t i;
	
	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 7;
	
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = 0xF1;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = 0x00;
	G_SendData[DATA_CMD] = 0x18;
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	�������ͨѶ   
*	@detail 	ȷ�������ϵͳ    
*/
/**********************************************************/
void cmd19(void)
{
	uint8_t i;
	
	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 11;
	
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x19;

	G_SendData[6] = G_OutdoorIndex;

	if (G_SendState.cmdType == CMD_TYPE_19_KEY)
	{
		G_SendData[7] = (uint8_t)(G_8BKeyValue>>8);
		G_SendData[8] =  (uint8_t)(G_8BKeyValue & 0x00FF);
		G_SendData[9] = 0;
	}
	else
	{
		G_SendData[7] = 0;
		G_SendData[8] = 0;
		G_SendData[9] = 0;
	}
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	�������ͨѶ   
*	@detail 	ȷ�������ϵͳ    
*/
/**********************************************************/
void cmd8B(void)
{
	uint8_t i;
	
	G_CmdNeedResponse = G_SendState.cmdReply;

	G_SendDataLength = 10;
	
	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] =  (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x8B;

	if (G_SendState.cmdType == CMD_TYPE_8B_KEY)
	{
		G_SendData[6] = (uint8_t)(G_8BKeyValue>>8);
		G_SendData[7] =  (uint8_t)(G_8BKeyValue & 0x00FF);
		G_SendData[8] = 0;
	}
	else
	{
		G_SendData[6] = 0;
		G_SendData[7] = 0;
		G_SendData[8] = 0;
	}
	
	
	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd16(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	
	G_SendDataLength = 11;

	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x16;

	if (G_SendState.cmdType == CMD_TYPE_16_INIT)
	{
		G_SendData[6] = 0xF5;
		G_SendData[7] = 0; 
		G_SendData[8] = 0;
		G_SendData[9] = 0;
	}
	else if (G_SendState.cmdType == CMD_TYPE_16_F1_F5)
	{
		G_SendData[6] = 0xF1;
		G_SendData[7] = G_ProCode;
		G_SendData[8] = 0xF5;
		G_SendData[9] = (uint8_t)G_ProData;
	}
	else if (G_SendState.cmdType == CMD_TYPE_16_F2_F5)
	{
		G_SendData[6] = 0xF2;
		G_SendData[7] = G_ProCode;
		G_SendData[8] = 0xF5;
		G_SendData[9] = (uint8_t)G_ProData;
	}
	else if (G_SendState.cmdType == CMD_TYPE_16_F5_F1)
	{
		G_SendData[6] = 0xF5;
		G_SendData[7] = G_ProCode;
		G_SendData[8] = 0xF1;
		G_SendData[9] = (uint8_t)G_ProData;
	}
	else if (G_SendState.cmdType == CMD_TYPE_16_F5_F2)
	{
		G_SendData[6] = 0xF5;
		G_SendData[7] = G_ProCode;
		G_SendData[8] = 0xF2;
		G_SendData[9] = (uint8_t)G_ProData;
	}

	
	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

void cmd17(void)
{
	uint8_t i;

	// �Ƿ���Ҫ����    
 	G_CmdNeedResponse = G_SendState.cmdReply;

	
	G_SendDataLength = 9;

	G_SendData[DATA_SA] = G_RemoAdd.add8.addL;
	G_SendData[DATA_DA] = G_MainAdd.add8.addL;
	G_SendData[DATA_CC] = 0x10+G_SendState.cmdReply+(G_SendState.cmdformat<<2);
	G_SendData[DATA_BC] = G_SendDataLength - 5;
	G_SendData[DATA_EA] = (G_RemoAdd.add8.addH<<4)+(G_MainAdd.add8.addH&0x0f);
	G_SendData[DATA_CMD] = 0x17;

	G_SendData[6] = G_ProCode;
	G_SendData[7] = (uint8_t)G_ProData;

	G_SendData[G_SendDataLength-1] = 0;
	for (i=0;i<G_SendDataLength-1;i++)
		G_SendData[G_SendDataLength-1] ^= G_SendData[i] ;
}

/**********************************************************/
/*
*	@brief 	��������ȷ��   
*	@detail 
*/
/**********************************************************/
void Vrf_SelfRecCheck(uint8_t rec_data)
{
	if (rec_data != G_SendNowData)
	{
		G_CmdSendEnable = 0;
		G_SendFlag &= ~(SEND_FLAG_BUSY+SEND_FLAG_WAIT_RES);
		G_QueueSendSpacing = Get_RandomDat();
		G_CmdNeedResponse = 0;
		Vrf_CmdJoinQueue(G_SendState.cmdType,G_SendState.cmdReply,G_SendState.cmdformat);
		G_CmdNeedResponse = 0;
	}
	else
	{
		G_SendSelfCheck = 1;
		G_ComAbnormalCount = 0;
		if (G_SendCount >= G_SendDataLength)
		{
			G_SendFlag &= ~SEND_FLAG_BUSY;
			G_RecCount = 0;
			
			if (G_TestStage==TEST_STAGE_VRF_COM)		// ��������   
				G_VrfComTestErr = 0;
		}
	}
}

/**********************************************************/
/*
*	@brief 	���ݽ��ջ��洦��    
*	@detail 
*/
/**********************************************************/
void Vrf_ComRecDeal(uint8_t rec_data)
{
	uint8_t i;
	G_RecDataTemp[G_RecCount] = rec_data;
	G_RecCount++;

	// �����Ƿ����   
	if (G_RecCount > 32)
	{
		ClearRecBuffer();
	}

	// �Ƿ���ܳ���3CHR   
	if (G_RecCount >= 3)
	{
		if (G_RecCount==3)
		{
			if ((G_RecDataTemp[DATA_CC]!=0x18)&&
				(G_RecDataTemp[DATA_CC]!=0x1C)&&
				(G_RecDataTemp[DATA_CC]!=0x10)&&
				(G_RecDataTemp[DATA_CC]!=0x58)&&
				(G_RecDataTemp[DATA_CC]!=0x5C)&&
				(G_RecDataTemp[DATA_CC]!=0x50)&&
				(G_RecDataTemp[DATA_CC]!=0x1A)&&
				(G_RecDataTemp[DATA_CC]!=0x12)&&
				(G_RecDataTemp[DATA_CC]!=0x11)&&
				(G_RecDataTemp[DATA_CC]!=0x15))
			{
				ClearRecBuffer();
			}
		}
		else if (G_RecCount >= G_RecDataTemp[DATA_BC]+5)
		{
			G_RecFinish = 1;
			for (i=0;i<32;i++)
				G_RecData[i] = G_RecDataTemp[i];
		}
	}
}

/**********************************************************/
/*
*	@brief 	�������    
*	@detail 
*/
/**********************************************************/
void ClearRecBuffer(void)
{
	uint8_t i;
	G_RecCount = 0;

	for (i=0;i<REC_DATA_NUM;i++)
		G_RecDataTemp[i] = 0;
	
}


/**********************************************************/
/*
*	@brief 	�̶�ʱ����δ������Ϣ�建��  
*	@detail 	ʱ��27ms   
*/
/**********************************************************/
void FitTimeClearRecBuffer(void)
{
	if (G_RecCount== 0)
		return;
	
	G_ClearBufferCount++;
		
	if (G_ClearBufferCount >= CLEAR_BUFFER_COUNT_27MS)
	{
		G_ClearBufferCount = 0;
		ClearRecBuffer();
	}
}

/**********************************************************/
/*
*	@brief 	������ɴ���    
*	@detail 
*/
/**********************************************************/
void Vrf_RecDataDeal(void)
{
	uint8_t i;
	uint8_t temp = 0;
	
	if (G_RecFinish == 0)
		return;
	
	G_RecFinish = 0;

	// FCC�����    
	for (i=0;i<G_RecData[DATA_BC]+4;i++)
		temp ^= G_RecData[i];
	if (temp !=G_RecData[G_RecData[DATA_BC]+4])
		return;

	if ((G_RecData[DATA_CC]==0x11)||(G_RecData[DATA_CC]==0x15))
	{
		Res_RemocJudge();
		return;
	}

	Res_Cmd06();
	Res_Cmd0D();
	Res_Cmd0A();
	Res_Cmd81();
	Res_Cmd0F();
	Res_Cmd0C();
	Res_Cmd10();
	Res_Cmd54();
	Res_Cmd08();
	Res_Cmd13();
	Res_Cmd45();
	Res_Cmd55();
	Res_cmd61();
	Res_cmd62();
	Res_Cmd02();
	Res_Cmd49();
	Res_Cmd2C();
	Res_Cmd67();
	Res_Cmd0E();
	Res_Cmd5F();
	Res_Cmd27();
	Res_Cmd18();
	Res_Cmd19();
	Res_Cmd8B();
	Res_Cmd16();
	Res_CmdA1();
	Res_CmdA2();
	Res_CmdA3();
	
}

void Res_RemocJudge(viod)
{
	if (G_KeyCount != 0)
		return;
	if (G_RemoRole == REMO_ROLE_MASTER)
	{
		if ((G_RecData[DATA_SA]==0x40)&&((G_RecData[DATA_EA]&0xF0)==0))
		{
			G_MasterErrorCount++;
			if (G_MasterErrorCount>=2)
			{
				G_MasterErrorCount = 0;
				if (G_ErrorCode == 0x00)
					G_ErrorCode = 0x49;
			}
		}
	}
}


/**********************************************************/
/*
*	@brief 	06ָ����մ���     
*	@detail 	�����ж��Ƿ�Ϊ�����    
*/
/**********************************************************/
void Res_Cmd06(void)
{
	uint8_t format_temp;
	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x06))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x06))
		return;


	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;  

	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		G_CmdNeedResponse = 0;
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;
		if (G_SendState.cmdType == CMD_TYPE_06_REQ_EXPAND)
		{
			
			G_ManualAddr = G_RecData[10]&0x3F;
			G_ManualAddrGetFlag = 1;
		}
		if (G_SendState.cmdType == CMD_TYPE_06_REQ)
		{
			if (G_SendFlag & SEND_FLAG_INIT)
			{
				G_SendFlag &= ~SEND_FLAG_INIT;
				G_SendFlag |= SEND_FLAG_OUTDOOR_INIT;
				G_InitCmdLevel = INIT_CMD_LEVEL1;
				G_InitSendRequest = 1;
				GuiTaskMode = OUTDOOR_NORMAL_TAST;

				G_SystemNumbel = G_RecData[7] - 0x80;
				
			}
		}
	}
	
}

/**********************************************************/
/*
*	@brief 	0Dָ����մ���   
*	@detail 	��ȡ��ַ    
*/
/**********************************************************/
void Res_Cmd0D(void)
{
	uint8_t i;
	uint8_t format_temp;
	
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x0D))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;  
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_0D)
			return;
		if (G_RecData[DATA_BC] != 0x12)
			return;

		G_MainAdd.add8.addH = G_RecData[DATA_CMD+1];
		G_MainAdd.add8.addL = G_RecData[DATA_CMD+2];
		
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4+G_RemoAdd.add8.addH)))
		{
			#if 0
			G_IndoorMacNum = 0;
			for (i=0;i<8;i++)
			{
				if ((G_RecData[DATA_CMD+2*i+1]!=0xFE)&&(G_RecData[DATA_CMD+2*i+2]!=0xFE))
				{
					G_IndoorMacNum++;	
				}
			}
			#endif

			G_SystemNumbel = (G_RecData[DATA_CMD+1]<<2)+(G_RecData[DATA_CMD+2]>>6) - 0x20;
			G_IndoorNumbel = (G_RecData[DATA_CMD+2]&0x3F);
			G_ProSendObj = PRO_SEND_OBJ_SINGLE;
				
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}
}

/**********************************************************/
/*
*	@brief 	0Aָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd0A(void)
{
	uint8_t temp;
	uint8_t format_temp;
	
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x0A))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;  

	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_0A)
			return;
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			if ((G_RecData[DATA_BC]==0x0D)||(G_RecData[DATA_BC]==0x0E))
			{

				// ���·������     
				if ((G_RecData[DATA_FL]&0x0F)==0)
				{
					G_UdWindDirGroup[SYSTEM_MODE_AUTO] = UD_WIND_DIR_GROUP_NO;
					G_UdWindDirGroup[SYSTEM_MODE_WARM] = UD_WIND_DIR_GROUP_NO;
					G_UdWindDirGroup[SYSTEM_MODE_COLD] = UD_WIND_DIR_GROUP_NO;
					G_UdWindDirGroup[SYSTEM_MODE_WET] = UD_WIND_DIR_GROUP_NO;
					G_UdWindDirGroup[SYSTEM_MODE_WIND] = UD_WIND_DIR_GROUP_NO;
				}
				else if ((G_RecData[DATA_FL]&0x0F)==1)
				{
					G_UdWindDirGroup[SYSTEM_MODE_AUTO] = UD_WIND_DIR_GROUP_ONLY_AUTO;
					G_UdWindDirGroup[SYSTEM_MODE_WARM] = UD_WIND_DIR_GROUP_ONLY_AUTO;
					G_UdWindDirGroup[SYSTEM_MODE_COLD] = UD_WIND_DIR_GROUP_ONLY_AUTO;
					G_UdWindDirGroup[SYSTEM_MODE_WET] = UD_WIND_DIR_GROUP_ONLY_AUTO;
					G_UdWindDirGroup[SYSTEM_MODE_WIND] = UD_WIND_DIR_GROUP_ONLY_AUTO;
				}
				else if ((G_RecData[DATA_FL]&0x0F)==2)
				{
					G_UdWindDirGroup[SYSTEM_MODE_AUTO] = UD_WIND_DIR_GROUP_5;
					G_UdWindDirGroup[SYSTEM_MODE_WARM] = UD_WIND_DIR_GROUP_5;
					G_UdWindDirGroup[SYSTEM_MODE_COLD] = UD_WIND_DIR_GROUP_3;
					G_UdWindDirGroup[SYSTEM_MODE_WET] = UD_WIND_DIR_GROUP_3;
					G_UdWindDirGroup[SYSTEM_MODE_WIND] = UD_WIND_DIR_GROUP_5;
				}
				else
				{
					G_UdWindDirGroup[SYSTEM_MODE_AUTO] = UD_WIND_DIR_GROUP_5;
					G_UdWindDirGroup[SYSTEM_MODE_WARM] = UD_WIND_DIR_GROUP_5;
					G_UdWindDirGroup[SYSTEM_MODE_COLD] = UD_WIND_DIR_GROUP_3;
					G_UdWindDirGroup[SYSTEM_MODE_WET] = UD_WIND_DIR_GROUP_3;
					G_UdWindDirGroup[SYSTEM_MODE_WIND] = UD_WIND_DIR_GROUP_5;
				}
			
				// ������ת��ģʽ    
				G_AllowMode = G_RecData[DATA_RS];

				// ���ټ����趨��3�ٻ���5��     
				if (G_RecData[DATA_FM]&(BIT3+BIT2+BIT1))
				{
					if (G_RecData[DATA_FM]&BIT4)
						G_WindSpeedGroup = WIND_SPEED_GROUP_5;
					else
						G_WindSpeedGroup = WIND_SPEED_GROUP_3;
				}
				else
					G_WindSpeedGroup = WIND_SPEED_GROUP_NO;

				G_ColdTempMax = (G_RecData[DATA_CT] - 70) / 2;
				G_ColdTempMin = (G_RecData[DATA_CB] - 70) / 2;
				G_WarmTempMax = (G_RecData[DATA_HT] - 70) / 2;
				G_WarmTempMin = (G_RecData[DATA_HB] - 70) / 2;
				G_WetTempMax = (G_RecData[DATA_DT] - 70) / 2;
				G_WetTempMin = (G_RecData[DATA_DB] - 70) / 2;
				G_AutoTempMax = (G_RecData[DATA_FT] - 70) / 2;
				G_AutoTempMin = (G_RecData[DATA_FB] - 70) / 2;

				if (G_RecData[DATA_BC] == 0x0E)
				{
					temp = G_RecData[DATA_FL2]>>4;
					if (temp == 0x03)
						G_LrWindDirGroup = LR_WIND_DIR_GROUP_5;
					else if (temp == 0x02)
						G_LrWindDirGroup = LR_WIND_DIR_GROUP_3;
					else
						G_LrWindDirGroup = LR_WIND_DIR_GROUP_NO;
				}
				
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
		}
	}
}

/**********************************************************/
/*
*	@brief 	81ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd81(void)
{
	uint8_t temp;
	uint8_t temp1;
	uint8_t format_temp;
	uint16_t remo_add,main_locat;
	
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x81))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	remo_add = G_RecData[DATA_DA]+((uint16_t)(G_RecData[DATA_EA]&0x0F)<<8);
	main_locat = G_RecData[DATA_SA] + ((uint16_t)(G_RecData[DATA_EA]&0xF0)<<4);
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if ((main_locat==G_MainAdd.add16)&&((remo_add==G_RemoAdd.add16)||(remo_add==0x0FE)))
		{
			
			if (G_SendState.cmdType != CMD_TYPE_81)
				return;
			

			// Ԥ��   
			G_Preheat = (G_RecData[DATA_D2]&BIT1)>>1;
			// nanoe�쳣     
			G_NanoeAb = (G_RecData[DATA_D12]&BIT5)>>5; 
			if (G_NanoeAb == 0)
				G_NanoeAbCnt = 0;
			// nanoe_g �쳣     
			G_NanoeGAb = (G_RecData[DATA_D12]&BIT7)>>7; 

			
			
			if (G_KeyCount != 0)
				return;
			
			
			// ��ת״̬    
			G_SystemStatus = G_RecData[DATA_D0] & BIT0;

			// �������ڻ�                   
			G_PrioIndoor =  (G_RecData[DATA_D0] & BIT1)>>1;	

			// ��תģʽ    
			temp = (G_RecData[DATA_D0]&(BIT5+BIT6+BIT7))>>5;
			switch (temp)
			{
				case 1:
					G_SystemMode = SYSTEM_MODE_WARM;
					break;
				case 2:
					G_SystemMode = SYSTEM_MODE_COLD;
					break;
				case 3:
					G_SystemMode = SYSTEM_MODE_WIND;
					break;
				case 4:
					G_SystemMode = SYSTEM_MODE_WET;
					break;
				case 5:
					G_AutoCold = AUTO_WARM;
					G_SystemMode = SYSTEM_MODE_AUTO;
					break;
				case 6:
					G_AutoCold = AUTO_COLD;
					G_SystemMode = SYSTEM_MODE_AUTO;
					break;
			}

			// ���·���    
			temp = (G_RecData[DATA_D0]&(BIT2+BIT3+BIT4))>>2;
			Parse_CmdWindDir(&G_WindDirUd[G_SystemMode],temp);

			// ����   
			G_FreshAir = (G_RecData[DATA_D1] & BIT2)>>2;

				

			// ��תģʽ�̶�     
			G_ModeFit = G_RecData[DATA_D1] & (BIT0+BIT1);

			//�Զ���   
			if (!(G_RecData[DATA_D1] & BIT3))
				G_AllowMode &= ~ALLOW_AUTO;
			else
				G_AllowMode |= ALLOW_AUTO;

			

			// ����ת��    
			G_TryRun = (G_RecData[DATA_D2]&BIT3)>>3;

			// ��������λ�ź�    
			G_FilterRstSign = (G_RecData[DATA_D2]&BIT7)>>7;


			// ���ؽ�ֹ��Ŀ                 
			G_CentralCtrBanFlag = G_RecData[DATA_D3];

			// ���ص�ַCA      
			G_CentralCtrAddr =  G_RecData[DATA_D6];

			// �趨�¶�   
			G_SystemTemp[G_SystemMode] = (G_RecData[DATA_D4] - 70) / 2; 

			// ����ʹ���е��¶�   
			G_StyleTempe =  G_RecData[DATA_D5]; 

			// ����      
			temp = G_RecData[DATA_D1] >> 5;
			temp1 = G_RecData[DATA_D12] & BIT0;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[G_SystemMode],temp,temp1);
			// �����ͳ�ǿ    
			if (G_RecData[DATA_D11]&BIT5)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_MUTE;
			}
			else if (G_RecData[DATA_D11]&BIT6)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_STRONG;
			}
			else
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
			}
			
			
			// �����еĻ���    
			G_WainingMachine = G_RecData[DATA_D7];

			// ����  
			G_SaveEnergy = G_RecData[DATA_D8] & BIT0;

			// econavi  
			if (G_RecData[DATA_D8] & BIT5)
				G_EconaviStatus= 1;
			else
				G_EconaviStatus = 0;

			// nanoe��ת״̬    
			if (G_RecData[DATA_D12]&(BIT3+BIT1))
				G_NanoeStatus = 1;
			else
				G_NanoeStatus = 0;

			// �ྻ��   
			G_Cleanning = (G_RecData[DATA_D12]&BIT4)>>4;

			

			// ���ҷ���    
			temp = (G_RecData[DATA_D13] & (BIT3+BIT4+BIT5))>>3;
			Parse_CmdWindDir(&G_WindDirLr[G_SystemMode], temp);

			if ((G_CmdNeedResponse == 1)&&(format_temp==CMD_FORMAT_REPLY))
			{
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}

		}
	}
	else if (format_temp==CMD_FORMAT_STATUS_CHANGE)
	{
		if ((main_locat==G_MainAdd.add16)&&((remo_add==G_RemoAdd.add16)||(remo_add==0x0FE)))
		{
			// Ԥ��   
			G_Preheat = (G_RecData[DATA_D2]&BIT1)>>1;
			// nanoe�쳣    
			G_NanoeAb = (G_RecData[DATA_D10]&BIT5)>>5;
			if (G_NanoeAb == 0)
				G_NanoeAbCnt = 0;
			// nanoe_g �쳣    
			G_NanoeGAb = (G_RecData[DATA_D10]&BIT7)>>7;
			

			
			if (G_KeyCount != 0)
				return;

			
			
			// ��ת״̬    
			if (G_SystemStatus != (G_RecData[DATA_D0]&BIT0))
			{
				G_SystemStatus = G_RecData[DATA_D0]&BIT0;
				// �׻��쳣E09   
				if (G_ErrorCode==0x49)
				{
					G_ErrorCode = 0;
				}
				G_MasterErrorCount = 0;
			}

			
			// �������ڻ�                   
			G_PrioIndoor =  (G_RecData[DATA_D0] & BIT1)>>1;	

			// ��תģʽ    
			temp = (G_RecData[DATA_D0]&(BIT5+BIT6+BIT7))>>5;
			switch (temp)
			{
				case 1:
					G_SystemMode = SYSTEM_MODE_WARM;
					break;
				case 2:
					G_SystemMode = SYSTEM_MODE_COLD;
					break;
				case 3:
					G_SystemMode = SYSTEM_MODE_WIND;
					break;
				case 4:
					G_SystemMode = SYSTEM_MODE_WET;
					break;
				case 5:
					G_AutoCold = AUTO_WARM;
					G_SystemMode = SYSTEM_MODE_AUTO;
					break;
				case 6:
					G_AutoCold = AUTO_COLD;
					G_SystemMode = SYSTEM_MODE_AUTO;
					break;
			}

			// ���·���    
			temp = (G_RecData[DATA_D0]&(BIT2+BIT3+BIT4))>>2;
			Parse_CmdWindDir(&G_WindDirUd[G_SystemMode],temp);

			// ����   
			G_FreshAir = (G_RecData[DATA_D1] & BIT2)>>2;

			// ��תģʽ�̶�     
			G_ModeFit = G_RecData[DATA_D1] & (BIT0+BIT1);

			//�Զ���   
			if (!(G_RecData[DATA_D1] & BIT3))
				G_AllowMode &= ~ALLOW_AUTO;
			else
				G_AllowMode |= ALLOW_AUTO;

			

			// ����ת��    
			G_TryRun = (G_RecData[DATA_D2]&BIT3) >> 3;

			// ����������    
			G_FilterRstSign = G_RecData[DATA_D2] & BIT7;

			// ���ؽ�ֹ��Ŀ                 
			G_CentralCtrBanFlag = G_RecData[DATA_D3];
			

			// �趨�¶�  
			G_SystemTemp[G_SystemMode] = (G_RecData[DATA_D4] - 70) / 2; 

			// ��˪   
			G_Defrost = (G_RecData[DATA_D5]&BIT4)>>4;
			
			// ����      
			temp = G_RecData[DATA_D1] >> 5;
			temp1 = G_RecData[DATA_D10] & BIT0;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[G_SystemMode],temp,temp1);
			// �����ͳ�ǿ    
			if (G_RecData[DATA_D9]&BIT5)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_MUTE;
			}
			else if (G_RecData[DATA_D9] & BIT6)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_STRONG;
			}
			else
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
			}
			

			// ����
			G_SaveEnergy = G_RecData[DATA_D6] & BIT0;

			// econavi  
			if (G_RecData[DATA_D6] & BIT5)
				G_EconaviStatus = 1;
			else
				G_EconaviStatus = 0;

			// nanoe��ת״̬    
			if (G_RecData[DATA_D10] & (BIT3+BIT1))
				G_NanoeStatus = 1;
			else
				G_NanoeStatus = 0;
			
			// �ྻ��   
			G_Cleanning = (G_RecData[DATA_D10]&BIT4)>>4;

			

			// ���ҷ���   
			temp = (G_RecData[DATA_D11] & (BIT3+BIT4+BIT5))>>3;
			Parse_CmdWindDir(&G_WindDirLr[G_SystemMode], temp);

			if ((G_CmdNeedResponse == 1)&&(format_temp==CMD_FORMAT_REPLY))
			{
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
			
		}
	}
}

/**********************************************************/
/*
*	@brief 	0Fָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd0F(void)
{
	uint8_t temp,temp1;
	uint8_t format_temp;
	
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x0F))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_0F)
			return;
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{

			
			// �¶�     
			G_SystemTemp[SYSTEM_MODE_AUTO] = (G_RecData[DATA_FET_1] - 70) / 2;
			G_SystemTemp[SYSTEM_MODE_WARM] = (G_RecData[DATA_FET_2] - 70) / 2;
			G_SystemTemp[SYSTEM_MODE_WET] = (G_RecData[DATA_FET_3] - 70) / 2;
			G_SystemTemp[SYSTEM_MODE_COLD] = (G_RecData[DATA_FET_4] - 70) / 2;

			// ů������     
			temp = G_RecData[DATA_FT_1] >> 4;
			temp1 = G_RecData[DATA_FT_EX] &BIT0;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[SYSTEM_MODE_WARM],temp,temp1);
			//�Զ�����     
			temp = G_RecData[DATA_FT_1]  & 0x0F;
			temp1 = (G_RecData[DATA_FT_EX]  & BIT4)>>4;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[SYSTEM_MODE_AUTO],temp,temp1);
			// �䷿����     
			temp = G_RecData[DATA_FT_2] >>4;
			temp1 = (G_RecData[DATA_FT_EX]  & BIT1)>>1;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[SYSTEM_MODE_COLD],temp,temp1);
			// ��ʪ����   
			temp = G_RecData[DATA_FT_2] &0x0F;
			temp1 = (G_RecData[DATA_FT_EX]  & BIT3)>>3;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[SYSTEM_MODE_WET],temp,temp1);
			// �ͷ����   
			temp = G_RecData[DATA_FT_3] &0x0F;
			temp1 = (G_RecData[DATA_FT_EX]  & BIT2)>>2;
			Parse_Cmd0FWindSpeed(&G_WindSpeed[SYSTEM_MODE_WIND],temp,temp1);

			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;

		}
	}

}

void Parse_Cmd0FWindSpeed(uint8_t *windspeed_temp,uint8_t level_temp, uint8_t strengthen_temp)
{
	switch (level_temp)
	{
		case 0:
		case 1:
		case 6:
		case 7:
			break;
		case 2:
			*windspeed_temp = WIND_SPEED_AUTO;
			break;
		case 3:
			*windspeed_temp = WIND_SPEED_LEVEL5;
			break;
		case 4:
			if (strengthen_temp)
				*windspeed_temp = WIND_SPEED_LEVEL4;
			else
				*windspeed_temp = WIND_SPEED_LEVEL3;
			break;
		case 5:
			if (strengthen_temp)
				*windspeed_temp = WIND_SPEED_LEVEL2;
			else
				*windspeed_temp = WIND_SPEED_LEVEL1;
			break;
	}
}


/**********************************************************/
/*
*	@brief 	0Cָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd0C(void)
{
	uint8_t temp;
	uint8_t format_temp;
	
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x0C))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			temp = G_RecData[DATA_BC];
			if ((G_RecData[temp+2]==0x30)&&(temp==9)&&(G_SendState.cmdType==CMD_TYPE_0C_0x30))
			{
				if (G_RecData[DATA_CMD+1]==0x00)
					G_TimerType = TIMER_TYPE_NO_SET;
				else if (G_RecData[DATA_CMD+1]==0x05)
					G_TimerType = TIMER_TYPE_ONCE_OFF;
				else if (G_RecData[DATA_CMD+1]==0x06)
					G_TimerType = TIMER_TYPE_CYCLE_OFF;
				else if (G_RecData[DATA_CMD+1]==0x07)
					G_TimerType = TIMER_TYPE_ONCE_ON;

				G_TimerHour = (uint16_t)G_RecData[DATA_CMD+2]*5;
				G_TimerRemainHour = (uint16_t)G_RecData[DATA_CMD+3]*5;
				G_TimerCount = (uint32_t)(G_TimerRemainHour*360);

				
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
			else if ((G_RecData[temp+2]==0x48)&&(temp==8)&&(G_SendState.cmdType==CMD_TYPE_0C_0x48))
			{
				G_FreshAirFunc = (G_RecData[DATA_CMD+1]&BIT1)>>1;
				G_EepromDat0x49 = G_RecData[DATA_CMD+2];
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
			else if ((G_RecData[temp+2]==0x4E)&&(temp==7)&&(G_SendState.cmdType==CMD_TYPE_0C_0x4E))
			{
				G_EepromDat0x4E = G_RecData[DATA_CMD+1];
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
			else if ((G_RecData[temp+2]==0x40)&&(temp==7)&&(G_SendState.cmdType==CMD_TYPE_0C_0x40))
			{
				G_EepromDat0x40 = G_RecData[DATA_CMD+1];
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
		}
	}

}


/**********************************************************/
/*
*	@brief 	10ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd10(void)
{
	uint8_t temp;
	uint8_t format_temp;
	
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x10))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_10)
			return;
		
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{

			
			// ���·���
			temp = (G_RecData[DATA_P1_1]>>4);
			Parse_CmdWindDir(&G_WindDirUd[SYSTEM_MODE_WET],temp);
			temp = (G_RecData[DATA_P1_1] & 0x0F);
			Parse_CmdWindDir(&G_WindDirUd[SYSTEM_MODE_WARM],temp);
			temp = (G_RecData[DATA_P1_2]>>4);
			Parse_CmdWindDir(&G_WindDirUd[SYSTEM_MODE_WIND],temp);
			temp = (G_RecData[DATA_P1_2] & 0x0F);
			Parse_CmdWindDir(&G_WindDirUd[SYSTEM_MODE_COLD],temp);


			// nanoe��������   
			G_NanoeFunc = G_RecData[DATA_P2]&BIT0;

			// econavi��������    
			G_EconaviFunc = (G_RecData[DATA_P2]&BIT3)>>3;
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}
}

void Parse_CmdWindDir(uint8_t *wind_dir,uint8_t dat)
{
	switch (dat)
	{
		case 0:
			//*wind_dir= WIND_DIR_UD_AUTO_STOP;
			break;
		case 1:
			*wind_dir= WIND_DIR_UD_AUTO;
			break;
		case 2:
			*wind_dir = WIND_DIR_UD_LEVEL1;
			break;
		case 3:
			*wind_dir = WIND_DIR_UD_LEVEL2;
			break;
		case 4:
			*wind_dir = WIND_DIR_UD_LEVEL3;
			break;
		case 5:
			*wind_dir = WIND_DIR_UD_LEVEL4;
			break;
		case 6:
			*wind_dir = WIND_DIR_UD_LEVEL5;
			break;
		default:
			*wind_dir = WIND_DIR_UD_AUTO_STOP;
			break;
	}
}

/**********************************************************/
/*
*	@brief 	54ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd54(void)
{
	uint8_t temp;
	uint8_t format_temp;


	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x54))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_54)
			return;
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{

			if (G_RecData[DATA_CMD+1] & BIT0)
				G_SaveEnergyFunc = 1;
			else
				G_SaveEnergyFunc = 0;
			
			if (G_RecData[DATA_CMD+1] & BIT1)
				G_SaveEnergy = 1;
			else
				G_SaveEnergy = 0;
			
			G_Cmd54Resend = 0;				// ������յ�Ӧ��֮����Ҫ���ط�     
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}

}


/**********************************************************/
/*
*	@brief 	08ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd08(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x08))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_08)
			return;
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}

}

/**********************************************************/
/*
*	@brief 	13ָ����մ���   
*	@detail 	wifi eeprom   
*/
/**********************************************************/
void Res_Cmd13(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x13))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_13)
			return;
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{

			eeprom_no_h = G_RecData[DATA_CMD+2];
			eeprom_no_l = G_RecData[DATA_CMD+3];
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}

}

/**********************************************************/
/*
*	@brief 	45ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd45(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x45))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_45)
			return;
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}
}

/**********************************************************/
/*
*	@brief 	55ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd55(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x55))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType != CMD_TYPE_55)
			return;
		
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
		}
	}
}

void Res_cmd61(void)
{
	uint8_t format_temp;
	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x61))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x61))
		return;

	if ((G_SendState.cmdType==CMD_TYPE_61)||(G_SendState.cmdType==CMD_TYPE_61_EXPAND))
		return;
	
	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if (format_temp == CMD_FORMAT_SETTING)
	{
		if ((GuiTaskMode == NORMAL_TAST) || (GuiTaskMode == OUTDOOR_NORMAL_TAST))
			GuiTaskMode = OTHER_REMO_SETTING_TAST;
	}
}

void Res_cmd62(void)
{
	uint8_t format_temp;
	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x62))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x62))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if (format_temp == CMD_FORMAT_SETTING)
	{
		if (GuiTaskMode == OTHER_REMO_SETTING_TAST)
		{
			G_WdtReset = 1;
			GuiTaskMode = RESET_TAST;
		}
	}

}

/**********************************************************/
/*
*	@brief 	02ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd02(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x02))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{


		if ((G_SendState.cmdType!=CMD_TYPE_02_F1)&&
			(G_SendState.cmdType!=CMD_TYPE_02_F2)&&
			(G_SendState.cmdType!=CMD_TYPE_02_F3)&&
			(G_SendState.cmdType!=CMD_TYPE_02_F4)&&
			(G_SendState.cmdType!=CMD_TYPE_02_F5)&&
			(G_SendState.cmdType!=CMD_TYPE_02_F7))
		{
			return;
		}
		
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;

			G_ProCode = G_RecData[DATA_DN];
			G_ProData = G_RecData[DATA_PM];
			G_ProDataUL = G_RecData[DATA_UL];
			G_ProDataLL = G_RecData[DATA_LL];
			G_ProDataA9 = G_RecData[DATA_A9];
			G_ProFlag = PRO_FLAG_CODE_SEND;
		}
	}
}

/**********************************************************/
/*
*	@brief 	49ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd49(void)
{
	uint8_t temp;
	uint8_t format_temp;
	uint8_t ex_flag;

	
	ex_flag = (G_RecData[DATA_CC]&BIT1)>>1;

	if ((!ex_flag) && (G_RecData[DATA_CMD]!=0x49))
		return;
		
	if ((ex_flag) && (G_RecData[DATA_CMD+3]!=0x49))
		return;
	

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if ((G_SendState.cmdType!=CMD_TYPE_49)&&(GuiTaskMode!=AUTO_ADDR_TAST))
			return;
		if (!ex_flag)
		{
			G_ErrorSystemNum =  (G_RecData[DATA_AU0]<<2)+(G_RecData[DATA_AU1]>>6) - 0x20;
			G_ErrorIndoorNum = G_RecData[DATA_AU1]&0x3F;
			G_ErrorCode = G_RecData[DATA_AN];
		}
		else
		{
			G_ErrorSystemNum =  (G_RecData[DATA_AU0+3]<<2)+(G_RecData[DATA_AU1+3]>>6) - 0x20;
			G_ErrorIndoorNum = G_RecData[DATA_AU1+3]&0x3F;
			G_ErrorCode = G_RecData[DATA_AN+3];
		}

		G_CmdNeedResponse = 0;
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;
	}
	else if (format_temp == CMD_FORMAT_STATUS_CHANGE)
	{
		if (!ex_flag)
		{
			G_ErrorSystemNum =  (G_RecData[DATA_AU0]<<2)+(G_RecData[DATA_AU1]>>6) - 0x20;
			G_ErrorIndoorNum = G_RecData[DATA_AU1]&0x3F;
			G_ErrorCode = G_RecData[DATA_AN];
		}
		else
		{
			G_ErrorSystemNum =  (G_RecData[DATA_AU0+3]<<2)+(G_RecData[DATA_AU1+3]>>6) - 0x20;
			G_ErrorIndoorNum = G_RecData[DATA_AU1+3]&0x3F;
			G_ErrorCode = G_RecData[DATA_AN+3];
		}

		G_CmdNeedResponse = 0;
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;
	}
}

/**********************************************************/
/*
*	@brief 	49ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd2C(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x2C))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x2C))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType==CMD_TYPE_2C_EXPAND)
		{
			if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
				&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
				&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
			{

				G_ServerRecFeedBack = 1;
				G_ServerCode = (uint16_t)(G_RecData[DATA_MON1])<<8;
				G_ServerCode += (uint16_t)G_RecData[DATA_MON2];

				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			}
		}
		else if (G_SendState.cmdType==CMD_TYPE_2C)
		{
			if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
				&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
				&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
			{

				G_ServerRecFeedBack = 1;
				G_ServerCode = (uint16_t)(G_RecData[6])<<8;
				G_ServerCode += (uint16_t)G_RecData[7];

				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			}
		}
	}
}

/**********************************************************/
/*
*	@brief 	�Զ���ַ����   
*	@detail 
*/
/**********************************************************/
void Res_Cmd67(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x67))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x67))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType!=CMD_TYPE_67_COMFIRM)
			return;

		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;

			if (G_RecData[9] == 0x00)
			{
				G_AutoAddrFlag |= AUTO_ADDR_FLAG_FINISH;
			}
		}
	}
}

/**********************************************************/
/*
*	@brief 	��̨ȷ��   
*	@detail 	�Զ���ַ�������ͨѶ��   
*/
/**********************************************************/
void Res_Cmd0E(void)
{
	uint8_t temp = 0;
	uint8_t format_temp;
	uint8_t i,j;

	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x0E))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x0E))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if (G_SendState.cmdType==CMD_TYPE_0E_EXPAND)
		{
			if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
				&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
				&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
			{
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;

				G_IndoorMacNum = 0;
				for (i=9;i<17;i++)
				{
					if (G_RecData[i]!=0)
					{
						for (j=0;j<8;j++)
						{
							if (G_RecData[i]&(1<<j))
							{
								G_LicIndoorNum[G_IndoorMacNum] = (i-9)*8 + j;
								G_IndoorMacNum++;
							}
						}
					}
				}
				G_ManualAddrStep = MANUAL_ADDR_STEP2;
				G_ManualCmdCnt = 0;
			}
		}
		else if (G_SendState.cmdType == CMD_TYPE_0E)
		{
			if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
				&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
				&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
			{
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;

				G_IndoorMacNum = 0;
				for (i=6;i<14;i++)
				{
					if (G_RecData[i]!=0)
					{
						for (j=0;j<8;j++)
						{
							if (G_RecData[i]&(1<<j))
							{
								G_LicIndoorNum[G_IndoorMacNum] = (i-9)*8 + j;
								G_IndoorMacNum++;
								if (temp == 0)
								{
									temp = 1;
									G_IndoorNumbel = (i-6)*8 + j;
								}
							}
						}
					}
				}

				if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT) 
					G_InitSendRequest = 1;
			}
		}
	}
}

/**********************************************************/
/*
*	@brief 	��������ǿ��wifiָ���     
*	@detail 	
*/
/**********************************************************/
void Res_Cmd5F(void)
{
	uint8_t temp;
	uint8_t format_temp;
	uint16_t remo_add,main_locat;
	uint16_t temp_16bit;

	
	if (G_RecData[DATA_CMD]!=0x5F)
		return;


	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	remo_add = G_RecData[DATA_DA]+((uint16_t)(G_RecData[DATA_EA]&0x0F)<<8);
	main_locat = G_RecData[DATA_SA] + ((uint16_t)(G_RecData[DATA_EA]&0xF0)<<4);
	if (((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))||(format_temp==CMD_FORMAT_STATUS_CHANGE))
	{

		G_CmdNeedResponse = 0;
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;

		

		temp = G_RecData[10] & BIT0;
		if (temp!=G_WifiState)
		{
			G_WifiResetState = 0;
			G_WifiState = temp;
			G_WifiCheckResult = WIFI_NO_CHECK;
			wifi_match_enable_write = 1;
		}

		temp_16bit = G_RecData[12];
		G_SucTempe = (uint8_t)((temp_16bit*5-350)/10);					// �����¶�    

		temp_16bit = G_RecData[13];
		G_TupingTempe1 = (uint8_t)((temp_16bit*5-350)/10);				// ����¶�1             
		
		temp_16bit = G_RecData[14];
		G_TupingTempe2 =  (uint8_t)((temp_16bit*5-350)/10);				// ����¶�2            
				
		if (G_SendFlag & SEND_FLAG_INIT)
			G_InitSendRequest = 1;
		
	}
}

/**********************************************************/
/*
*	@brief 	�쳣���뱨��ָ��             
*	@detail 	�쳣����           
*/
/**********************************************************/
void Res_Cmd27(void)
{
	uint8_t temp;
	uint8_t format_temp;
	uint16_t remo_add,main_locat;

	
	if (G_RecData[DATA_CMD]!=0x27)
		return;


	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	remo_add = G_RecData[DATA_DA]+((uint16_t)(G_RecData[DATA_EA]&0x0F)<<8);
	main_locat = G_RecData[DATA_SA] + ((uint16_t)(G_RecData[DATA_EA]&0xF0)<<4);
	if (((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))||(format_temp==CMD_FORMAT_STATUS_CHANGE))
	{

		G_CmdNeedResponse = 0;
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;

		// ���ڻ��쳣����Ҫ��ȡ���ڻ����������ַ  
		if (GuiTaskMode == ERROR_INDEX_TAST)		
		{
			G_ErrorIndexSysNum =  (G_RecData[DATA_CMD+1]<<2) + (G_RecData[DATA_CMD+2]>>6) - 0x20;		
			G_ErrorIndexIndoorNum = G_RecData[DATA_CMD+2]&0x3F;
		}
		// �쳣����    
		G_ErrorIndex = G_RecData[DATA_CMD+3];
	}
	
	
}


/**********************************************************/
/*
*	@brief 	��̨ȷ��   
*	@detail 	�Զ���ַ�������ͨѶ��   
*/
/**********************************************************/
void Res_Cmd18(void)
{
	uint8_t temp;
	uint8_t format_temp;
	uint8_t i;

	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x18))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x18))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		G_CmdNeedResponse = 0;
		G_SendFlag &= ~SEND_FLAG_WAIT_RES;
		if (G_SendState.cmdType == CMD_TYPE_18)
		{
			G_MainAdd.add8.addH = G_RecData[8] ;
			G_MainAdd.add8.addL = G_RecData[9] ;
			G_OutdoorMacNum = 0;
			for (i=0;i<8;i++)
			{
				if ((G_RecData[8+2*i]!=0xFE)&&(G_RecData[9+2*i]!=0xFE))
				{
					G_OutdoorMacNum++;	
				}
			}
			
			if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT) 
				G_InitSendRequest = 1;
		}	
	}
}

/**********************************************************/
/*
*	@brief 	������鱨   
*	@detail 	�Զ���ַ�������ͨѶ��   
*/
/**********************************************************/
void Res_Cmd19(void)
{
	uint8_t temp;
	uint8_t format_temp;
	uint8_t i;

	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x19))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x19))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if ((G_SendState.cmdType == CMD_TYPE_19_REG)||(G_SendState.cmdType == CMD_TYPE_19_KEY))
			{
				if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT) 
					G_InitSendRequest = 1;

				if ( G_RecData[6] < 6)							// �����ֻ��ʾ00 ~ 05����Ŀ          
				{
					G_OutdoorIndex = G_RecData[6];

					G_PointFlag = G_RecData[7];
					
					for (i = 0; i<8; i++)
					{
						G_OutdoorErrorCodeSeg[i] = G_RecData[9+i];
					}

				}
			}	
		}
	}
}

/**********************************************************/
/*
*	@brief 	������鱨   
*	@detail 	�Զ���ַ�������ͨѶ��   
*/
/**********************************************************/
void Res_Cmd8B(void)
{
	uint8_t temp;
	uint8_t format_temp;
	uint8_t i,j;

	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0x8B))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x8B))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if ((G_SendState.cmdType==CMD_TYPE_8B_REG)||(G_SendState.cmdType==CMD_TYPE_8B_KEY))
			{
				// ��ת�Ƶ�״̬   
				if (G_RecData[6] & BIT0)
					G_LedStatus = LED_STATUS_ON;
				else if (G_RecData[6] & BIT1)
					G_LedStatus = LED_STATUS_FLASH;
				else
					G_LedStatus = LED_STATUS_OFF;
			
				// ��תģʽ     
				if (G_RecData[7] & BIT0)
					G_SystemMode = SYSTEM_MODE_WARM;
				else if (G_RecData[7] & BIT1)
					G_SystemMode = SYSTEM_MODE_COLD;
				else if (G_RecData[7] & BIT2)
					G_SystemMode = SYSTEM_MODE_WIND;
				else if (G_RecData[7] & BIT3)
					G_SystemMode = SYSTEM_MODE_WET;

				// ����ת         
				if (G_RecData[7] & BIT4)
					G_TryRun = 1;
				else
					G_TryRun = 0;

				// ����    
				if (G_RecData[7] & BIT5)
					G_DoubleSpeed = 1;
				else 
					G_DoubleSpeed = 0;

				// �趨��   
				if (G_RecData[8] & BIT1)
					G_SettingFlag = 1;
				else
					G_SettingFlag = 0;

				G_OutdoorShowFlag |= SYSTEM_MODE_SHOW;
				// ��������ڻ�ͨѶ   
				if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT) 
				{
					G_InitSendRequest = 1;
				}
			}	
		}
	}
}

/**********************************************************/
/*
*	@brief 	16ָ����մ���   
*	@detail 
*/
/**********************************************************/
void Res_Cmd16(void)
{
	uint8_t temp;
	uint8_t format_temp;

	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0x16))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2; 
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{


		if ((G_SendState.cmdType!=CMD_TYPE_16_INIT)&&
			(G_SendState.cmdType!=CMD_TYPE_16_F1_F5)&&
			(G_SendState.cmdType!=CMD_TYPE_16_F2_F5)&&
			(G_SendState.cmdType!=CMD_TYPE_16_F5_F1)&&
			(G_SendState.cmdType!=CMD_TYPE_16_F5_F2))
		{
			return;
		}
		
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;

			G_ProCode = G_RecData[DATA_DN];
			G_ProData = G_RecData[DATA_PM];
			G_ProFlag = PRO_FLAG_CODE_SEND;
		}
	}
}

/**********************************************************/
/*
*	@brief 	A1ָ����մ���   
*	@detail 	ACK
*/
/**********************************************************/
void Res_CmdA1(void)
{
	uint8_t temp;
	uint8_t format_temp;
	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0xA1))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0xA1))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
				G_InitSendRequest = 1;
			
			if (GuiTaskMode == PRO_TAST)
			{
				if (G_SendState.cmdType==CMD_TYPE_64_START)
				{
					G_ProSendEnable = 1;
				}
			}
			else if (GuiTaskMode == AUTO_ADDR_TAST)
			{
				if (G_SendState.cmdType==CMD_TYPE_67_START)
				{
					G_AutoAddrFlag |= AUTO_ADDR_FLAG_HAVE;
				}
			}
			else if (GuiTaskMode == MANUAL_ADDR_TAST)
			{
				if (G_SendState.cmdType==CMD_TYPE_64_START_EXPAND)
				{
					G_ManualAddrStep = MANUAL_ADDR_STEP5;
					G_ManualCmdCnt = 0;
				}
			}
		}
	}

}

/**********************************************************/
/*
*	@brief 	A2ָ����մ���   
*	@detail 	NACK
*/
/**********************************************************/
void Res_CmdA2(void)
{
	uint8_t temp;
	uint8_t format_temp;
	
	if ((G_RecData[DATA_CC]&BIT1)&&(G_RecData[DATA_CMD+3]!=0xA2))
		return;
	if ((!(G_RecData[DATA_CC]&BIT1))&&(G_RecData[DATA_CMD]!=0xA2))
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			G_CmdNeedResponse = 0;
			G_SendFlag &= ~SEND_FLAG_WAIT_RES;
			if (G_SendFlag & SEND_FLAG_INIT)
			{
				if (G_SendState.cmdType == CMD_TYPE_45)
				{
					G_SaveEnergyFunc = 0;	
				}
				G_InitSendRequest = 1;
			}
		}
	}
}

/**********************************************************/
/*
*	@brief 	A3ָ����մ���   
*	@detail 	busy
*/
/**********************************************************/
void Res_CmdA3(void)
{
	uint8_t temp;
	uint8_t format_temp;
	
	if ((G_RecData[DATA_CMD]) != 0xA3)
		return;

	format_temp = (G_RecData[DATA_CC]&(BIT2+BIT3))>>2;
	if ((format_temp==CMD_FORMAT_REPLY)&&(G_CmdNeedResponse==1))
	{
	
		if ((G_RecData[DATA_SA]==G_MainAdd.add8.addL)
			&&(G_RecData[DATA_DA]==G_RemoAdd.add8.addL)
			&&(G_RecData[DATA_EA]==(G_MainAdd.add8.addH<<4 + G_RemoAdd.add8.addH)))
		{
			if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT)	// �������busyʱ��Ҫ���·���ָ��   
			{

			}
			else
			{
				G_CmdNeedResponse = 0;
				G_SendFlag &= ~SEND_FLAG_WAIT_RES;
				if (G_SendFlag & SEND_FLAG_INIT)
					G_InitSendRequest = 1;
			}
		}
	}

}

/**********************************************************/
/*
*	@brief 	VRFָ��Ͷ��л�ȡ    
*	@detail 
*/
/**********************************************************/
void Vrf_SendList(void)
{
	if (G_QueueSendSpacing>0)
		G_QueueSendSpacing--;
	else
	{
		if (G_SendFlag & SEND_FLAG_BUSY)
			return;
		if (Vrf_CmdTakeOutQueue(&G_SendState))
		{
			NOP();
			G_QueueSendSpacing = QUEUE_SEND_SPACING;
			Vrf_GetCmdData();
		}
	}
}

/**********************************************************/
/*
*	@brief 	�������   
*	@detail 
*/
/**********************************************************/
uint8_t Vrf_CmdJoinQueue(uint8_t cmd_type, uint8_t cmd_reply, uint8_t cmd_format)
{
	if (G_CmdListCount >= CMD_LIST_LENGTH)
		return 0;
	G_CmdList[G_CmdListCount].cmdType = cmd_type;
	G_CmdList[G_CmdListCount].cmdReply = cmd_reply;
	G_CmdList[G_CmdListCount].cmdformat = cmd_format;
	
	G_CmdListCount++;
	return 1;
}

/**********************************************************/
/*
*	@brief 	ȡ���������ݲ�ɾ��ȡ������   
*	@detail 
*/
/**********************************************************/
uint8_t Vrf_CmdTakeOutQueue(struct_send_data_type *cmd_type_temp)
{
	uint8_t i;
	if (G_CmdListCount==0)
		return 0;

	*cmd_type_temp = G_CmdList[0];

	G_CmdListCount--;
	if (G_CmdListCount>0)
	{
		for (i=0; i<G_CmdListCount; i++)
			G_CmdList[i] = G_CmdList[i+1];
	}

	return 1;
}

/**********************************************************/
/*
*	@brief 	���    
*	@detail 
*/
/**********************************************************/
void Vrf_CmdJumpQueue(uint8_t cmd_type, uint8_t cmd_reply, uint8_t cmd_format)
{
	uint8_t i;
	uint8_t j;

	G_CmdListCount++;

	if (G_CmdListCount>=5)
	{
		for (i=4;i>0;i--)
		{
			G_CmdList[i] = G_CmdList[i-1];
		}
		G_CmdListCount = 5;
	}
	else if (G_CmdListCount > 0)
	{
		for (i=G_CmdListCount-1;i>0;i--)
		{
			G_CmdList[i] = G_CmdList[i-1];
		}
	}

	G_CmdList[0].cmdType= cmd_type;
	G_CmdList[0].cmdReply = cmd_reply;
	G_CmdList[0].cmdformat = cmd_format;
}

/**********************************************************/
/*
*	@brief 	��ն���   
*	@detail 
*/
/**********************************************************/
void Vrf_CmdClearQueue(void)
{
	G_CmdListCount = 0;
}

/**********************************************************/
/*
*	@brief 	��ȡ�����   
*	@detail 
*/
/**********************************************************/
uint16_t Get_RandomDat(void)
{
	uint16_t temp;

	temp = TCR02;
	temp %= 8;
	
	return G_ErrorTimeTable[temp];
}


void Vrf_TempSendDeal(void)
{
	if (G_VrfTempSendFlag)
	{
		G_VrfTempSendCount++;
		if (G_VrfTempSendCount>=VRF_TEMP_COUNT)
		{
			G_VrfTempSendCount = 0;
			G_VrfTempSendFlag = 0;
			Vrf_CmdJoinQueue(CMD_TYPE_4C_TEMPE,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		}
	}
}


