#ifndef _MAIN_H
#define _MAIN_H

#ifdef _EXTERN_MAIN_H_
#define EXT_MAIN
#else
#define EXT_MAIN extern
#endif

#define BS(a,b)				a |= (1<<b)
#define BC(a,b)				a &= ~(1<<b)
#define Judge_Bit(a,b) 	(a & (1<<b))

/************************/
typedef enum
{
	BIT0 = 0x01,
	BIT1 = 0x02,
	BIT2 = 0x04,
	BIT3 = 0x08,
	BIT4 = 0x10,
	BIT5 = 0x20,
	BIT6 = 0x40,
	BIT7 = 0x80,
}enum_bit_type;

/************************/
typedef struct
{
    unsigned char  b0:1;
    unsigned char  b1:1;
    unsigned char  b2:1;
    unsigned char  b3:1;
    unsigned char  b4:1;
    unsigned char  b5:1;
    unsigned char  b6:1;
    unsigned char  b7:1;
	unsigned char  b8:1;
	unsigned char  b9:1;
	unsigned char  b10:1;
	unsigned char  b11:1;
	unsigned char  b12:1;
	unsigned char  b13:1;
	unsigned char  b14:1;
	unsigned char  b15:1;
} struct_bit_type;


/********************/
/*
**	G_SystemScanFlag
*/
/****************/
enum
{
	SYSTEM_SCAN_FLAG_1MS = BIT0,
	SYSTEM_SCAN_FLAG_10MS = BIT1,
	SYSTEM_SCAN_FLAG_500MS = BIT2,
	SYSTEM_SCAN_FLAG_UART = BIT3,
};

#define		SOFTWARE_VERSION		327


EXT_MAIN uint8_t G_SystemScanFlag;
EXT_MAIN uint8_t G_WdtReset;


void System_ScanProcess(void);
void WDT_Process(void);
void System_ScanCount(void);


#endif


