#ifndef _UART_H_
#define _UART_H_

#ifdef _EXTERN_UART_H_
#define EXT_UART
#else
#define EXT_UART extern
#endif

#define RECEIVE_BUFFER_LENGTH		40
typedef struct
{
	uint8_t buffer[RECEIVE_BUFFER_LENGTH];
	uint8_t bufferHead;
	uint8_t bufferTail;
	uint8_t bufferCount;
}struct_receive_type;

enum
{
	TX1_SEND_FREE_FLAG = 0,
	TX1_SEND_BUSY_FLAG = 1,
};

EXT_UART struct_receive_type G_Rx0RecDat;
EXT_UART struct_receive_type G_Rx1RecDat;
EXT_UART uint8_t G_Tx1SendBusy;

uint8_t PutUartReceiveDat(uint8_t dat, struct_receive_type *rec_dat);
uint8_t GetUartReceiveDat(uint8_t *dat,struct_receive_type *rec_dat);
uint8_t uart0_send(uint8_t const dat);
void Tx1_SendPocess(void);
#endif

