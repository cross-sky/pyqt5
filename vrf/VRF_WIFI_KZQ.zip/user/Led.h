#include "r_cg_macrodriver.h"

#ifndef _LED_H
#define _LED_H

#ifdef _EXTERN_LED_H_
#define EXT_LED
#else
#define EXT_LED extern
#endif

typedef struct
{
	uint16_t count;
	uint8_t level;
	uint8_t levelChange;
	uint8_t state;
	uint8_t lightTime;
}struct_led_type;

// ���⿪��   
enum
{
	LIGHT_OFF,
	LIGHT_ON,
};

// ��������   
enum
{
	BL_LIGHT_LEVEL_LOW,
	BL_LIGHT_LEVEL_MID,
	BL_LIGHT_LEVEL_HIGH,
	
};

// �������ʱ��   
enum
{
	LIGHT_TIME_0S = 0,
	LIGHT_TIME_5S = 5,
	LIGHT_TIME_10S = 10,
	LIGHT_TIME_15S = 15,
	LIGHT_TIME_20S = 20,
};

// led����   
enum
{
	LED_LIGHT_LEVEL1 = 1,
	LED_LIGHT_LEVEL2,
	LED_LIGHT_LEVEL3,
	LED_LIGHT_LEVEL4,
	LED_LIGHT_LEVEL5,
	LED_LIGHT_LEVEL6,
	LED_LIGHT_LEVEL7,
	LED_LIGHT_LEVEL8,
	LED_LIGHT_LEVEL9,
	LED_LIGHT_LEVEL10,
};

#define	BL_TURN_ON_HIGH()		{P12.5=1;P12.7=1;}
#define	BL_TURN_ON_MID()		{P12.5=0;P12.7=1;}
#define	BL_TURN_ON_LOW()		{P12.5=1;P12.7=0;}
#define	BL_TURN_OFF()			{P12.5=0;P12.7=0;}

EXT_LED struct_led_type G_Led;
EXT_LED struct_led_type G_BL;

void Led_RegInit(void);
void Led_RamInit(void);
void Led_Process(void);
void PowerLight_On(void);
void PowerLight_Off(void);
void Led_PowerLightDeal(void);
void BL_On(void);
void BL_Off(void);
void Led_BackLightDeal(void);
void BL_Count(void);

#endif
