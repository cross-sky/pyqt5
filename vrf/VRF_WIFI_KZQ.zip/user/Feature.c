#define _EXTERN_FEATURE_H_

#include "Common.h"

const uint8_t G_VrfTsDatTb[5]="TEST";

/**************************************************************/
/**
*	@brief	������ʼ��      
*/
/**************************************************************/
void System_RamInit(void)
{

	delay_ms(500);
	G_TouchWriteFlag = 1;
	G_TouchLevel = 0;
	Key_ConfWrite();


	System_EepromDataInit();				// �����ȡ   

	Led_RamInit();							// LED�ͱ����ʼ��    
	G_SystemStatusFunc = 1;				// ���ػ���Ч    
	G_RegularComCnt = 5;					// ��һ�ζ���ͨѶ��ʱ��    
	G_SendFlag |= SEND_FLAG_INIT;			// ����ͨѶ    
	G_InitSendRequest = 1;				// ����ͨѶ���ʹ���    
	G_InitCmdLevel = INIT_CMD_LEVEL0;		// ����ͨѶ��һ������    
	G_RemoMode = REMO_MODE_NORMAL;			// ң�����趨�����е�01��Ŀ��ʼֵ    
	
}

/**************************************************************/
/**
*	@brief	�������趨����      
*/
/**************************************************************/
void Key_DetailProSetDeal(void)
{
	if ((GuiTaskMode==NORMAL_TAST)||(GuiTaskMode==OUTDOOR_NORMAL_TAST))
	{
		if (G_KeyDownType == KEY_TYPE_5S)
		{
			G_ProSetting = PRO_SETTING_LEVEL1;
			G_ProSendEnable = 1;
			G_SystemStatus = SYSTEM_STATUS_OFF;	
			if (GuiTaskMode==NORMAL_TAST)
				G_ProType = PRO_TYPE_DETAIL;
			else
				G_ProType = PRO_TYPE_OUTDOOR_DETAIL;
			G_ProStep = 1;					// ��Ŀ��������    
			G_ProCmdCount = 0;				// ��Ŀָ��ͼ���   
			G_ProCode = 0;					// ��Ŀ����  
			G_ProFlag = 0;
			Vrf_ClearSend();
			Buzzer_KeySoundEnable();
			GuiTaskMode = PRO_TAST;
		}
	}
	
}

/**************************************************************/
/**
*	@brief	�������趨����      
*/
/**************************************************************/
void Key_SimpleProSetDeal(void)
{
	if (GuiTaskMode != NORMAL_TAST)
		return;
	if (G_KeyDownType == KEY_TYPE_5S)
	{
		G_ProSetting = PRO_SETTING_LEVEL1;
		G_ProSendEnable = 1;
		G_SystemStatus = SYSTEM_STATUS_OFF;	
		G_ProType = PRO_TYPE_SIMPLE;
		G_ProStep = 1;					// ��Ŀ��������    
		G_ProCmdCount = 0;				// ��Ŀָ��ͼ���   
		G_ProCode = 0;					// ��Ŀ����  
		G_ProFlag = 0;
		GuiTaskMode = PRO_TAST;
		Vrf_ClearSend();
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	�������ģʽ   
*/
/**************************************************************/
void Key_Check(void)
{
	if (GuiTaskMode != NORMAL_TAST)
		return;
	if (G_KeyDownType == KEY_TYPE_3S)
	{
		G_TestMode = 1;
		GuiTaskMode = TEST_TAST;
		Vrf_ClearSend();
		Buzzer_Enable(1,100);
	}
}

/**************************************************************/
/**
*	@brief	ң�����趨����   
*/
/**************************************************************/
void Key_RemoSetFunction(void)
{
	if (GuiTaskMode != NORMAL_TAST)
		return;

	if (G_KeyDownType == KEY_TYPE_5S)
	{
		GuiTaskMode = REMO_SET_TAST;
		
		G_RemoFunSet = REMO_FUN_SET_PROJECT;			// ��Ŀ�趨  
		G_RemoFunStage = REMO_FUN_STAGE_REMO_ADDR;		// �趨����Ŀ  

		// ��Ŀ�趨�滺��   
		G_RemoRoleBack = G_RemoRole;			
		G_RemoModeBack = G_RemoMode;			
		G_ServerRoleBack = G_ServerRole;	
		G_BLTimeLevelBack = G_BLTimeLevel;
		G_BLLevelBack = G_BL.level;
		G_LedLevelBack = G_Led.level;
		G_BzModeBack = G_BzMode;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	�����쳣����    
*/
/**************************************************************/
void Key_ErrorIndex(void)
{
	if ((GuiTaskMode != NORMAL_TAST)&&(GuiTaskMode!=OUTDOOR_NORMAL_TAST))
		return;
		
	if (G_KeyDownType == KEY_TYPE_5S)
	{
		if (G_ErrorCheck==1)
			return;
			
		if (GuiTaskMode == NORMAL_TAST)
			GuiTaskMode = ERROR_INDEX_TAST;
		else
			GuiTaskMode = OUTDOOR_ERROR_INDEX_TAST;

			
		G_ErrorCheck = 1;
		G_ErrorObj = 0;
		
		G_ErrorIndexSysNum = 0;
		G_ErrorIndexIndoorNum = 0;
		G_ErrorIndex = 0;
		Vrf_CmdJoinQueue(CMD_TYPE_27, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	�������ģʽ������������״̬    
*/
/**************************************************************/
void Key_ServerIndex(void)
{
	if ((GuiTaskMode != NORMAL_TAST)&&(GuiTaskMode!=OUTDOOR_NORMAL_TAST))
		return;

	if (G_KeyDownType == KEY_TYPE_5S)
	{
		if (G_SendFlag & SEND_FLAG_INIT)		// ���ڻ�   
			return;
		if (G_ServerCheck==1)
			return;
			
		if (GuiTaskMode == NORMAL_TAST)
			GuiTaskMode = SERVER_INDEX_TAST;
		else
			GuiTaskMode = OUTDOOR_SERVER_INDEX_TAST;
			
		G_ServerCheck = 1;
		G_ServerObj = 0;
		
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	�������ģʽ������������״̬    
*/
/**************************************************************/
void Key_AutoAddr(void)
{
	if (GuiTaskMode != NORMAL_TAST)
		return;
	if (G_KeyDownType == KEY_TYPE_5S)
	{
		//if (G_SendFlag & SEND_FLAG_INIT)		// ���ڻ�   
			//return;
		if (G_AutoAddrSet!=AUTO_ADDR_NO_SET)
			return;

		G_ErrorCode = 0;
		GuiTaskMode = AUTO_ADDR_TAST;
		G_AutoAddrSet = AUTO_ADDR_SET_TYPE;
		G_AutoAddrType = AUTO_ADDR_AA;
		G_SystemType = SYSTEM_TYPE_MIN;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	 �ֶ����õ�ַ   
*/
/**************************************************************/
void Key_ManualAddr(void)
{
	if (GuiTaskMode != NORMAL_TAST)
		return;
	
	if (G_KeyDownType == KEY_TYPE_5S)
	{
		if (G_SendFlag & SEND_FLAG_INIT)		// ���ڻ�   
			return;

		if (G_ManualAddrSet)
			return;

		GuiTaskMode = MANUAL_ADDR_TAST;
		G_ManualAddrSet = MANUAL_ADDR_SET_SYSTEM;
		G_ManualSystemNum = 0;
		G_ManualIndoorNum = 0;
		G_ManualAddrGetFlag = 0;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	 �ֶ����õ�ַ   
*/
/**************************************************************/
void ManualAddr_Process(void)
{
	if (GuiTaskMode != MANUAL_ADDR_TAST)
		return;
	
	if (G_ManualAddrSend == 0)
		return;
	G_ManualAddrSend = 0;

	switch (G_ManualAddrSet)
	{
		case MANUAL_ADDR_SET_INDOOR:
			if (G_ManualAddrStep == MANUAL_ADDR_STEP1)
			{
				if (G_ManualCmdCnt == 0)
				{
					G_ManualCmdCnt++;
					Vrf_CmdJoinQueue(CMD_TYPE_0E_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				}
			}
			else if (G_ManualAddrStep == MANUAL_ADDR_STEP2)
			{
				if (G_ManualCmdCnt<3)
				{
					G_ManualCmdCnt++;
					Vrf_CmdJoinQueue(CMD_TYPE_61_EXPAND, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				}
				if (G_ManualCmdCnt>=3)
				{
					G_ManualCmdCnt = 0;
					G_ManualAddrStep = MANUAL_ADDR_STEP3;
				}
			}
			else if (G_ManualAddrStep == MANUAL_ADDR_STEP3)
			{
				if (G_ManualCmdCnt<3)
				{
					G_ManualCmdCnt++;
					G_ManualAddrGetFlag = 0;
					Vrf_CmdJoinQueue(CMD_TYPE_64_STOP_EXPAND, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				}
				if (G_ManualCmdCnt>=3)
				{
					G_ManualCmdCnt = 0;
					G_ManualAddrStep = MANUAL_ADDR_STEP4;
				}
			}
			else if (G_ManualAddrStep == MANUAL_ADDR_STEP4)
			{
				if (G_ManualCmdCnt == 0)
				{
					G_ManualCmdCnt++;
					Vrf_CmdJoinQueue(CMD_TYPE_64_START_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
			}
			else if (G_ManualAddrStep == MANUAL_ADDR_STEP5)
			{
				if (G_ManualCmdCnt == 0)
				{
					G_ManualCmdCnt++;
					Vrf_CmdJoinQueue(CMD_TYPE_06_REQ_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				}
			}	
			break;
		case MANUAL_ADDR_SET_ADDR:
		case MANUAL_ADDR_SET_FINISH:
			if (G_ManualCmdCnt==0)
			{
				G_ManualCmdCnt++;
				Vrf_CmdJoinQueue(CMD_TYPE_06_SET_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			break;
		case MANUAL_ADDR_EXIT:
			if (G_ManualAddrStep == 0)
			{
				Vrf_CmdJoinQueue(CMD_TYPE_63_EXPAND, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				G_ManualCmdCnt++;
				if (G_ManualCmdCnt>=3)
				{
					G_ManualCmdCnt = 0;
					G_ManualAddrStep++;
				}
			}
			else if (G_ManualAddrStep == 1)
			{
				Vrf_CmdJoinQueue(CMD_TYPE_62_EXPAND, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				G_ManualCmdCnt++;
				if (G_ManualCmdCnt>=3)
				{
					G_ManualCmdCnt = 0;
					GuiTaskMode = RESET_TAST;
					G_WdtReset = 1;
					G_ManualAddrSet = 0;
				}
			}
			break;
	}
}

/**************************************************************/
/**
*	@brief	 
*/
/**************************************************************/
void ManualAddr_FitSend(void)
{
	if (GuiTaskMode != MANUAL_ADDR_TAST)
		return;
	
	G_ManualSendTime++;
	if (G_ManualSendTime>=50)
	{
		G_ManualSendTime = 0;
		G_ManualAddrSend = 1;
	}

}


/**************************************************************/
/**
*	@brief	�Զ���ַ�趨����   
*/
/**************************************************************/
void AutoAddr_Process(void)
{
	if (G_AutoAddrSet == 0)
		return;

	if (G_AutoAddrSend == 0)
		return;
	G_AutoAddrSend = 0;
	
	switch (G_AddrSetStep)
	{
		case ADDR_SET_STEP_STOP_RUN:
			Vrf_CmdJoinQueue(CMD_TYPE_61_EXPAND,CMD_NO_REPLY, CMD_FORMAT_SETTING);
			G_AddrComSendCnt++;
			if (G_AddrComSendCnt >= 5)
			{
				G_AddrComSendCnt = 0;
				G_AddrSetStep = ADDR_SET_STEP_AUTO_SYSTEM;
			}
			break;
		case ADDR_SET_STEP_AUTO_SYSTEM:
			if (G_AddrComSendCnt<5)
			{
				Vrf_CmdJoinQueue(CMD_TYPE_67_START, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				G_AddrComSendCnt++;
			}
			else 
			{
				G_AddrComSendCnt = 0;
				AutoAddr_StopJudge();
			}
			break;
		case ADDR_SET_STEP_QUERY:
			Vrf_CmdJoinQueue(CMD_TYPE_67_COMFIRM, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			break;
		case ADDR_SET_STEP_RESET:
			Vrf_CmdJoinQueue(CMD_TYPE_62_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			G_AddrComSendCnt++;
			if (G_AddrComSendCnt >= 3)
			{
				G_AutoAddrSet = 0;
				G_WdtReset = 1;
				GuiTaskMode = RESET_TAST;
			}
			break;
	}

}

/**************************************************************/
/**
*	@brief	�Զ���ַ�Ƿ�������ж�    
*/
/**************************************************************/
void AutoAddr_StopJudge(void)
{
	if (G_AutoAddrType == AUTO_ADDR_AA)
	{
		if (G_SystemType == SYSTEM_TYPE_MAX)
		{
			G_AddrSetStep = ADDR_SET_STEP_RESET;
			G_AddrSendTime = 0;
			GuiTaskMode = RESET_TAST;
		}
		else
		{
			G_SystemType++;
			G_AddrComSendCnt = 0;
			G_AddrSetStep = ADDR_SET_STEP_AUTO_SYSTEM;
			G_AddrSendTime = 0;
		}
	}
	else if (G_AutoAddrType == AUTO_ADDR_A1)
	{
		G_AddrSetStep = ADDR_SET_STEP_RESET;
		G_AddrSendTime = 0;
		GuiTaskMode = RESET_TAST;
	}
}

/**************************************************************/
/**
*	@brief	�Զ���ַ�̶�ʱ�䷢��    
*	@detail	10ms����һ��   
*/
/**************************************************************/
void AutoAddr_FitSend(void)
{
	if (G_AutoAddrSet == 0)
		return;
	
	if (G_AutoAddrSet != AUTO_ADDR_SET_WAIT)
		return;

	switch (G_AddrSetStep)
	{
		case ADDR_SET_STEP_STOP_RUN:
			G_AddrSendTime++;
			if (G_AddrSendTime >= 50)
			{
				G_AddrSendTime = 0;
				G_AutoAddrSend = 1; 
			}
			break;
		case ADDR_SET_STEP_AUTO_SYSTEM:
			if (G_AutoAddrFlag & AUTO_ADDR_FLAG_HAVE)
			{
				G_AutoAddrFlag = 0;
				
				G_AddrSetStep = ADDR_SET_STEP_QUERY;
				G_AutoAddrSend = 1;
				G_AddrSendTime = 0;
			}
			else
			{
				G_AddrSendTime++;
				if (G_AddrSendTime >= 50)
				{
					G_AddrSendTime = 0;
					G_AutoAddrSend = 1; 
				}
			}
			break;
		case ADDR_SET_STEP_QUERY:
			if (G_AutoAddrFlag & AUTO_ADDR_FLAG_FINISH)
			{
				G_AutoAddrFlag = 0;
				AutoAddr_StopJudge();
			}
			else
			{
				G_AddrSendTime++;
				if (G_AddrSendTime >= 1500)
				{
					G_AddrSendTime = 0;
					G_AutoAddrSend = 1; 
				}
			}
			break;
		case ADDR_SET_STEP_RESET:
			G_AddrSendTime++;
			if (G_AddrSendTime >= 50)
			{
				G_AddrSendTime = 0;
				G_AutoAddrSend = 1; 
			}
			break;
	}
}

/**************************************************************/
/**
*	@brief	�������趨����      
*	@detail	ָ���    
*/
/**************************************************************/
void Pro_EnterOrExitSet(void)
{
	if (G_ProSendEnable == 0)
		return;
	G_ProSendEnable = 0;
		
	if (G_ProSetting==PRO_SETTING_LEVEL1)
	{
		switch(G_ProStep)
		{
			case 1:
				Vrf_CmdJoinQueue(CMD_TYPE_61, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				G_ProCmdCount++;
				if (G_ProCmdCount>=3)
				{
					G_ProCmdCount = 0;
					G_ProStep = 2;
				}
				break;
			case 2:
				Vrf_CmdJoinQueue(CMD_TYPE_64_STOP, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				G_ProCmdCount++;
				if (G_ProCmdCount>=5)
				{
					G_ProCmdCount = 0;
					G_ProStep = 3;
				}
				break;
			case 3:
				Vrf_CmdJoinQueue(CMD_TYPE_64_START, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				G_ProCmdCount = 1;
				G_ProStep = 4;
				break;
			case 4:
				if (G_ProType == PRO_TYPE_DETAIL)
				{
					Vrf_CmdJoinQueue(CMD_TYPE_02_F5, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				}
				else if (G_ProType == PRO_TYPE_SIMPLE)
				{
					Vrf_CmdJoinQueue(CMD_TYPE_02_F7, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				}
				else if (G_ProType == PRO_TYPE_OUTDOOR_DETAIL)
				{
					Vrf_CmdJoinQueue(CMD_TYPE_16_INIT, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				}
				G_ProStep = 0;
				G_ProFlag = 0;
				break;
		}
	}
	else if (G_ProSetting == PRO_SETTING_LEVEL3)
	{
		switch (G_ProStep)
		{
			case 1:
				Vrf_CmdJoinQueue(CMD_TYPE_62_EEP_EX, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				G_ProCmdCount++;
				if (G_ProCmdCount>=3)
				{
					G_ProCmdCount = 0; 
					G_ProStep = 2;
				}
				break;
			case 2:
				Vrf_CmdJoinQueue(CMD_TYPE_62, CMD_NO_REPLY, CMD_FORMAT_SETTING);
				G_ProCmdCount++;
				if (G_ProCmdCount>=3)
				{
					G_ProCmdCount = 0; 
					G_ProStep = 0;
					G_ProSetting = 0;
					G_WdtReset = 1;
				}
				break;
		}
	}
}

/**************************************************************/
/**
*	@brief	�������趨����      
*	@detail	ָ��ͼ�ʱ    
*/
/**************************************************************/
void Pro_InitStepCount(void)
{
	static uint8_t count_500ms_temp = 0; 

	if (G_ProSetting==PRO_NO_SET)
		return;

	count_500ms_temp++;
	if (count_500ms_temp>=50)
	{
		count_500ms_temp = 0;
		if (G_ProSetting == PRO_SETTING_LEVEL1)
		{
			if (G_ProStep<=3)
				G_ProSendEnable = 1;
		}
		else if (G_ProSetting == PRO_SETTING_LEVEL3)
		{
			G_ProSendEnable = 1;
		}
	}
}


/**************************************************************/
/**
*	@brief	������ �ϼ� ����       
*/
/**************************************************************/
void FunctionArea6_KeyUp(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		switch (G_FunctionType)
		{
			case FUNCTION_NANOE:
				G_FunctionType = FUNCTION_TRY_RUN;
				break;
			case FUNCTION_ECONAVI:
				if (G_NanoeFunc)
					G_FunctionType = FUNCTION_NANOE;
				else
					G_FunctionType = FUNCTION_TRY_RUN;
				break;
			case FUNCTION_SAVE_POWER:
				if (G_EconaviFunc)
					G_FunctionType = FUNCTION_ECONAVI;
				else
				{
					if (G_NanoeFunc)
						G_FunctionType = FUNCTION_NANOE;
					else
					{
						G_FunctionType = FUNCTION_TRY_RUN;
					}
				}
				break;
			case FUNCTION_FRESH_AIR:
				if (G_SaveEnergyFunc)
				{
					G_FunctionType = FUNCTION_SAVE_POWER;
				}
				else
				{
					if (G_EconaviFunc)
						G_FunctionType = FUNCTION_ECONAVI;
					else
					{
						if (G_NanoeFunc)
							G_FunctionType = FUNCTION_NANOE;
						else
						{
							G_FunctionType = FUNCTION_TRY_RUN;
						}
					}
				}
				break;
			case FUNCTION_TIMER:
				if (G_TimerSet == TIMER_SET_NO_SET)
				{
					if (G_FreshAirFunc)
						G_FunctionType = FUNCTION_FRESH_AIR;
					else
					{
						if (G_SaveEnergyFunc)
						{
							G_FunctionType = FUNCTION_SAVE_POWER;
						}
						else
						{
							if (G_EconaviFunc)
								G_FunctionType = FUNCTION_ECONAVI;
							else
							{
								if (G_NanoeFunc)
									G_FunctionType = FUNCTION_NANOE;
								else
								{
									G_FunctionType = FUNCTION_TRY_RUN;
								}
							}
						}
					}
				}
				else if (G_TimerSet == TIMER_SET_TYPE_CHOOSE)
				{
					if (G_TimerTypeSet > TIMER_TYPE_ONCE_OFF)
						G_TimerTypeSet--;
					else
						G_TimerTypeSet = TIMER_TYPE_ONCE_ON;
				}
				else if (G_TimerSet == TIMER_SET_TIME_SET)
				{
					G_TimerHourSet += 5;
					if (G_TimerHourSet > TIMER_HOUR_MAX)
						G_TimerHourSet = TIMER_HOUR_MIN;
				}
				break;
			case FUNCTION_WIFI:
				if (G_ErrorCode==0x00)
					G_FunctionType = FUNCTION_TIMER;
				else
				{
					if (G_FreshAirFunc)
						G_FunctionType = FUNCTION_FRESH_AIR;
					else
					{
						if (G_SaveEnergyFunc)
						{
							G_FunctionType = FUNCTION_SAVE_POWER;
						}
						else
						{
							if (G_EconaviFunc)
								G_FunctionType = FUNCTION_ECONAVI;
							else
							{
								if (G_NanoeFunc)
									G_FunctionType = FUNCTION_NANOE;
								else
								{
									G_FunctionType = FUNCTION_TRY_RUN;
								}
							}
						}
					}
				}
				break;
			case FUNCTION_CONNECT_NET:
				G_FunctionType = FUNCTION_WIFI;
				break;
			case FUNCTION_RESET:
				if (G_WifiState)
					G_FunctionType = FUNCTION_CONNECT_NET;
				else
					G_FunctionType = FUNCTION_WIFI;
				break;
			case FUNCTION_FILTER_RESET:
				if (G_WifiState)
					G_FunctionType = FUNCTION_RESET;
				else
					G_FunctionType = FUNCTION_WIFI;
				break;
			case FUNCTION_TRY_RUN:
				if (G_FilterRstSign)	
					G_FunctionType = FUNCTION_FILTER_RESET;
				else
				{
					if (G_WifiState)
						G_FunctionType = FUNCTION_RESET;
					else
						G_FunctionType = FUNCTION_WIFI;
				}
				break;
			default:
				G_FunctionType = FUNCTION_TRY_RUN;
				break;
		}
		Buzzer_KeySoundEnable();
	}
	else if (G_KeyDownType==KEY_TYPE_CONTINUE)
	{
		if (G_FunctionType==FUNCTION_TIMER)
		{
			if (G_TimerSet == TIMER_SET_TIME_SET)
			{
				G_TimerHourSet += 5;
				if (G_TimerHourSet > TIMER_HOUR_MAX)
					G_TimerHourSet = TIMER_HOUR_MIN;
				// �����ͷż���   
				G_KeyReleaseBz = 1;
			}
		}
	}
}

/**************************************************************/
/**
*	@brief	������ �¼� ����   
*/
/**************************************************************/
void FunctionArea6_KeyDown(void)
{
	if (G_KeyDownType==KEY_TYPE_SHORT)
	{
		switch (G_FunctionType)
		{
			case FUNCTION_NANOE:
				if (G_EconaviFunc)
					G_FunctionType = FUNCTION_ECONAVI;
				else
				{
					if (G_SaveEnergyFunc)
						G_FunctionType = FUNCTION_SAVE_POWER;
					else
					{
						if (G_FreshAirFunc)
							G_FunctionType = FUNCTION_FRESH_AIR;
						else
						{
							if (G_ErrorCode==0x00)
								G_FunctionType = FUNCTION_TIMER;
							else
								G_FunctionType = FUNCTION_WIFI;
						}
					}
				}
				break;
			case FUNCTION_ECONAVI:
				if (G_SaveEnergyFunc)
					G_FunctionType = FUNCTION_SAVE_POWER;
				else
				{
					if (G_FreshAirFunc)
						G_FunctionType = FUNCTION_FRESH_AIR;
					else
					{
						if (G_ErrorCode==0x00)
							G_FunctionType = FUNCTION_TIMER;
						else
							G_FunctionType = FUNCTION_WIFI;
					}
				}
				break;
			case FUNCTION_SAVE_POWER:
				if (G_FreshAirFunc)
					G_FunctionType = FUNCTION_FRESH_AIR;
				else
				{
					if (G_ErrorCode==0x00)
						G_FunctionType = FUNCTION_TIMER;
					else
						G_FunctionType = FUNCTION_WIFI;
				}
				break;
			case FUNCTION_FRESH_AIR:
				if (G_ErrorCode==0x00)
					G_FunctionType = FUNCTION_TIMER;
				else
					G_FunctionType = FUNCTION_WIFI;
				break;
			case FUNCTION_TIMER:
				if (G_TimerSet == TIMER_SET_NO_SET)
				{
					G_FunctionType = FUNCTION_WIFI;
				}
				else if (G_TimerSet == TIMER_SET_TYPE_CHOOSE)
				{
					if (G_TimerTypeSet < TIMER_TYPE_ONCE_ON)
						G_TimerTypeSet++;
					else
					{
						G_TimerSet = TIMER_SET_NO_SET;
						G_SystemSet = 0;				// �˳��趨   
					}
				}
				else if (G_TimerSet == TIMER_SET_TIME_SET)
				{
					if (G_TimerHourSet > TIMER_HOUR_MIN)
						G_TimerHourSet -= 5;
					else 
						G_TimerHourSet = TIMER_HOUR_MAX;
				}
				break;
			case FUNCTION_WIFI:
				if (G_WifiState)
					G_FunctionType = FUNCTION_CONNECT_NET;
				else
				{
					if (G_FilterRstSign)
						G_FunctionType = FUNCTION_FILTER_RESET;
					else
						G_FunctionType = FUNCTION_TRY_RUN;
				}
				break;
			case FUNCTION_CONNECT_NET:
				G_FunctionType = FUNCTION_RESET;
				break;
			case FUNCTION_RESET:
				if (G_FilterRstSign)
					G_FunctionType = FUNCTION_FILTER_RESET;
				else
					G_FunctionType = FUNCTION_TRY_RUN;
				break;
			case FUNCTION_FILTER_RESET:
				G_FunctionType = FUNCTION_TRY_RUN;
				break;
			case FUNCTION_TRY_RUN:
				if (G_NanoeFunc)
					G_FunctionType = FUNCTION_NANOE;
				else
				{
					if (G_EconaviFunc)
						G_FunctionType = FUNCTION_ECONAVI;
					else
					{
						if (G_SaveEnergyFunc)
							G_FunctionType = FUNCTION_SAVE_POWER;
						else
						{
							if (G_FreshAirFunc)
								G_FunctionType = FUNCTION_FRESH_AIR;
							else
							{
								if (G_ErrorCode==0x00)
									G_FunctionType = FUNCTION_TIMER;
								else
									G_FunctionType = FUNCTION_WIFI;
							}
						}
					}
				}
				break;
			default:
				if (G_NanoeFunc)
					G_FunctionType = FUNCTION_NANOE;
				else
				{
					if (G_EconaviFunc)
						G_FunctionType = FUNCTION_ECONAVI;
					else
					{
						if (G_SaveEnergyFunc)
							G_FunctionType = FUNCTION_SAVE_POWER;
						else
						{
							if (G_FreshAirFunc)
								G_FunctionType = FUNCTION_FRESH_AIR;
							else
								G_FunctionType = FUNCTION_TIMER;
						}
					}
				}
				break;
		}
		Buzzer_KeySoundEnable();
	}
	else if (G_KeyDownType==KEY_TYPE_CONTINUE)
	{
		if (G_FunctionType==FUNCTION_TIMER)
		{
			if (G_TimerSet == TIMER_SET_TIME_SET)
			{
				if (G_TimerHourSet > TIMER_HOUR_MIN)
					G_TimerHourSet -= 5;
				else 
					G_TimerHourSet = TIMER_HOUR_MAX;
				
				// �����ͷż���   
				G_KeyReleaseBz = 1;
			}
		}
	}
}

/**************************************************************/
/**
*	@brief	����ڶ���ʱ����    
*	@note	�˺���500ms����һ��   
*/
/**************************************************************/
void WindDir_AutoSwingDeal(void)
{
	static uint8_t count_500ms = 0;

	count_500ms++;
	count_500ms %= 2;

	if (count_500ms == 0)
	{
		if (G_WindDirUd[G_SystemMode] == WIND_DIR_UD_AUTO)
		{
			if (G_WindDirUdSwingDir==0)
			{
				G_WindDirUdSwing++;
				if (G_WindDirUdSwing>=4)
				{
					G_WindDirUdSwing = 4;
					G_WindDirUdSwingDir = 1;
				}
			}
			else
			{
				G_WindDirUdSwing--;
				if (G_WindDirUdSwing>=4)
				{
					G_WindDirUdSwing = 1;
					G_WindDirUdSwingDir = 0;
				}
			}
		}

		if (G_WindDirLr[G_SystemMode] == WIND_DIR_LR_AUTO)
		{
			if (G_WindDirLrSwingDir==0)
			{
				G_WindDirLrSwing++;
				if (G_WindDirLrSwing>=4)
				{
					G_WindDirLrSwing = 4;
					G_WindDirLrSwingDir = 1;
				}
			}
			else
			{
				G_WindDirLrSwing--;
				if (G_WindDirLrSwing>=4)
				{
					G_WindDirLrSwing = 1;
					G_WindDirLrSwingDir = 0;
				}
			}
		}
	}
}

/**************************************************************/
/**
*	@brief	�Զ��˳����ü�ʱ��������        
*	@note	�˺���500ms����һ��   
*/
/**************************************************************/
void SystemSet_AutoExitCount(void)
{
	static uint8_t count_500ms_temp = 0;

	
	if (G_SystemSet==0)
		return;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;
	
	G_SystemSetCount++;
	if (G_SystemSetCount >= SYSTEM_SET_COUNT_30S)
	{
		G_SystemSetCount = 0;
		// �˳�����״̬   
		G_SystemSet = 0;
	}
}

/**************************************************************/
/**
*	@brief	������������   
*/
/**************************************************************/
void SystemStatus_OnDeal(void)
{
	// ����   

	if (G_Cleanning)
	{
		G_Cleanning = 0;
		SystemStatus_OffDeal();
		return;
	}
	G_SystemStatus = SYSTEM_STATUS_ON;

	Vrf_CmdJoinQueue(CMD_TYPE_41_ON_OFF,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);

	// ��������   
	if (G_FreshAirFunc)
		G_FreshAir = 1;

	// nanoe���ͷ����   
	G_NanoeUnion = 1;		

	// �رն�ʱ��   
	if (G_TimerType==TIMER_TYPE_ONCE_ON)
	{
		G_TimerType = TIMER_TYPE_NO_SET;
		G_TimerRemainHour = G_TimerHour = 0;
		G_TimerCount = 0;
		Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	}
	else if (G_TimerType==TIMER_TYPE_CYCLE_OFF)
	{
		if (G_TimerRemainHour==0)
		{
			G_TimerRemainHour = G_TimerHour;
			G_TimerCount = (uint32_t)G_TimerRemainHour * 360;
			Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		}
	}

	G_NanoeAbCnt = 0;

	// �׻��쳣E09   
	if (G_ErrorCode==0x49)
	{
		G_ErrorCode = 0;
	}
	G_MasterErrorCount = 0;
	
}	

/**************************************************************/
/**
*	@brief	�ػ���������   
*/
/**************************************************************/
void SystemStatus_OffDeal(void)
{
	// �ػ�       
	G_SystemStatus = SYSTEM_STATUS_OFF;
	Vrf_CmdJoinQueue(CMD_TYPE_41_ON_OFF,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	
	// �رջ���  
	G_FreshAir = 0;
	
	// �˳��趨״̬
	G_SystemSet = 0;

	
	G_NanoeAbCnt = 0;

	// �׻��쳣E09   
	if (G_ErrorCode==0x49)
	{
		G_ErrorCode = 0;
	}
	G_MasterErrorCount = 0;
	
}	

/**************************************************************/
/**
*	@brief	��ʱ����     
*/
/**************************************************************/
void Timer_Process(void)
{
	static uint8_t count_500ms_temp = 0;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;

	if (G_TimerCount==0)
		return;
	
	switch (G_TimerType)
	{
		case TIMER_TYPE_ONCE_OFF:
		case TIMER_TYPE_CYCLE_OFF:
			G_TimerCount--;
			if (G_TimerCount == ((uint32_t)G_TimerRemainHour-5)*360)
			{
				G_TimerRemainHour -= 5;
				if (G_TimerRemainHour == 0)
				{
					if (G_SystemStatus == SYSTEM_STATUS_ON)
					{
						SystemStatus_OffDeal();
						Buzzer_LongSoundEnable();
					}
					if (G_TimerType == TIMER_TYPE_ONCE_OFF)
					{
						G_TimerType = TIMER_TYPE_NO_SET;
						G_TimerRemainHour = G_TimerHour = 0;
						G_TimerCount = 0;
					}
					Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
				else
					Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			break;
		case TIMER_TYPE_ONCE_ON:
			G_TimerCount--;
			if (G_TimerCount == ((uint32_t)G_TimerRemainHour-5)*360)
			{
				G_TimerRemainHour -= 5;
				if (G_TimerRemainHour == 0)
				{
					SystemStatus_OnDeal();
					Buzzer_KeySoundEnable();
				}
				else
					Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			break;
	}
	
}

/**************************************************************/
/**
*	@brief	�߿���wifi on����ʱ���ܰ�����      
*/
/**************************************************************/
void Wifi_NetKeyCount(void)
{
	if (G_NetKeyCountdown==0)
		return;
	
	G_NetKeyCountdown--; 
}

void TestMode_KeyDeal(void)
{
	if (G_TestStage != TEST_STAGE_SW)
		return;
	switch (G_Key.value)
	{
		case KEY_VALUE_ON_OFF:
			if (!(G_KeyTestFlag&KEY_VALUE_ON_OFF))
			{
				G_KeyTestFlag |= KEY_VALUE_ON_OFF;
				G_KeyTestCount++;
			}
			break;
		case KEY_VALUE_FUNCTION:
			if (!(G_KeyTestFlag&KEY_VALUE_FUNCTION))
			{
				G_KeyTestFlag |= KEY_VALUE_FUNCTION;
				G_KeyTestCount++;
			}
			break;
		case KEY_VALUE_SET:
			if (!(G_KeyTestFlag&KEY_VALUE_SET))
			{
				G_KeyTestFlag |= KEY_VALUE_SET;
				G_KeyTestCount++;
			}

			break;
		case KEY_VALUE_WINDSPEED:
			if (!(G_KeyTestFlag&KEY_VALUE_WINDSPEED))
			{
				G_KeyTestFlag |= KEY_VALUE_WINDSPEED;
				G_KeyTestCount++;
			}

			break;
		case KEY_VALUE_UP:
			if (!(G_KeyTestFlag&KEY_VALUE_UP))
			{
				G_KeyTestFlag |= KEY_VALUE_UP;
				G_KeyTestCount++;
			}
			break;
		case KEY_VALUE_DOWN:
			if (!(G_KeyTestFlag&KEY_VALUE_DOWN))
			{
				G_KeyTestFlag |= KEY_VALUE_DOWN;
				G_KeyTestCount++;
			}
			break;
	}
}

/**************************************************************/
/**
*	@brief	����ģʽ    
*/
/**************************************************************/
void TestMode_Process(void)
{
	static uint8_t count = 0;
	uint8_t temp;
	
	if (G_TestMode != 1)
		return;

	switch (G_TestStage)
	{
		case TEST_STAGE_LCD:
			BL_TURN_ON_MID();
			count++;
			if (count>=100)
			{
				count = 0;
				G_TestLength++;
				if (G_TestLength >= TEST_LENGTH_LCD)
				{
					G_TestLength = 0;
					G_TestStage++;
					G_EepromTestErr = 0;
				}
			}
			break;
		case TEST_STAGE_BL:
			count++;
			if (count>=50)
			{
				count = 0;
				switch (G_TestLength)
				{
					case 0:
						BL_TURN_OFF();
						break;
					case 1:
						BL_TURN_ON_MID();
						break;
					case 2:
						BL_TURN_ON_LOW();
						break;
					case 3:
						BL_TURN_ON_MID();
						break;
					case 4:
						BL_TURN_ON_LOW();
						break;
					case 5:
						BL_TURN_ON_MID();
						break;
				}
				G_TestLength++;
				if (G_TestLength>=TEST_LENGTH_BL)
				{
					G_TestLength = 0;
					G_TestStage++;
				}	
			}
			break;
		case TEST_STAGE_LED:
			count++;
			if (count>=50)
			{
				count = 0;
				switch (G_TestLength)
				{
					case 0:
						PowerLight_On();
						break;
					case 1:
						PowerLight_Off();
						break;
					case 2:
						PowerLight_On();
						break;
					case 3:
						PowerLight_Off();
						break;
				}
				G_TestLength++;
				if (G_TestLength>=TEST_LENGTH_LED)
				{
					G_TestLength = 0;
					G_TestStage++;
				}	
			}
			break;
		case TEST_STAGE_EEPROM:
			count = 0;
			Eeprom_TestProcess();
			break;
		case TEST_STAGE_WIFI:
			if (G_WifiPass == 1)
			{
				count = 0;
				G_WifiTestErr = 0;
				G_TestLength = 0;
				G_TestStage++;
				G_VrfComTestErr = 1;
			}
			else
			{
				count++;
				if (count==2)
				{
					count = 0;
					temp = 0x55;
					R_UART0_Send(&temp,1);
					G_TestLength++;
					if (G_TestLength>=TEST_LENGTH_WIFI)
					{
						G_TestLength = 0;
						G_TestStage++;
						G_VrfComTestErr = 1;
					}
				}
			}
			break;
		case TEST_STAGE_VRF_COM:
			count++;
			if (count>=10)
			{
				count = 0;
				if (G_TestLength < TEST_LENGTH_VRF)
				{
					G_TestLength++;
					Vrf_CmdJoinQueue(CMD_TYPE_0D, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				}
				else
				{
					G_TestLength = 0;
					G_TestStage++;
				}
			}
			break;
		case TEST_STAGE_SW:
			if (G_KeyTestCount == 6)
			{
				G_WdtReset = 1;
			}
			break;
	}
}

/**************************************************************/
/**
*	@brief	eepromӲ������      
*/
/**************************************************************/
void Eeprom_TestProcess(void)
{
	uint8_t i,j;
	uint8_t eeprom_dev;
	uint8_t eeprom_add;
	uint8_t temp;
	
	if (G_EepTsCnt==0)
		temp = 0xaa;
	else
		temp = 0x55;
	for (i=0;i<16;i++)
		G_EepromWriteTemp[i] = temp;

	if (G_TestLength < TEST_LENGTH_EEPROM)
	{
		eeprom_dev = 0xa0;					// д��ĵ�ַ    
		eeprom_add = G_TestLength*16;					// 
		eeprom_Write_String(eeprom_dev,eeprom_add,16,G_EepromWriteTemp);	// 16��ҳ��д������    
	}
	
	
	G_TestLength++;
	if (G_TestLength >= TEST_LENGTH_EEPROM)
	{
		G_TestLength = 0;
		G_TestReadEnable = 1;
	}
	if (G_TestReadEnable == 1)
	{
		G_TestReadEnable = 0;
		for (i=0;i<16;i++)
		{
			eeprom_dev = 0xa0;					// д��ĵ�ַ    
			eeprom_add = i*16;					// 
			eeprom_Read_String(eeprom_dev,eeprom_add,16,G_EepromReadTemp);

			for(j=0;j<16;j++)
			{
				if(G_EepromReadTemp[j]!=temp)
				{
					G_EepromTestErr = 1;
				}
			}
		}
		
		G_EepTsCnt++;
		if (G_EepTsCnt>1)
		{
			G_EepTsCnt = 0;
			G_TestLength = 0;
			G_TestStage++;
			G_WifiTestErr = 1;
			G_WifiTestNum = 0;
			G_SystemDataInit = 0;				// resetʱ���³�ʼ������   
			eeprom_Write_String(0xa0,eeprom_init_enable_dress,1,&G_SystemDataInit);
			
		}
	}


}

/**************************************************************/
/**
*	@brief	nanoe�쳣��ʱ����         
*	@detail	nanoe�쳣3���Ӻ󱨾���������ʽ��2.5s��0.5s��     
*/
/**************************************************************/
void Nanoe_AbnormalCount(void)
{
	static uint8_t count_500ms_temp = 0;
	static uint8_t flash_cnt1 = 0 , flash_cnt2 = 0, flash_cnt3 = 0;

	// 0.5s off 2.5s on			
	flash_cnt1++;
	flash_cnt1%= 6;
	if (flash_cnt1<1)
	{
		flash_500ms_off_2500ms_on = 0;
	}
	else
	{
		flash_500ms_off_2500ms_on = 1;
	}

	// 0.5s off 0.5s on
	flash_cnt2++;
	flash_cnt2%= 2;
	if (flash_cnt2<1)
	{
		flash_500ms_off_500ms_on = 1;
	}
	else
	{
		flash_500ms_off_500ms_on = 0;
	}

	// 2.5soff 2.5s on	
	flash_cnt3++;
	flash_cnt3%= 10;
	if (flash_cnt3<5)
	{
		flash_2500ms_off_2500ms_on = 1;
	}
	else
	{
		flash_2500ms_off_2500ms_on = 0;
	}
	

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;
	
	if (G_NanoeAb)
	{
		G_NanoeAbCnt++;
		if (G_NanoeAbCnt>=NANOE_ERROR_2MIN)
			G_NanoeAbCnt = NANOE_ERROR_2MIN;
	}
	else
		G_NanoeAbCnt = 0;
}

void CentralCtl_FlashCount(void)
{

	static uint8_t count_500ms_temp = 0;

	count_500ms_temp++;
	count_500ms_temp %= 2;
	if (count_500ms_temp!=0)
		return;

	//û ����Ԫ��ֹ��־        
	if (G_CentralCtrBanFlag == 0)
		return;

	//û�н�ֹ��������               
	if (G_CtlBanSwAction == CTL_BAN_SW_NO_ACT)
		return;

	if  (G_CtlBanIconFlashCount > CTL_BAN_ICON_FLASH_COUNTS)
	{
		G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
	}
	else 
	{
		G_CtlBanIconFlashCount--;
		if (G_CtlBanIconFlashCount == 0)
		{
			G_CtlBanSwAction = CTL_BAN_SW_NO_ACT;
		}
	}
}



