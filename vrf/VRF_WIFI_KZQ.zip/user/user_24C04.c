#include "Common.h"


/**************************************************************/ 
/**
* @brief	delay ms
* @note		systemClk:16MHz
*/
/**************************************************************/
void delay_ms(uint16_t timebufe)								
{
	unsigned int i=0x00,j=0x00;
	while(j<timebufe)
	{
		for(i=0;i<1800;i++);
			j++;
	}
}

/*****************************************************/ 
/**
** @brief	EEPROM write a byte 
*/
/*****************************************************/
void eeprom_Write_Byte(uint8_t devSel, uint8_t addr, uint8_t dat)
{
	I2C_Start();
	I2C_WriteByte(devSel);
	I2C_WriteByte(addr);
	I2C_WriteByte(dat);
	I2C_Stop();
	delay_ms(10);
}

/*****************************************************/ 
/**
** @brief	EEPROM read a byte 
*/
/*****************************************************/
void eeprom_Read_Byte(uint8_t devSel, uint8_t addr, uint8_t *pdate)
{
	I2C_Start();
	I2C_WriteByte(devSel);
	I2C_WriteByte(addr);

	I2C_Start();
	I2C_WriteByte(devSel|0x01);
	*pdate = I2C_ReadByte(1);
	I2C_Stop();
	delay_ms(10);
}

/*****************************************************/ 
/**
** @brief	EEPROM write string
*/
/*****************************************************/
void eeprom_Write_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate)
{
	I2C_Start();
	I2C_WriteByte(devSel);
	I2C_WriteByte(addr);
	if (len==0)
	{
		I2C_Stop();
	}
	else
	{
		while (len--)
		{
			I2C_WriteByte(*pdate);	
			pdate++;
		}
		I2C_Stop();
	}
	delay_ms(10);
}

/*****************************************************/ 
/**
** @brief	EEPROM read string
*/
/*****************************************************/
void eeprom_Read_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate)
{
	I2C_Start();
	I2C_WriteByte(devSel);
	I2C_WriteByte(addr);

	I2C_Start();
	I2C_WriteByte(devSel|0x01);
	if (len==0)
	{
		I2C_Stop();
	}
	else
	{
		for (;len>=2;len--)
		{
			*pdate = I2C_ReadByte(0);
			pdate++;
		}
		*pdate = I2C_ReadByte(1);
		I2C_Stop();
	}
	delay_ms(10);
}


