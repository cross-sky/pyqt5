#define _EXTERN_IR_H_

#include "Common.h"

//#define IR_TEST

/**********************************************************/
/*
*	@brief 	IR���տ�ʼ   
*	@detail ʹ���ⲿ����ʱ���ã����ⲿ�����жϷ������ڵ���    
*/
/**********************************************************/
void Ir_Rec_Start(void)
{
	G_IrRecStartFlag = 1;
	R_INTC0_Stop();
	R_TAU0_Channel1_Start();
}

/**********************************************************/
/*
*	@brief 	IR���ս���    
*	@detail ʹ���ⲿ����ʱ���ã��ڽ��յ�IR��tailer֮�����       
*/
/**********************************************************/
void Ir_Rec_Stop(void)
{
	R_TAU0_Channel1_Stop();
	R_INTC0_Start();
}

/**********************************************************/
/*
*	@brief 	IR���պ���
*	@detail 125us����һ��  
*/
/**********************************************************/
void Ir_Rec(void)
{
	static uint16_t rece_count = 0;
	static uint8_t flag_rise_edge = 0;
	static uint8_t flag_header = 0;
	static uint8_t r_date; 

	if (G_IrRecStartFlag)
	{
		rece_count++;
		// Tailer = 21T/125us; (T=420us)      
		if(rece_count > 70)  		// β�����   
		{
			rece_count = 0;
			G_IrRecStartFlag=0;
			flag_header=0;
			flag_rise_edge = 0;
			G_IrRecFlag = IR_REC_FINISH;
			G_IrRecLength = G_IrRecNumber;
			G_IrRecNumber = 0;
			G_BitCount = 0;
			r_date = 0;

			//ʹ���ⲿ����ʱ�ŵ��ô˺�����ֱ���ö�ʱ��ʱ���δ˺���       
			Ir_Rec_Stop();		
			return;
		}
	}
	if(!flag_rise_edge)			 	// �����½����м��������   
	{
		if(REC) 
			flag_rise_edge=1;
		else
			flag_rise_edge=0;   
	}
	else
	{
		if(!REC) 					// ��������½���֮���ʱ����     
		{
			flag_rise_edge=0;		// ��������ر�־   
			if(G_IrRecStartFlag)	// ������ձ�־   
			{
				if(!flag_header)	// �Ƿ���չ�ͷ��?   
				{
					// Header = 12T/125us; (T=420us)      
					if((37<rece_count)&&(rece_count<45))	// �Ƿ�Ϊͷ��?     
					{
						flag_header=1;
						G_IrRecNumber=0; 
						r_date = 0;
					}
					else									// ����ͷ�룬�˳��������    
					{
						G_IrRecStartFlag=0;
						G_IrRecNumber=0;
						flag_header=0;  
						flag_rise_edge = 0;
						rece_count = 0;
						r_date = 0;
						Ir_Rec_Stop();	
						return;
					}   
				}
				else
				{	// ���ݽ���    
					if (rece_count < 16)		
					{
						r_date >>= 1;
						// ��ֵ1 = 4T/125us; (T=420us)   
						if ((rece_count>12)&&(rece_count<16))
						{
							r_date |= BIT7;
						}
						G_BitCount++;
						if (G_BitCount >= 8)
						{
							G_BitCount = 0;
							G_IrRecDate[G_IrRecNumber] = r_date;
							r_date = 0;
							G_IrRecNumber++;
						}
					}
				}   
				rece_count=0;
			}
			#if 0
			// ��ʱɨ��ʱ����ȷ����ʼ�źţ��ⲿ����ʱ����Ҫ�õ�  
			else
			{
				G_IrRecStartFlag=1;
				G_IrRecNumber=0;
				flag_header=0;
				rece_count=0;
			}
			#endif
		}   
	}
}

/**********************************************************/
/*
*	@brief 	IR������ɺ���
*	@detail 
*/
/**********************************************************/
void Ir_DataDeal(void)
{
	uint8_t i;
	if (G_IrRecFlag == IR_NO_REC)
		return;
	G_IrRecFlag = IR_NO_REC;
	
	if (G_IrRecLength == 0)
		return;
	

	// IR������ɺ������ݽ���      
	// start
	if ((G_IrRecDate[0]==0x40)&&(G_IrRecDate[1]==0x00)&&(G_IrRecDate[3]==0x81))
	{
		switch (G_IrRecLength)
		{
			case 6:
				Ir_TypeC_Deal();	
				break;
			case 10:
				Ir_TypeD_Deal();	
				break;
			case 11:
				Ir_TypeE_Deal();
				break;
			case 12:
				Ir_TypeA_Deal();
				break;
			default:
				Ir_TypeB_Deal();	
				break;
		}
	}
	G_IrRecLength = 0;
	// stop 
}

void Ir_TypeA_Deal(void)
{
	uint8_t dc_sum_temp;
	uint8_t i;
	uint8_t temp,temp1;
	
	if (G_IrRecDate[2]!=0x14)
		return;

	dc_sum_temp = G_IrRecDate[2]>>4;
	
	for (i=3;i<IR_TYPE_LENGTH_A-1;i++)
	{
		dc_sum_temp += (G_IrRecDate[i]&0x0f);
		dc_sum_temp += (G_IrRecDate[i]>>4);
	}

	if (dc_sum_temp != G_IrRecDate[12])
		return;

	
	
}

void Ir_TypeB_Deal(void)
{
	uint8_t i;
	uint8_t temp0,temp1,temp2;
	uint8_t on_flag = 0;
	uint8_t mode_disable_flag = 0;
	
	if (G_IrRecDate[2]!=0x14)
		return;

	temp2 = G_IrRecDate[2]>>4;
	
	for (i=3;i<IR_TYPE_LENGTH_A-1;i++)
	{
		temp2 += (G_IrRecDate[i]&0x0f);
		temp2 += (G_IrRecDate[i]>>4);
	}

	if (temp2 != G_IrRecDate[IR_TYPE_LENGTH_A-1])
		return;

	for (i=IR_TYPE_LENGTH_A-1;i<G_IrRecLength-1;i++)
	{
		temp2 += (G_IrRecDate[i]&0x0f);
		temp2 += (G_IrRecDate[i]>>4);
	}

	if (temp2 != G_IrRecDate[G_IrRecLength-1])
		return;

	G_KeyCount = KEY_COUNT_5S;

	
	// ���أ���������תģʽ�ڵ���     
	on_flag = 0;
	temp0 = G_IrRecDate[IR_DATA_FC1] & (BIT0+BIT1);
	if ((temp0==BIT0)&&(G_SystemStatus==SYSTEM_STATUS_ON))
	{
		SystemStatus_OffDeal();
		Buzzer_LongSoundEnable();
	}
	else if ((temp0==BIT1)&&(G_SystemStatus==SYSTEM_STATUS_OFF))
	{
		on_flag = 1;
	}

	// ��תģʽ    
	mode_disable_flag = 0;
	temp1 = (G_IrRecDate[IR_DATA_FC1]&(BIT6+BIT7))>>6;
	temp2 = (G_IrRecDate[IR_DATA_FC2]&BIT7)>>7;
	if ((temp2==1)&&(temp1==0))
	{
		if (G_AllowMode & ALLOW_AUTO)
			temp0 = SYSTEM_MODE_AUTO;
		else
			mode_disable_flag = 1;
	}
	else
	{	
		// ȥ��ң���������������������������
		// �׻���Ϊ�������ڻ�����û�̶�����ʱ��������ģʽ�����л�             
		//if (((G_RemoRole == REMO_ROLE_MASTER) && (G_PrioIndoor == PRIO_INDOOR_ON)) || (G_ModeFit == MODE_FIT_NONE))
		if ((G_PrioIndoor == PRIO_INDOOR_ON) || (G_ModeFit == MODE_FIT_NONE))
		{
			switch (temp1)
			{
				case 0:
					if (G_AllowMode & ALLOW_WIND)
						temp0 = SYSTEM_MODE_WIND;
					else
						mode_disable_flag = 1;
					break;
				case 1:
					if (G_AllowMode & ALLOW_WARM)
						temp0 = SYSTEM_MODE_WARM;
					else
						mode_disable_flag = 1;
					break;
				case 2:
					if (G_AllowMode & ALLOW_COLD)
						temp0 = SYSTEM_MODE_COLD;
					else
						mode_disable_flag = 1;
					break;
				case 3:
					if (G_AllowMode & ALLOW_WET)
						temp0 = SYSTEM_MODE_WET;
					else
						mode_disable_flag = 1;
					break;
				default:
					temp0 = G_SystemMode;
					break;
			}
		}
		// ��(�׻���Ϊ�������ڻ�����û�̶�����)ʱ                         
		else
		{
			switch (temp1)
			{
				case 0:
					if (G_AllowMode & ALLOW_WIND)
						temp0 = SYSTEM_MODE_WIND;
					else
						mode_disable_flag = 1;
					break;
				case 1:
					if ((G_AllowMode & ALLOW_WARM) && (G_ModeFit == MODE_FIT_WARM_PRIO))
						temp0 = SYSTEM_MODE_WARM;
					else
						mode_disable_flag = 1;
					break;
				case 2:
					if ((G_AllowMode & ALLOW_COLD) &&  (G_ModeFit == MODE_FIT_COLD_PRIO))
						temp0 = SYSTEM_MODE_COLD;
					else
						mode_disable_flag = 1;
					break;
				case 3:
					if ((G_AllowMode & ALLOW_WET) &&  (G_ModeFit == MODE_FIT_COLD_PRIO))
						temp0 = SYSTEM_MODE_WET;
					else
						mode_disable_flag = 1;
					break;
				default:
					temp0 = G_SystemMode;
					break;
			}
		}
	}

	if (mode_disable_flag == 0)
	{
		
		if (temp0!=G_SystemMode)
		{
			G_SystemMode = temp0;
			Vrf_CmdJoinQueue(CMD_TYPE_42,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
		}
	}
	else
	{
		if (on_flag == 1)
		{
			Buzzer_AlarmEnable();
			return;
		}
	}
	// ����   
	if (on_flag == 1)
	{
		G_StandbySound = 0;
		SystemStatus_OnDeal();
	}
	
	
	// ����    
	temp0 = (G_IrRecDate[IR_DATA_FC1]&(BIT2+BIT3))>>2;
	temp1 = (G_IrRecDate[IR_DATA_EFC0]&BIT4)>>4;
	temp0 = Ir_WindSpeed_deal(temp0,temp1);
	if (temp0!=G_WindSpeed[G_SystemMode])
	{
		G_WindSpeed[G_SystemMode] = temp0;
		Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	}

	// �趨�¶�   
	temp0 = G_IrRecDate[IR_DATA_FC2]&0x3F;
	temp0 = 4+(temp0>>1);
	if (temp0 != G_SystemTemp[G_SystemMode])
	{
		G_SystemTemp[G_SystemMode] = temp0;
		Vrf_CmdJoinQueue(CMD_TYPE_4C_TEMPE,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	}

	// �����¶�    
	temp0 = G_IrRecDate[IR_DATA_FC2]&0x3F;
	temp0 = 4+(temp0>>1);
	G_IndoorTemp = temp0;

	// ����    
	temp0 = (G_IrRecDate[IR_DATA_FC5]&BIT7)>>7;
	if (temp0 != G_FreshAir)
	{
		if (G_FreshAirFunc)
			G_FreshAir = temp0;
		Vrf_CmdJoinQueue(CMD_TYPE_52, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	}

	// ���·���   
	temp1 = G_IrRecDate[IR_DATA_FC6]&(BIT0+BIT1+BIT2);
	switch (temp1)
	{
		case 0:
			temp0 = WIND_DIR_UD_AUTO;
			break;
		case 1:
			temp0 = WIND_DIR_UD_LEVEL1;
			break;
		case 2:
			temp0 = WIND_DIR_UD_LEVEL2;
			break;
		case 3:
			temp0 = WIND_DIR_UD_LEVEL3;
			break;
		case 4:
			temp0 = WIND_DIR_UD_LEVEL4;
			break;
		case 5:
			temp0 = WIND_DIR_UD_LEVEL5;
			break;
		case 7:
			temp0 = WIND_DIR_UD_AUTO_STOP;
			break;
		default:
			temp0 = WIND_DIR_UD_AUTO;
			break;
	}
	if (temp0 != G_WindDirUd[G_SystemMode])
	{
		G_WindDirUd[G_SystemMode] = temp0;
		Vrf_CmdJoinQueue(CMD_TYPE_4C_UP_WIND_DIR,CMD_NO_REPLY, CMD_FORMAT_SETTING);
	}

	// ���ҷ���    
	temp1 = G_IrRecDate[IR_DATA_EFC0]&(BIT0+BIT1+BIT2);
	switch (temp1)
	{
		case 0:
			temp0 = WIND_DIR_LR_AUTO;
			break;
		case 1:
			temp0 = WIND_DIR_LR_LEVEL1;
			break;
		case 2:
			temp0 = WIND_DIR_LR_LEVEL2;
			break;
		case 3:
			temp0 = WIND_DIR_LR_LEVEL3;
			break;
		case 4:
			temp0 = WIND_DIR_LR_LEVEL4;
			break;
		case 5:
			temp0 = WIND_DIR_LR_LEVEL5;
			break;
		case 7:
			temp0 = WIND_DIR_LR_AUTO_STOP;
			break;
		default:
			temp0 = WIND_DIR_LR_AUTO;
			break;
	}
	if (temp0 != G_WindDirLr[G_SystemMode])
	{
		G_WindDirLr[G_SystemMode] = temp0;
		Vrf_CmdJoinQueue(CMD_TYPE_4C_LR_WIND_DIR,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	}

	// ECONAVI    
	temp0 = (G_IrRecDate[IR_DATA_EFC0]&BIT5)>>5;
	if (temp0!=G_EconaviStatus)
	{
		if (G_EconaviFunc)
			G_EconaviStatus = temp0;
		else
			G_EconaviStatus = 0;
		Vrf_CmdJoinQueue(CMD_TYPE_58, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
	}

	// Nanoe		
	temp0 = (G_IrRecDate[IR_DATA_EFC0]&BIT6)>>6;
	if (temp0!=G_NanoeStatus)
	{
		if (G_NanoeFunc)
			G_NanoeStatus = temp0;
		else
			G_NanoeStatus = 0;
		Vrf_CmdJoinQueue(CMD_TYPE_5C, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
	}

	// ����   
	temp0 = (G_IrRecDate[IR_DATA_EFC1]&BIT6)>>6;
	if (temp0!=G_SaveEnergy)
	{
		G_SaveEnergy = temp0;
		Vrf_CmdJoinQueue(CMD_TYPE_54, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
	}

	BL_On();
	if (G_TestMode)
		Buzzer_Enable(1,100);
	else
		Buzzer_KeySoundEnable();
}

void Ir_TypeC_Deal(void)
{
	uint8_t dc_sum_temp;
	uint8_t i;
	if (G_IrRecDate[2]!=0x04)
		return;

	dc_sum_temp = G_IrRecDate[2]>>4;
	
	for (i=3;i<IR_TYPE_LENGTH_C-1;i++)
	{
		dc_sum_temp += (G_IrRecDate[i]&0x0f);
		dc_sum_temp += (G_IrRecDate[i]>>4);
	}

	if (dc_sum_temp != G_IrRecDate[IR_TYPE_LENGTH_C-1])
		return;
}

void Ir_TypeD_Deal(void)
{
	uint8_t dc_sum_temp;
	uint8_t i;
	if (G_IrRecDate[2]!=0x14)
		return;

	dc_sum_temp = G_IrRecDate[2]>>4;
	
	for (i=3;i<IR_TYPE_LENGTH_D-1;i++)
	{
		dc_sum_temp += (G_IrRecDate[i]&0x0f);
		dc_sum_temp += (G_IrRecDate[i]>>4);
	}

	if (dc_sum_temp != G_IrRecDate[IR_TYPE_LENGTH_D-1])
		return;
}

void Ir_TypeE_Deal(void)
{
	uint8_t i;
	uint8_t temp0,temp1,temp2;
	if (G_IrRecDate[2]!=0x14)
		return;

	if (G_IrRecDate[IR_DATA_FC0]!=0x3F)
		return;

	temp2 = G_IrRecDate[2]>>4;
	
	for (i=3;i<IR_TYPE_LENGTH_E-1;i++)
	{
		temp2 += (G_IrRecDate[i]&0x0f);
		temp2 += (G_IrRecDate[i]>>4);
	}

	if (temp2 != G_IrRecDate[IR_TYPE_LENGTH_E-1])
		return;
	G_KeyCount = KEY_COUNT_5S;
	
	switch (G_IrRecDate[IR_DATA_FC1])
	{
		case 0x07:
			if (G_IrRecDate[IR_DATA_FC3])
			{
				if (G_SpecWindSpeed!=WIND_SPEED_SPEC_STRONG)
				{
					G_SpecWindSpeed = WIND_SPEED_SPEC_STRONG;
					G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
					Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
			}
			else
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			BL_On();
			Buzzer_KeySoundEnable();
			break;
		case 0x08:
			if (G_IrRecDate[IR_DATA_FC3])
			{
				if (G_SpecWindSpeed!=WIND_SPEED_SPEC_MUTE)
				{
					G_SpecWindSpeed = WIND_SPEED_SPEC_MUTE;
					G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
					Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
			}
			else
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			BL_On();
			Buzzer_KeySoundEnable();
			break;
		case 0x09:
			G_LedDuty = G_IrRecDate[IR_DATA_FC3];
			G_Cmd5FFnc = CMD_5F_FNC_LED_DUTY;
			Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			BL_On();
			Buzzer_KeySoundEnable();
			break;
		case 0x0A:
			if (G_IrRecDate[IR_DATA_FC2] == 0x00)
			{
				if (G_IrRecDate[IR_DATA_FC3] == 0x01)
				{
					G_WifiResetState = 0;
					G_WifiState = 1;
					G_WifiCheckResult = WIFI_NO_CHECK;
					G_NetKeyCountdown = 200;
				}
				else
				{
					G_WifiResetState = 0;
					G_WifiState = 0;
					G_WifiCheckResult = WIFI_NO_CHECK;
				}
				wifi_match_enable_write = 1;
				G_WifiCmd5F = WIFI_CMD_5F_ON_OFF;
				G_Cmd5FFnc = CMD_5F_FNC_WIFI;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			else if (G_IrRecDate[IR_DATA_FC2] == 0x01)
			{	
				G_WifiCmd5F = WIFI_CMD_5F_SIGNAL;
				G_Cmd5FFnc = CMD_5F_FNC_WIFI;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				
			}
			else if (G_IrRecDate[IR_DATA_FC2] == 0x02)
			{
				G_WifiConnectNetState = 1;
				G_WifiNetShowCount = WIFI_NET_SHOW_COUNT;
				
				G_WifiCmd5F = WIFI_CMD_5F_NET;
				G_Cmd5FFnc = CMD_5F_FNC_WIFI;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			else if (G_IrRecDate[IR_DATA_FC2] == 0x03)
			{
					G_WifiResetState = 1;
					G_WifiCheckResult = WIFI_NO_CHECK;
					G_WifiResetShowCnt = WIFI_RESET_SHOW_COUNT;
					G_WifiCmd5F = WIFI_CMD_5F_RESET;
					G_Cmd5FFnc = CMD_5F_FNC_WIFI;
					Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			Buzzer_KeySoundEnable();
			break;
	}

	
	
}

uint8_t Ir_WindSpeed_deal(uint8_t dat0,uint8_t dat1)
{
	uint8_t windspeed_temp;
	switch (dat0)
	{
		case 0:
			windspeed_temp = WIND_SPEED_AUTO;
			break;
		case 1:
			windspeed_temp = WIND_SPEED_LEVEL5;
			break;
		case 2:
			if (dat1&&(G_WindSpeedGroup == WIND_SPEED_GROUP_5))
				windspeed_temp = WIND_SPEED_LEVEL2;
			else
				windspeed_temp = WIND_SPEED_LEVEL1;
			break;
		case 3:
			if (dat1&&(G_WindSpeedGroup == WIND_SPEED_GROUP_5))
				windspeed_temp = WIND_SPEED_LEVEL4;
			else
				windspeed_temp = WIND_SPEED_LEVEL3;
			break;
	}
	return windspeed_temp;
}

