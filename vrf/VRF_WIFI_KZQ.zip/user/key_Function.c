#include "Common.h"


/**************************************************************/
/**
*	@brief	���ܰ�����������   
*/
/**************************************************************/
void Key_FunctionDeal(void)
{
	
	switch (GuiTaskMode)
	{
		case NORMAL_TAST:					/* ���ڻ�����ģʽ   */
			FunKey_Normal();
			break;
		case PRO_TAST:						/* ��ϸ�ͼ���Ŀ�趨���� ep�趨  */
			FuncKey_Pro();
			break;
		case REMO_SET_TAST:					/*	ң���������趨   */
			FuncKey_RemoSet();
			break;
		case ERROR_INDEX_TAST:				/*	�쳣��ѯ����  */
			FuncKey_ErrorCheck();
			break;
		case SERVER_INDEX_TAST:				/*	����������  */
			FuncKey_ServerCheck();
			break;
		case AUTO_ADDR_TAST:				/*	�Զ���ַ����  */
			FuncKey_AutoAddr();
			break;
		case MANUAL_ADDR_TAST:				/*	�ֶ���ַ����  */
			FuncKey_ManualAddr();			
			break;
		case OUTDOOR_NORMAL_TAST:			/*	���������  */
			FuncKey_OutdoorNormal();
			break;
		case OUTDOOR_ERROR_INDEX_TAST:	/*	������쳣����  */
			FuncKey_OutdoorErrorCheck();
			break;
		case OUTDOOR_SERVER_INDEX_TAST:	/*	�������������  */
			FuncKey_OutdoorServerCheck();
			break;
	}
	
}

/**************************************************************/
/**
*	@brief	���ܰ��� ����ģʽ����    
*/
/**************************************************************/
static void FunKey_Normal(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)			// �����̰�����    
	{
		if (G_SendFlag & SEND_FLAG_INIT)			// ����ͨѶδ���ʱ������Ч    
					return;
		if (G_SystemStatus == SYSTEM_STATUS_OFF)	// �ػ�ʱ������Ч   
			return;
		
		G_KeyCount = KEY_COUNT_5S;					// ����������5s������81ָ��   
		
		if (G_SystemSet == 0)						// δ���빦������ѡ��ʱ�����빦������ѡ��   
		{
			G_SystemSet = 1;
			switch (G_SettingMode)
			{
				case SETTING_MODE_RUN_MODE:
					G_SystemModeSet = G_SystemMode;
					break;
				case SETTING_MODE_UD_WIND:
					break;
				case SETTING_MODE_LR_WIND:
					break;
				case SETTING_MODE_FUNCTION:
					if (G_NanoeFunc == 0)
					{
						if (G_EconaviFunc == 0)
						{
							if (G_SaveEnergyFunc == 0)
							{
								if (G_FreshAirFunc)
									G_FunctionType = FUNCTION_FRESH_AIR;
								else
									G_FunctionType = FUNCTION_TIMER;
							}
							else
								G_FunctionType = FUNCTION_SAVE_POWER;
						}
						else
							G_FunctionType = FUNCTION_ECONAVI;
					}
					else
						G_FunctionType = FUNCTION_NANOE;
					
					G_TimerSet = TIMER_SET_NO_SET;
					break;
			}
		}
		else						// ��������ѡ��ʱ���л�����   
		{
			switch (G_SettingMode)
			{
				case SETTING_MODE_RUN_MODE:
					if (G_UdWindDirGroup[G_SystemMode]!=UD_WIND_DIR_GROUP_NO)
					{
						G_SettingMode = SETTING_MODE_UD_WIND;
					}
					else
					{
						if (G_LrWindDirGroup!=LR_WIND_DIR_GROUP_NO)
						{
							G_SettingMode = SETTING_MODE_LR_WIND;
						}
						else
						{
							G_SettingMode = SETTING_MODE_FUNCTION;
							if (G_NanoeFunc == 0)
							{
								if (G_EconaviFunc == 0)
								{
									if (G_SaveEnergyFunc == 0)
									{
										if (G_FreshAirFunc)
											G_FunctionType = FUNCTION_FRESH_AIR;
										else
											G_FunctionType = FUNCTION_TIMER;
									}
									else
										G_FunctionType = FUNCTION_SAVE_POWER;
								}
								else
									G_FunctionType = FUNCTION_ECONAVI;
							}
							else
								G_FunctionType = FUNCTION_NANOE;
						}
					}
					break;
				case SETTING_MODE_UD_WIND:
					if (G_LrWindDirGroup!=LR_WIND_DIR_GROUP_NO)
					{
						G_SettingMode = SETTING_MODE_LR_WIND;
					}
					else
					{
						G_SettingMode = SETTING_MODE_FUNCTION;
						if (G_NanoeFunc == 0)
						{
							if (G_EconaviFunc == 0)
							{
								if (G_SaveEnergyFunc == 0)
								{
									if (G_FreshAirFunc)
										G_FunctionType = FUNCTION_FRESH_AIR;
									else
										G_FunctionType = FUNCTION_TIMER;
								}
								else
									G_FunctionType = FUNCTION_SAVE_POWER;
							}
							else
								G_FunctionType = FUNCTION_ECONAVI;
						}
						else
							G_FunctionType = FUNCTION_NANOE;
					}
					break;
				case SETTING_MODE_LR_WIND:
					G_SettingMode = SETTING_MODE_FUNCTION;
					if (G_NanoeFunc == 0)
					{
						if (G_EconaviFunc == 0)
						{
							if (G_SaveEnergyFunc == 0)
							{
								if (G_FreshAirFunc)
									G_FunctionType = FUNCTION_FRESH_AIR;
								else
									G_FunctionType = FUNCTION_TIMER;
							}
							else
								G_FunctionType = FUNCTION_SAVE_POWER;
						}
						else
							G_FunctionType = FUNCTION_ECONAVI;
					}
					else
						G_FunctionType = FUNCTION_NANOE;
					break;
				case SETTING_MODE_FUNCTION:
					G_SettingMode = SETTING_MODE_RUN_MODE;
					G_SystemModeSet = G_SystemMode;
					break;
			}
		}
		G_SystemSetCount = 0;				// ����ʱ����0
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	���ܰ���   ��ϸ�ͼ��趨����   
*/
/**************************************************************/
static void FuncKey_Pro(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if ((G_ProSetting==PRO_SETTING_LEVEL1)||(G_ProSetting==PRO_SETTING_LEVEL2))
		{
			G_ProSetting = PRO_SETTING_LEVEL3;
			G_ProCmdCount = 0;
			G_ProStep = 1;
			G_ProSendEnable = 1;
			Vrf_ClearSend();
			GuiTaskMode = RESET_TAST;
			Buzzer_KeySoundEnable();
		}
	}
}
/**************************************************************/
/**
*	@brief	���ܰ���  ң������Ŀ�趨�Ĺ��ܰ�������   
*/
/**************************************************************/
static void FuncKey_RemoSet(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_RemoFunSet == REMO_FUN_NO_SET)
			return;
		G_RemoFunSet = REMO_FUN_NO_SET;
		if (G_RemoMode == REMO_MODE_TEST)
		{
			G_TestMode = 1;
			GuiTaskMode = TEST_TAST;
			Vrf_ClearSend();
			Buzzer_Enable(1,100);
		}
		else
		{
			G_WdtReset = 1;
			GuiTaskMode = RESET_TAST;
			Buzzer_KeySoundEnable();
		}
	}
}

/**************************************************************/
/**
*	@brief	���ܰ���   �������ݼ����Ĺ��ܰ�������   
*/
/**************************************************************/
static void FuncKey_ErrorCheck(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		G_ErrorCheck = 0;
		GuiTaskMode = NORMAL_TAST;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	���ܰ��� ������ģʽ����
*/
/**************************************************************/
static void FuncKey_ServerCheck(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		G_ServerCheck = 0;
		GuiTaskMode = NORMAL_TAST;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	���ܰ��� �Զ���ַ����
*/
/**************************************************************/
static void FuncKey_AutoAddr(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_AddrSetStep == ADDR_SET_STEP_RESET)
			return;
		Vrf_ClearSend();
		G_AutoAddrSet = AUTO_ADDR_SET_WAIT;
		G_AddrSetStep = ADDR_SET_STEP_RESET;
		G_AddrSendTime = 0;
		G_AddrComSendCnt = 0;
		G_AutoAddrSend = 1;
		GuiTaskMode = RESET_TAST;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	���ܰ��� �ֶ���ַ����   
*/
/**************************************************************/
static void FuncKey_ManualAddr(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_ManualAddrSet == MANUAL_ADDR_EXIT)
			return;
		Vrf_ClearSend();
		G_ManualAddrSet = MANUAL_ADDR_EXIT;
		G_ManualAddrStep = 0;
		G_ManualCmdCnt = 0;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	���ܰ��� �������ʱ������ģʽ����   
*/
/**************************************************************/
static void FuncKey_OutdoorNormal(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_SendFlag & SEND_FLAG_OUTDOOR_INIT)		// ���ڻ�   
				return;
		
		G_8BKeyValue = KEY_8B_FUNC;
		Vrf_CmdJoinQueue(CMD_TYPE_8B_KEY,CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		Vrf_CmdJoinQueue(CMD_TYPE_19_KEY,CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		Buzzer_LongSoundEnable();
	}
}


/**************************************************************/
/**
*	@brief	���ܰ���   �˳��쳣����    
*/
/**************************************************************/
static void FuncKey_OutdoorErrorCheck(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		G_ErrorCheck = 0;
		GuiTaskMode = OUTDOOR_NORMAL_TAST;
		Buzzer_KeySoundEnable();
	}
}

/**************************************************************/
/**
*	@brief	���ܰ��� ���������ģʽ����
*/
/**************************************************************/
static void FuncKey_OutdoorServerCheck(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		G_ServerCheck = 0;
		GuiTaskMode = OUTDOOR_NORMAL_TAST;
		Buzzer_KeySoundEnable();
	}
}


