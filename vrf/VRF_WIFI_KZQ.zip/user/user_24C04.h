#include "r_cg_macrodriver.h"

#ifndef _24C04_H
#define _24C04_H


void delay_ms(uint16_t timebufe);
void eeprom_Write_Byte(uint8_t devSel, uint8_t addr, uint8_t dat);
void eeprom_Read_Byte(uint8_t devSel, uint8_t addr, uint8_t *pdate);
void eeprom_Write_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate);
void eeprom_Read_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate);

#endif
