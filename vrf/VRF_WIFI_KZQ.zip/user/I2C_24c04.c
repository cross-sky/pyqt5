#include "Common.h"


/*****************************************************************/ 
/**
** @brief	delay 5us
*/
/****************************************************************/
void delay_5us(void)
{
	uint8_t i;
	for (i=0; i<9;i++)
		NOP();								// delay
}
/*****************************************************/ 
/**
** @brief       i2c start
*/
/*****************************************************/
void I2C_Start(void)
{
    I2C_SDA_OUTPUT();
    I2C_SDA_HIGH();
    delay_5us();
    I2C_SCL_HIGH();
    delay_5us();
    I2C_SDA_LOW();
    delay_5us(); 
    I2C_SCL_LOW();
    delay_5us();
}

/*****************************************************/ 
/**
** @brief	i2c stop
/**
/*****************************************************/
void I2C_Stop(void)
{   
	I2C_SDA_OUTPUT();
	delay_5us();
    I2C_SDA_LOW();
    delay_5us();
    I2C_SCL_HIGH();
    delay_5us();
    I2C_SDA_HIGH();
    delay_5us();
}

/*****************************************************/ 
/**
** @brief       I2C write dat
*/
/*****************************************************/
uint8_t I2C_WriteByte(uint8_t Byte)
{
    uint8_t i=0;
    I2C_SDA_OUTPUT();
    delay_5us();
    for(i=0;i<8;i++)
    {   
        if (Byte & 0x80)
            I2C_SDA_HIGH();
        else
            I2C_SDA_LOW();
        NOP();     
        I2C_SCL_HIGH();
        delay_5us();
        I2C_SCL_LOW();
        delay_5us();
        Byte <<= 1;
    }   
    I2C_SDA_INPUT();
    I2C_SCL_HIGH();
    delay_5us();
    if (I2C_SDA_READ() == 1)
        i = 0x01;
    else
        i = 0x00;
    I2C_SCL_LOW();
    return i;
}

/*****************************************************/ 
/*
* 	@brief      I2C read dat
*	@param		ack:0 , no ack:1 
*/
/*****************************************************/
uint8_t I2C_ReadByte(uint8_t ack)
{
    uint8_t i = 0;
    uint8_t Byte = 0;
    I2C_SDA_INPUT();
    delay_5us();
    for(i=0; i<8; i++)
    {
        I2C_SCL_LOW();
        delay_5us();
        I2C_SCL_HIGH();
        delay_5us();
        Byte <<= 1;
        if (I2C_SDA_READ())
            Byte|=0x01;
    }
    I2C_SCL_LOW();
    I2C_SDA_OUTPUT();
    delay_5us();
    if (ack)
        I2C_SDA_HIGH();
    else
        I2C_SDA_LOW();   
    I2C_SCL_HIGH();
    delay_5us();
    I2C_SCL_LOW();
    I2C_SDA_INPUT();	
	//I2C_SDA_HIGH();    
    return Byte;
}



