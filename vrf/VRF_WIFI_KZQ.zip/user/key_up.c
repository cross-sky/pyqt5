#include "Common.h"

/**************************************************************/
/**
*	@brief	up����������   
*/
/**************************************************************/
void Key_UpDeal(void)
{
	switch (GuiTaskMode)
	{
		case NORMAL_TAST:				/* ���ڻ�����ģʽ   */
			UpKey_Normal();
			break;
		case PRO_TAST:					/* ��ϸ�ͼ���Ŀ�趨���� ep�趨  */
			UpKey_Pro();
			break;
		case REMO_SET_TAST:				/*	ң���������趨   */
			UpKey_RemoFun();	
			break;
		case ERROR_INDEX_TAST:			/*	�쳣��ѯ����  */
			UpKey_ErrorIndex();
			break;
		case SERVER_INDEX_TAST:			/*	����������  */
			UpKey_ServerIndex();
			break;
		case AUTO_ADDR_TAST:			/*	�Զ���ַ����  */
			UpKey_AutoAddr();
			break;
		case MANUAL_ADDR_TAST:			/*	�ֶ���ַ����  */
			UpKey_ManualAddr();
			break;
		case OUTDOOR_NORMAL_TAST:		/*	���������  */
			UpKey_OutdoorNormal();
			break;
		case OUTDOOR_ERROR_INDEX_TAST:	/*	������쳣��������   */
			UpKey_OutdoorErrorIndex();		
			break;
		case OUTDOOR_SERVER_INDEX_TAST:			/*	����������  */
			UpKey_OutdoorServerIndex();
			break;
	}
}

/**************************************************************/
/**
*	@brief	�ϰ��� ����ģʽ����    
*/
/**************************************************************/
static void UpKey_Normal(void)
{
	uint8_t i;
	uint8_t tempe_max,tempe_min;
	if ((G_KeyDownType == KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		if (G_SendFlag & SEND_FLAG_INIT)
			return;
		if (G_SystemStatus == SYSTEM_STATUS_OFF)
			return;
			
		G_KeyCount = KEY_COUNT_5S;

		
		if (G_SystemSet == 1)
		{	
			G_SystemSetCount = 0;
			if (G_KeyDownType==KEY_TYPE_SHORT)
			{
				switch (G_SettingMode)
				{
					case SETTING_MODE_RUN_MODE:
						// ���п��ƽ�ֹ��         
						if (G_CentralCtrBanFlag & MODE_SW_BAN)
						{
							G_CtlBanSwAction = CTL_BAN_SW_ACT;
							G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;

							G_SystemModeSet = G_SystemMode;
							return;
						}
						// ȥ��ң���������������������������
						//if (((G_RemoRole == REMO_ROLE_MASTER) && (G_PrioIndoor == PRIO_INDOOR_ON)) || (G_ModeFit == MODE_FIT_NONE))
						if ((G_PrioIndoor == PRIO_INDOOR_ON) || (G_ModeFit == MODE_FIT_NONE))
						{
							for (i=0;i<5;i++)
							{
								switch (G_SystemModeSet)
								{
									case SYSTEM_MODE_AUTO:
										G_SystemModeSet = SYSTEM_MODE_WIND;
										if (G_AllowMode & ALLOW_WIND)
											i=5;
										break;
									case SYSTEM_MODE_WARM:
										G_SystemModeSet = SYSTEM_MODE_AUTO;
										if (G_AllowMode & ALLOW_AUTO)
											i=5;
										break;
									case SYSTEM_MODE_COLD:
										G_SystemModeSet = SYSTEM_MODE_WARM;
										if (G_AllowMode & ALLOW_WARM)
											i=5;
										break;
									case SYSTEM_MODE_WET:
										G_SystemModeSet = SYSTEM_MODE_COLD;
										if (G_AllowMode & ALLOW_COLD)
											i=5;
										break;
									case SYSTEM_MODE_WIND:
										G_SystemModeSet = SYSTEM_MODE_WET;
										if (G_AllowMode & ALLOW_WET)
											i=5;
										break;
								}
							}
						}
						else
						{
							for (i=0;i<5;i++)
							{
								switch (G_SystemModeSet)
								{
									case SYSTEM_MODE_AUTO:
										G_SystemModeSet = SYSTEM_MODE_WIND;
										if (G_AllowMode & ALLOW_WIND)
											i=5;
										break;
									case SYSTEM_MODE_WARM:
										G_SystemModeSet = SYSTEM_MODE_AUTO;
										if (G_AllowMode & ALLOW_AUTO)
											i=5;
										break;
									case SYSTEM_MODE_COLD:
										G_SystemModeSet = SYSTEM_MODE_WARM;
										if ((G_AllowMode & ALLOW_WARM) && (G_ModeFit == MODE_FIT_WARM_PRIO))
											i=5;
										break;
									case SYSTEM_MODE_WET:
										G_SystemModeSet = SYSTEM_MODE_COLD;
										if ((G_AllowMode & ALLOW_COLD) && (G_ModeFit == MODE_FIT_COLD_PRIO))
											i=5;
										break;
									case SYSTEM_MODE_WIND:
										G_SystemModeSet = SYSTEM_MODE_WET;
										if ((G_AllowMode & ALLOW_WET) && (G_ModeFit == MODE_FIT_COLD_PRIO))
											i=5;
										break;
								}
							}
						}
						Buzzer_KeySoundEnable();
						break;
					case SETTING_MODE_UD_WIND:
						// ���п��ƽ�ֹ��         
						if (G_CentralCtrBanFlag & WIND_DIR_SW_BAN)
						{
							G_CtlBanSwAction = CTL_BAN_SW_ACT;
							G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
							return;
						}
						if (G_UdWindDirGroup[G_SystemMode] == UD_WIND_DIR_GROUP_5)
						{
							switch (G_WindDirUd[G_SystemMode])
							{
								case WIND_DIR_UD_AUTO:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_AUTO_STOP;
									break;
								case WIND_DIR_UD_AUTO_STOP:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL5;
										break;
								case WIND_DIR_UD_LEVEL5:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL4;
									break;
								case WIND_DIR_UD_LEVEL4:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL3;
									break;
								case WIND_DIR_UD_LEVEL3:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL2;
									break;
								case WIND_DIR_UD_LEVEL2:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL1;
									break;
								case WIND_DIR_UD_LEVEL1:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_AUTO;
									break;
								default:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL1;
									break;
							}
							Vrf_CmdJoinQueue(CMD_TYPE_4C_UP_WIND_DIR,CMD_NO_REPLY, CMD_FORMAT_SETTING);
							Buzzer_KeySoundEnable();
						}
						else if (G_UdWindDirGroup[G_SystemMode]  == UD_WIND_DIR_GROUP_3)
						{
							switch (G_WindDirUd[G_SystemMode])
							{
								case WIND_DIR_UD_AUTO:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_AUTO_STOP;
									break;
								case WIND_DIR_UD_AUTO_STOP:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL3;
										break;
								case WIND_DIR_UD_LEVEL3:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL2;
									break;
								case WIND_DIR_UD_LEVEL2:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL1;
									break;
								case WIND_DIR_UD_LEVEL1:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_AUTO;
									break;
								default:
									G_WindDirUd[G_SystemMode] = WIND_DIR_UD_LEVEL1;
									break;
							}
							Vrf_CmdJoinQueue(CMD_TYPE_4C_UP_WIND_DIR,CMD_NO_REPLY, CMD_FORMAT_SETTING);
							Buzzer_KeySoundEnable();
						}
						else if (G_UdWindDirGroup[G_SystemMode]  == UD_WIND_DIR_GROUP_ONLY_AUTO)
						{
							G_WindDirUd[G_SystemMode] = WIND_DIR_UD_AUTO;
							Vrf_CmdJoinQueue(CMD_TYPE_4C_UP_WIND_DIR,CMD_NO_REPLY, CMD_FORMAT_SETTING);
							Buzzer_KeySoundEnable();
						}
						break;
					case SETTING_MODE_LR_WIND:
						// ���п��ƽ�ֹ��         
						if (G_CentralCtrBanFlag & WIND_DIR_SW_BAN)
						{
							G_CtlBanSwAction = CTL_BAN_SW_ACT;
							G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
							return;
						}
						
						if (G_LrWindDirGroup == LR_WIND_DIR_GROUP_5)
						{
							switch (G_WindDirLr[G_SystemMode])
							{
								case WIND_DIR_LR_AUTO:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_AUTO_STOP;
									break;
								case WIND_DIR_LR_AUTO_STOP:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL3;
										break;
								case WIND_DIR_LR_LEVEL3:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL1;
									break;
								case WIND_DIR_LR_LEVEL1:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL2;
									break;
								case WIND_DIR_LR_LEVEL2:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL4;
									break;
								case WIND_DIR_LR_LEVEL4:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL5;
									break;
								case WIND_DIR_LR_LEVEL5:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_AUTO;
									break;
								default:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL3;
									break;
							}
							Buzzer_KeySoundEnable();
							Vrf_CmdJoinQueue(CMD_TYPE_4C_LR_WIND_DIR,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						}
						else if (G_LrWindDirGroup == LR_WIND_DIR_GROUP_3)
						{
							switch (G_WindDirLr[G_SystemMode])
							{
								case WIND_DIR_LR_AUTO:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_AUTO_STOP;
									break;
								case WIND_DIR_LR_AUTO_STOP:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL3;
										break;
								case WIND_DIR_LR_LEVEL3:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL1;
									break;
								case WIND_DIR_LR_LEVEL1:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL5;
									break;
								case WIND_DIR_LR_LEVEL5:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_AUTO;
									break;
								default:
									G_WindDirLr[G_SystemMode] = WIND_DIR_LR_LEVEL3;
									break;
							}
							Buzzer_KeySoundEnable();
							Vrf_CmdJoinQueue(CMD_TYPE_4C_LR_WIND_DIR,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						}
						else if (G_LrWindDirGroup == LR_WIND_DIR_GROUP_ONLY_AUTO)
						{
							G_WindDirLr[G_SystemMode] = WIND_DIR_LR_AUTO;
							Buzzer_KeySoundEnable();
							Vrf_CmdJoinQueue(CMD_TYPE_4C_LR_WIND_DIR,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						}
						break;
					case SETTING_MODE_FUNCTION:
						FunctionArea6_KeyUp();
						break;
				}
			}
			else if (G_KeyDownType==KEY_TYPE_CONTINUE)
			{
				FunctionArea6_KeyUp();
			}
		}
		else
		{
			// ���п��ƽ�ֹ��         
			if (G_CentralCtrBanFlag & TEMPE_SW_BAN)
			{
				G_CtlBanSwAction = CTL_BAN_SW_ACT;
				G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
				return;
			}
			
			if (G_SystemMode == SYSTEM_MODE_WIND)
				return;
			if (G_TryRun)
				return;
			switch (G_SystemMode)
			{
				case SYSTEM_MODE_AUTO:
					tempe_max =G_AutoTempMax;
					tempe_min = G_AutoTempMin;
					break;
				case SYSTEM_MODE_WARM:
					tempe_max =G_WarmTempMax;
					tempe_min = G_WarmTempMin;
					break;
				case SYSTEM_MODE_COLD:
					tempe_max =G_ColdTempMax;
					tempe_min = G_ColdTempMin;
					break;
				case SYSTEM_MODE_WET:
					tempe_max =G_WetTempMax;
					tempe_min = G_WetTempMin;
					break;
			}
			
			if ((G_SystemTemp[G_SystemMode]<tempe_max)&&(G_SystemTemp[G_SystemMode]>=tempe_min))
				G_SystemTemp[G_SystemMode]++;
			else
				G_SystemTemp[G_SystemMode] = tempe_max;

			G_TempSendCount = 0;

			// �¶���ʱ5s����       
			G_VrfTempSendFlag = 1;
			G_VrfTempSendCount = 0;
			//Vrf_CmdJoinQueue(CMD_TYPE_4C_TEMPE, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			if (G_KeyDownType == KEY_TYPE_SHORT)
				Buzzer_KeySoundEnable();
			else
				G_KeyReleaseBz = 1;
		}
	}
}

/**************************************************************/
/**
*	@brief	�ϰ��� ��ϸ�ͼ���Ŀ�趨����   
*/
/**************************************************************/
static void UpKey_Pro(void)
{
	if ((G_KeyDownType == KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		if (G_ProSetting == PRO_NO_SET)
			return;
		if (G_ProSetting == PRO_SETTING_LEVEL1)
		{
			if (G_ProFlag == PRO_FLAG_CODE_SEND)
			{
				G_ProFlag = 0;
				if (G_ProType == PRO_TYPE_DETAIL)
					Vrf_CmdJoinQueue(CMD_TYPE_02_F1, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				else if (G_ProType == PRO_TYPE_SIMPLE)
					Vrf_CmdJoinQueue(CMD_TYPE_02_F3, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				else if (G_ProType == PRO_TYPE_OUTDOOR_DETAIL)
					Vrf_CmdJoinQueue(CMD_TYPE_16_F1_F5, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
				
				if (G_KeyDownType == KEY_TYPE_SHORT)
					Buzzer_KeySoundEnable();
				else
					G_KeyReleaseBz = 1;
			}
		}
		else if (G_ProSetting == PRO_SETTING_LEVEL2)
		{
			if (G_ProType==PRO_TYPE_OUTDOOR_DETAIL)
			{
				if (G_ProFlag == PRO_FLAG_CODE_SEND)
				{
					G_ProFlag = 0;
					Vrf_CmdJoinQueue(CMD_TYPE_16_F5_F1, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
					if (G_KeyDownType == KEY_TYPE_SHORT)
						Buzzer_KeySoundEnable();
					else
						G_KeyReleaseBz = 1;
				}
			}
			else
			{
				if ((G_ProData>=G_ProDataLL)&&(G_ProData<G_ProDataUL))
					G_ProData++;
				else if (G_ProData==99)
					G_ProData = G_ProDataLL;
				else
				{
					if (G_ProDataA9)
						G_ProData = 99;
					else
						G_ProData = G_ProDataLL;
				}
				if (G_KeyDownType == KEY_TYPE_SHORT)
					Buzzer_KeySoundEnable();
				else
					G_KeyReleaseBz = 1;
			}
			
			
		}
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���   ң���������趨�Ĵ���   
*/
/**************************************************************/
static void UpKey_RemoFun(void)
{
	if (G_RemoFunSet == REMO_FUN_SET_PROJECT)
	{
		if ((G_KeyDownType == KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
		{
			G_RemoFunStage++;
			if (G_RemoFunStage > REMO_FUN_STAGE_BZ_STATE)
			{
				G_RemoFunStage = REMO_FUN_STAGE_REMO_ADDR;
			}
			// �趨����Ŀ�趨ֵ   
			G_RemoRoleBack = G_RemoRole;			
			G_RemoModeBack = G_RemoMode;			
			G_ServerRoleBack = G_ServerRole;	
			G_BLTimeLevelBack = G_BLTimeLevel;
			G_BLLevelBack = G_BL.level;
			G_LedLevelBack = G_Led.level;
			G_BzModeBack = G_BzMode;
			if (G_KeyDownType == KEY_TYPE_SHORT)
				Buzzer_KeySoundEnable();
			else
				G_KeyReleaseBz = 1;
		}
	}
	else if (G_RemoFunSet == REMO_FUN_SET_DATA)
	{
		if ((G_KeyDownType == KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
		{
			switch (G_RemoFunStage)
			{
				case REMO_FUN_STAGE_REMO_ADDR:
					if (G_RemoRole==REMO_ROLE_MASTER)
					{
						G_RemoRole = REMO_ROLE_SLAVE;
					}
					else 
					{
						G_RemoRole = REMO_ROLE_MASTER;
					}
					break;
				case REMO_FUN_STAGE_TEST_MODE:
					if (G_RemoMode == REMO_MODE_NORMAL)
						G_RemoMode = REMO_MODE_TEST;
					else
						G_RemoMode = REMO_MODE_NORMAL;
					break;
				case REMO_FUN_STAGE_SERVER:
					if (G_ServerRole == SERVER_ROLE_OUTDOOR)
						G_ServerRole = SERVER_ROLE_INDOOR;
					else
						G_ServerRole = SERVER_ROLE_OUTDOOR;
					break;
				case REMO_FUN_STAGE_BL_TIME:
					G_BLTimeLevel++;
					if (G_BLTimeLevel>4)
						G_BLTimeLevel = 0;
					if (G_BLTimeLevel == 4)
						G_BL.lightTime = 0;
					else
						G_BL.lightTime = (G_BLTimeLevel+1)*5;
					break;
				case REMO_FUN_STAGE_BL_LEVEL:
					G_BL.level++;
					if (G_BL.level > BL_LIGHT_LEVEL_HIGH)
						G_BL.level = BL_LIGHT_LEVEL_LOW;
					break;
				case REMO_FUN_STAGE_PW_LEVEL:
					G_Led.level++;
					if (G_Led.level > LED_LIGHT_LEVEL10)
						G_Led.level = LED_LIGHT_LEVEL1;
					G_Led.levelChange = 1;
					break;
				case REMO_FUN_STAGE_BZ_STATE:
					if (G_BzMode == BZ_ENABLE)
						G_BzMode = BZ_DISABLE;
					else 
						G_BzMode = BZ_ENABLE;
					break;
			}
			if (G_KeyDownType == KEY_TYPE_SHORT)
				Buzzer_KeySoundEnable();
			else
				G_KeyReleaseBz = 1;
		}
	}
	else if (G_RemoFunSet == REMO_FUN_SET_FINISH)
	{
		if ((G_KeyReleaseType==KEY_TYPE_SHORT)&&(G_Key.flag==KEY_FLAG_RELEASE))
		{
			G_RemoFunSet = REMO_FUN_SET_PROJECT;
			Buzzer_KeySoundEnable();
		}
	}
}
/**************************************************************/
/**
*	@brief	�ϰ���  �쳣��ѯ����   
*/
/**************************************************************/
static void UpKey_ErrorIndex(void)
{
	if ((G_KeyDownType==KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		G_ErrorObj++;
		if (G_ErrorObj>3)
			G_ErrorObj = 0;

		G_ErrorIndexSysNum = 0;
		G_ErrorIndexIndoorNum = 0;
		G_ErrorIndex = 0;
		Vrf_CmdJoinQueue(CMD_TYPE_27, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		if (G_KeyDownType == KEY_TYPE_SHORT)
			Buzzer_KeySoundEnable();
		else
			G_KeyReleaseBz = 1;
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���  ������ģʽ����   
*/
/**************************************************************/
static void UpKey_ServerIndex(void)
{
	if ((G_KeyDownType==KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		G_ServerObj++;
		if (G_ServerObj>SERVER_OBJ_MAX)
			G_ServerObj = SERVER_OBJ_MIN;
		if (G_ServerObj == 1)
			G_ServerObj = 2;
		G_ScComCnt = 0;
		G_ServerRecFeedBack = 0;
		if ((G_ServerObj!=0x00)&&(G_ServerObj!=0x01))
			Vrf_CmdJoinQueue(CMD_TYPE_2C_EXPAND, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		else
			G_ServerRecFeedBack = 1;
		
		if (G_KeyDownType == KEY_TYPE_SHORT)
			Buzzer_KeySoundEnable();
		else
			G_KeyReleaseBz = 1;
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���  �Զ���ַ   
*/
/**************************************************************/
static void UpKey_AutoAddr(void)
{
	if ((G_KeyDownType==KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		if (G_AutoAddrSet == AUTO_ADDR_SET_TYPE)
		{
			if (G_AutoAddrType == AUTO_ADDR_AA)
				G_AutoAddrType = AUTO_ADDR_A1;
			else
				G_AutoAddrType = AUTO_ADDR_AA;
			if (G_KeyDownType == KEY_TYPE_SHORT)
				Buzzer_KeySoundEnable();
			else
				G_KeyReleaseBz = 1;
		}
		else if (G_AutoAddrSet == AUTO_ADDR_SET_SYSTEM)
		{
			G_SystemType++;
			if (G_SystemType > SYSTEM_TYPE_MAX)
				G_SystemType = SYSTEM_TYPE_MIN;

			if (G_KeyDownType == KEY_TYPE_SHORT)
				Buzzer_KeySoundEnable();
			else
				G_KeyReleaseBz = 1;
		}
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���  �ֶ���ַ   
*/
/**************************************************************/
static void UpKey_ManualAddr(void)
{
	uint8_t i;
	if (G_ManualAddrSet != MANUAL_ADDR_SET_FINISH)
	{
		if ((G_KeyDownType==KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
		{
			if (G_ManualAddrSet == MANUAL_ADDR_SET_SYSTEM)
			{
				G_ManualSystemNum++;
				if (G_ManualSystemNum > 29)
					G_ManualSystemNum = 0;
				if (G_KeyDownType == KEY_TYPE_SHORT)
					Buzzer_KeySoundEnable();
				else
					G_KeyReleaseBz = 1;
			}
			else if(G_ManualAddrSet == MANUAL_ADDR_SET_INDOOR)
			{
				if (G_IndoorMacNum > 1)
				{
					G_ManualIndoorNum++;						
					if (G_ManualIndoorNum >= G_IndoorMacNum)
					{
						G_ManualIndoorNum = 0;
					}
					G_ManualAddrStep = MANUAL_ADDR_STEP3;
					G_ManualCmdCnt = 0;
				}
				
				if (G_KeyDownType == KEY_TYPE_SHORT)
					Buzzer_KeySoundEnable();
				else
					G_KeyReleaseBz = 1;
			}
			else if (G_ManualAddrSet == MANUAL_ADDR_SET_ADDR)
			{
				if (G_IndoorMacNum>1)
				{
					G_ManualAddr++;
					if (G_ManualAddr > 63)
						G_ManualAddr = 0;
					for (i=0; i<G_IndoorMacNum; i++)
					{
						if ((G_ManualAddr == G_LicIndoorNum[i])&&(G_ManualAddr!=G_LicIndoorNum[G_ManualIndoorNum]))
						{
							G_ManualAddr++;
							if (G_ManualAddr > 63)
								G_ManualAddr = 0;
						}
					}
				}
				if (G_KeyDownType == KEY_TYPE_SHORT)
					Buzzer_KeySoundEnable();
				else
					G_KeyReleaseBz = 1;
			}
		}
	}
	else
	{
		if ((G_KeyReleaseType==KEY_TYPE_SHORT)&&(G_Key.flag==KEY_FLAG_RELEASE))
		{
			G_ManualAddrSet = MANUAL_ADDR_SET_ADDR;
			Buzzer_KeySoundEnable();
		}
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���  ���������ģʽ����  
*/
/**************************************************************/
static void UpKey_OutdoorNormal(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_OutdoorIndex < OUTDOOR_INDEX_5)
		{
			G_8BKeyValue = KEY_8B_UP;
			Vrf_CmdJoinQueue(CMD_TYPE_8B_KEY,CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			Vrf_CmdJoinQueue(CMD_TYPE_19_KEY,CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
			Buzzer_KeySoundEnable();
		}
		
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���  ������쳣��ѯ����   
*/
/**************************************************************/
static void UpKey_OutdoorErrorIndex(void)
{
	if ((G_KeyDownType==KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		G_ErrorObj++;
		if (G_ErrorObj>7)
			G_ErrorObj = 0;

		G_ErrorIndexSysNum = 0;
		G_ErrorIndexIndoorNum = 0;
		G_ErrorIndex = 0;
		Vrf_CmdJoinQueue(CMD_TYPE_27, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		if (G_KeyDownType == KEY_TYPE_SHORT)
			Buzzer_KeySoundEnable();
		else
			G_KeyReleaseBz = 1;
	}
}

/**************************************************************/
/**
*	@brief	�ϰ���  ���������ģʽ����   
*/
/**************************************************************/
static void UpKey_OutdoorServerIndex(void)
{
	if ((G_KeyDownType==KEY_TYPE_SHORT)||(G_KeyDownType==KEY_TYPE_CONTINUE))
	{
		G_ServerObj++;
		if (G_ServerObj>SERVER_OBJ_MAX)
			G_ServerObj = SERVER_OBJ_MIN;
		if (G_ServerObj == 1)
			G_ServerObj = 2;
		G_ScComCnt = 0;
		G_ServerRecFeedBack = 0;
		if ((G_ServerObj!=0x00)&&(G_ServerObj!=0x01))
			Vrf_CmdJoinQueue(CMD_TYPE_2C, CMD_HAVE_REPLY, CMD_FORMAT_REQUEST);
		else
			G_ServerRecFeedBack = 1;
		
		if (G_KeyDownType == KEY_TYPE_SHORT)
			Buzzer_KeySoundEnable();
		else
			G_KeyReleaseBz = 1;
	}
}

