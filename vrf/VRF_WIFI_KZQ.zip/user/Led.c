#define _EXTERN_LED_H_

#include "Common.h"

/**********************************************************/
/*
*	@brief LED�Ĵ�����ʼ������   
*/
/**********************************************************/
void Led_RegInit(void)
{
	TT0 |= _0010_TAU_CH4_STOP_TRG_ON;
    TOE0 &= ~_0010_TAU_CH4_OUTPUT_ENABLE;
    TO0 |= BIT4;   
}

/**********************************************************/
/*
*	@brief LED������ʼ������   
*/
/**********************************************************/
void Led_RamInit(void)
{
	G_BL.state = LIGHT_ON;			// ������������    
	G_Led.state = LIGHT_OFF;		// ����������    
}


/**********************************************************/
/*
*	@brief 	LED�������� 
*	@detail ��Դ�ƺͱ�������ȴ���(PWM����)  
*/
/**********************************************************/
void Led_Process(void)
{
	Led_PowerLightDeal();
	Led_BackLightDeal();
}
/**********************************************************/
/*
*	@brief ��Դ�Ƶ���     
*/
/**********************************************************/
void PowerLight_On(void)
{
	G_Led.count = 0;
	G_Led.state = LIGHT_ON;
}

/**********************************************************/
/*
*	@brief ��Դ�ƹر�       
*/
/**********************************************************/
void PowerLight_Off(void)
{
	G_Led.count = 0;
	G_Led.state = LIGHT_OFF;
}

/**********************************************************/
/*
*	@brief ��Դ�����ȴ�������(PWM����) 
*/
/**********************************************************/
void Led_PowerLightDeal(void)
{

	if (G_TestMode==0)
	{
		if (GuiTaskMode ==OUTDOOR_NORMAL_TAST)
		{
			switch (G_LedStatus)
			{
				case 0:
					PowerLight_Off();
					break;
				case 1:
					PowerLight_On();
					break;
				case 2:
					if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
						PowerLight_On();
					else
						PowerLight_Off();
					break;
			}
		}
		else
		{
			if (G_SystemStatus == SYSTEM_STATUS_OFF)
				PowerLight_Off();
			else
			{
				if (G_ErrorCode!=0)
				{
					if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
						PowerLight_On();
					else
						PowerLight_Off();
				}
				else
					PowerLight_On();
			}
		}
	}
	
	//ͨ��0Ϊ�� ͨ��4Ϊ�� ���  
	if (G_Led.state)
	{	
		/* ������ԴLED�����ȵ�PWM�� */
		if (((TOE0&BIT4)==0)||(G_Led.levelChange))
		{
			TDR04 = (TDR00/10)*(10-G_Led.level);
			TOE0 |=  _0010_TAU_CH4_OUTPUT_ENABLE ;
			TS0 |=  _0010_TAU_CH4_START_TRG_ON ;
			G_Led.levelChange = 0;
		}
	}
	else
	{
		/* �ر�PWM,�رյ�Դ��    */
		if (TOE0 & BIT4)
		{
			TT0 |=  _0010_TAU_CH4_STOP_TRG_ON ;
			TOE0 &=  ~_0010_TAU_CH4_OUTPUT_ENABLE ;
			TO0 |= BIT4;   ////
		}
	}
}

/**********************************************************/
/*
*	@brief �������     
*/
/**********************************************************/
void BL_On(void)
{
	G_BL.count = 0;
	G_BL.state = LIGHT_ON;
}

/**********************************************************/
/*
*	@brief ����ر�       
*/
/**********************************************************/
void BL_Off(void)
{
	G_BL.count = 0;
	G_BL.state = LIGHT_OFF;
}

/**********************************************************/
/*
*	@brief ��������ȴ�������(PWM����)  
*/
/**********************************************************/
void Led_BackLightDeal(void)
{
	if (G_TestMode)
		return;
	//ͨ��0Ϊ�� ͨ��3Ϊ�� ���  
	if (G_BL.state)
	{
		if (G_BL.lightTime != 0)
		{
			if (G_BL.level==BL_LIGHT_LEVEL_HIGH)
			{
				BL_TURN_ON_HIGH();
			}
			else if (G_BL.level==BL_LIGHT_LEVEL_MID)
			{
				BL_TURN_ON_MID();
			}
			else
			{
				BL_TURN_ON_LOW();
			}
		}
	}
	else
	{
		/* �ر�PWM,�رձ���   */
		BL_TURN_OFF();
	}
}

/**********************************************************/
/*
*	@brief 	���������ʱ    
*	@note	�˺���ÿ10ms����һ��   
*/
/**********************************************************/
void BL_Count(void)
{
	if (G_TestMode)
		return;
	if (G_BL.state == LIGHT_OFF)
		return;

	G_BL.count++;
	if (G_BL.count >= (uint16_t)G_BL.lightTime*100)
	{
		BL_Off();
	}
}

