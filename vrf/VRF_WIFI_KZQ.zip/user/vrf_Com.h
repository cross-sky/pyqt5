#include "r_cg_macrodriver.h"

#ifndef _VRF_CMD_H
#define _VRF_CMD_H

#ifdef _EXTERN_VRF_CMD_H_
#define EXT_VRF_CMD
#else
#define EXT_VRF_CMD extern
#endif


typedef enum
{
	DATA_SA = 0,
	DATA_DA = 1,
	DATA_CC = 2,
	DATA_BC = 3,
	DATA_EA = 4,
	DATA_CMD = 5,
}enum_all_cmd;

typedef enum
{
	DATA_FL = 6,
	DATA_RS = 7,
	DATA_FM = 8,
	DATA_CT = 9,
	DATA_CB = 10,
	DATA_HT = 11,
	DATA_HB = 12,
	DATA_DT = 13,
	DATA_DB = 14,
	DATA_FT = 15,
	DATA_FB = 16,
	DATA_FL2 = 17,
	
}enum_0x0a_cmd;

typedef enum
{
	DATA_D0 = 6,
	DATA_D1 = 7,
	DATA_D2 = 8,
	DATA_D3 = 9,
	DATA_D4 = 10,
	DATA_D5 = 11,
	DATA_D6 = 12,
	DATA_D7 = 13,
	DATA_D8 = 14,
	DATA_D9 = 15,
	DATA_D10 = 16,
	DATA_D11= 17,
	DATA_D12 = 18,
	DATA_D13 = 19,
}enum_0x81_cmd;

typedef enum
{
	DATA_FET_1 = 6,
	DATA_FET_2 = 7,
	DATA_FET_3 = 8,
	DATA_FET_4 = 9,
	DATA_FT_1 = 10,
	DATA_FT_2 = 11,
	DATA_FT_3 = 12,
	DATA_FT_EX = 13,
}enum_0x0F_cmd;

typedef enum
{
	DATA_FK = 6,
	DATA_P1_1 = 7,
	DATA_P1_2 = 8,
	DATA_P2 = 9,
	DATA_P3 = 10,
	DATA_P4 = 11,
}enum_0x10_cmd;

typedef enum
{
	DATA_DN = 6,
	DATA_PM = 7,
	DATA_UL = 8,
	DATA_LL = 9,
	DATA_A9 = 10,
}enum_0x02_cmd;

typedef enum
{
	DATA_AU0 = 6,
	DATA_AU1 = 7,
	DATA_AN = 8,
	DATA_CA = 9,
}enum_0x49_cmd;

typedef enum
{
	DATA_MON1 = 9,
	DATA_MON2 = 10,
}enum_0x2C_cmd;


/*****************************************/
/*
	G_SendFlag
*/
/*****************************************/
enum
{
	SEND_FLAG_BUSY = BIT0,		// �������ڷ�����   
	SEND_FLAG_INIT = BIT1,			// ���ݳ�ʼ����־      
	SEND_FLAG_WAIT_RES = BIT2,	// ���ݷ��͵ȴ�����  	   
	SEND_FLAG_OUTDOOR_INIT = BIT3,	// ������ڻ�ͨѶ    
};

/*****************************************/
/*
	G_VrfSend.initComLevel
*/
/*****************************************/
enum
{
	INIT_CMD_LEVEL0,
	INIT_CMD_LEVEL1,
	INIT_CMD_LEVEL2,
	INIT_CMD_LEVEL3,
	INIT_CMD_LEVEL4,
	INIT_CMD_LEVEL5,
	INIT_CMD_LEVEL6,
	INIT_CMD_LEVEL7,
	INIT_CMD_LEVEL8,
	INIT_CMD_LEVEL9,
	INIT_CMD_LEVEL10,
	INIT_CMD_LEVEL11,
	INIT_CMD_LEVEL12,
	INIT_CMD_LEVEL13,
	INIT_CMD_FINISH,
};


enum
{
	CMD_TYPE_06_REQ,				
	CMD_TYPE_06_REQ_EXPAND,		
	CMD_TYPE_06_SET_EXPAND,
	CMD_TYPE_0D,
	CMD_TYPE_0A,
	CMD_TYPE_81,
	CMD_TYPE_0F,
	CMD_TYPE_0C_0x30,
	CMD_TYPE_0C_0x40,
	CMD_TYPE_0C_0x48,
	CMD_TYPE_0C_0x4E,
	CMD_TYPE_10,
	CMD_TYPE_54,
	CMD_TYPE_08,
	CMD_TYPE_13,
	CMD_TYPE_45,
	CMD_TYPE_55,
	CMD_TYPE_51,
	CMD_TYPE_41_ON_OFF,
	CMD_TYPE_41_TRY_RUN,
	CMD_TYPE_42,
	CMD_TYPE_4C_TEMPE,
	CMD_TYPE_4C_WINDSPEED,
	CMD_TYPE_4C_UP_WIND_DIR,
	CMD_TYPE_4C_LR_WIND_DIR,
	CMD_TYPE_5C,
	CMD_TYPE_52,
	CMD_TYPE_58,
	CMD_TYPE_61,
	CMD_TYPE_61_EXPAND,
	CMD_TYPE_64_START,
	CMD_TYPE_64_STOP,
	CMD_TYPE_64_START_EXPAND,
	CMD_TYPE_64_STOP_EXPAND,
	CMD_TYPE_02_F1,
	CMD_TYPE_02_F2,
	CMD_TYPE_02_F3,
	CMD_TYPE_02_F4,
	CMD_TYPE_02_F5,
	CMD_TYPE_02_F7,
	CMD_TYPE_07,
	CMD_TYPE_62_EEP_EX,
	CMD_TYPE_62,
	CMD_TYPE_62_EXPAND,
	CMD_TYPE_4B,
	CMD_TYPE_49,
	CMD_TYPE_2C,
	CMD_TYPE_2C_EXPAND,
	CMD_TYPE_67_START,
	CMD_TYPE_67_COMFIRM,
	CMD_TYPE_0E,
	CMD_TYPE_0E_EXPAND,
	CMD_TYPE_63_EXPAND,
	CMD_TYPE_5F,
	CMD_TYPE_27,
 
	CMD_TYPE_18,
	CMD_TYPE_19_REG,
	CMD_TYPE_19_KEY,
	CMD_TYPE_8B_REG,
	CMD_TYPE_8B_KEY,

	CMD_TYPE_16_INIT,
	CMD_TYPE_16_F1_F5,
	CMD_TYPE_16_F2_F5,
	CMD_TYPE_16_F5_F1,
	CMD_TYPE_16_F5_F2,
	CMD_TYPE_17,
};


enum
{
	CMD_FORMAT_SETTING = 0,
	CMD_FORMAT_REQUEST = 1,
	CMD_FORMAT_REPLY = 2,
	CMD_FORMAT_STATUS_CHANGE = 3,
};

enum
{
	CMD_NO_REPLY,
	CMD_HAVE_REPLY,
};

typedef union
{
	uint16_t add16;
	struct
	{
		uint8_t addL;
		uint8_t addH; 
	}add8;
}union_add_type;



#define  INIT_CMD_TIME_500MS		500   		// 100CHR����    100 * 11/2400 s    
#define  INIT_CMD_TIME_187MS		187			// 40CHR����    	 40 * 11/2400 s		


typedef struct
{
	uint8_t cmdType;
	uint8_t cmdReply;
	uint8_t cmdformat;
}struct_send_data_type;

#define BUFFER_LENGTH	30

EXT_VRF_CMD uint8_t G_SendFlag;		

EXT_VRF_CMD uint8_t G_SendData[BUFFER_LENGTH];
EXT_VRF_CMD uint8_t G_SendNowData;
EXT_VRF_CMD struct_send_data_type G_SendState;			// ��TX1����������     
EXT_VRF_CMD uint8_t G_SendDataLength;
EXT_VRF_CMD uint8_t G_SendSelfCheck;					// ����ָ��ʱ���Լ��־���Լ�ͨ����1        
EXT_VRF_CMD uint8_t G_SendCount;
#define	SEND_TIMEOUT_COUNT		14		// 14ms     
EXT_VRF_CMD uint8_t G_SendTimeoutCount;		// �����Լ��ʱ��     
EXT_VRF_CMD uint8_t G_InitCmdLevel;			// ���ڷ��Ͳ���     
EXT_VRF_CMD uint16_t G_SendErrorCount;		// �����޷���ʱ�ļ�ʱ       


extern uint16_t const G_ErrorTimeTable[8];		// 
EXT_VRF_CMD uint8_t G_CmdFormat;			// �������ͣ�Ҫ�����趨         
EXT_VRF_CMD uint8_t G_CmdNeedResponse;		// ��Ҫ����       

EXT_VRF_CMD uint8_t G_ResendCount;			// ���·����˶��ٴ�����   
EXT_VRF_CMD uint8_t G_CmdSendEnable;

EXT_VRF_CMD union_add_type G_RemoAdd;				// ң������ַ       
EXT_VRF_CMD union_add_type G_MainAdd;				// ϵͳ��ַ            

EXT_VRF_CMD uint8_t G_EepromReadAdd;		// ��ȡ��EEPROM���׵�ַ   
EXT_VRF_CMD uint8_t G_EepromReadNum;		// EEPROM��ȡ�ĳ���    
#define REC_DATA_NUM	32
EXT_VRF_CMD uint8_t G_RecDataTemp[REC_DATA_NUM];	// ���ܻ���    
EXT_VRF_CMD uint8_t G_RecData[REC_DATA_NUM];	// ���ܻ���    
EXT_VRF_CMD uint8_t G_RecCount;				// ���ջ������   


EXT_VRF_CMD uint8_t G_RecFinish;				// ������ɱ�־   

EXT_VRF_CMD uint8_t G_InitSendRequest;		// ���ڻ���������     

EXT_VRF_CMD uint16_t G_RecErrorCount; 		// ���մ����ʱ    



#define		CLEAR_BUFFER_COUNT_27MS	27		// 27ms ��Լ6CHR    

EXT_VRF_CMD uint8_t G_ClearBufferCount;

#define REG_COM_COUNT_30S		30				//30s
#define REG_COM_COUNT_5S		5				//5s
EXT_VRF_CMD uint8_t G_RegularComCnt;			//����ͨѶʱ��   

enum
{
	REGULAR_CMD_OC_40,
	REGULAR_CMD_OC_48,
	REGULAR_CMD_OC_4E,
};
EXT_VRF_CMD uint8_t G_RegularCmd0cLevel;



#define CMD_LIST_LENGTH			10
EXT_VRF_CMD struct_send_data_type G_CmdList[CMD_LIST_LENGTH];
EXT_VRF_CMD uint8_t G_CmdListCount;
#define QUEUE_SEND_SPACING		320
EXT_VRF_CMD uint16_t G_QueueSendSpacing;

EXT_VRF_CMD uint8_t G_Cmd54Resend;


uint8_t uart1_send(uint8_t const dat); 
void Vrf_DataSend(void); 
void Vrf_ClearSend(void); 
void Vrf_InitCommunication(void);
void Vrf_OutdoorInitCom(void);
void Vrf_RegularCommunication(void); 
void Vrf_OutdoorRegCom(void);
void Vrf_ScRegularCom(void);
void Vrf_Count1msDeal(void);
void Vrf_SendDataWaitCount(void);
void Vrf_GetCmdData(void);
void SendDat_TimeoutCount(void);
void cmd06(void);
void cmd0D(void);
void cmd0A(void);
void cmd81(void);
void cmd0F(void);
void cmd0C(void);
void cmd10(void);
void cmd08(void);
void cmd13(void);
void cmd45(void);
void cmd55(void);
void cmd51(void);
void cmdxx(uint8_t cmd_temp);
void cmd41(void);
void cmd42(void);
void cmd4C(void);
void cmd54(void);
void cmd5C(void);
void cmd52(void);
void cmd58(void);
void cmd61(void);
void cmd64(void);
void cmd02(void);
void cmd07(void);
void cmd62(void);
void cmd4B(void);
void cmd49(void);
void cmd2C(void);
void cmd67(void);
void cmd0E(void);
void cmd63(void);
void cmd5F(void);
void cmd27(void);
void cmd18(void);
void cmd19(void);
void cmd8B(void);
void cmd16(void);
void cmd17(void);
void Vrf_SelfRecCheck(uint8_t rec_data);
void Vrf_ComRecDeal(uint8_t rec_data);
void ClearRecBuffer(void);
void FitTimeClearRecBuffer(void);
void Vrf_RecDataDeal(void);
void Res_RemocJudge(viod);
void Res_Cmd06(void);
void Res_Cmd0D(void);
void Res_Cmd0A(void);
void Res_Cmd81(void);
void Res_Cmd0F(void);
void Parse_Cmd0FWindSpeed(uint8_t *windspeed_temp,uint8_t level_temp, uint8_t strengthen_temp);
void Res_Cmd0C(void);
void Res_Cmd10(void);
void Parse_CmdWindDir(uint8_t *wind_dir,uint8_t dat);
void Res_Cmd54(void);
void Res_Cmd08(void);
void Res_Cmd13(void);
void Res_Cmd45(void);
void Res_Cmd55(void);
void Res_cmd61(void);
void Res_cmd62(void);
void Res_Cmd02(void);
void Res_Cmd49(void);
void Res_Cmd2C(void);
void Res_Cmd67(void);
void Res_Cmd0E(void);
void Res_Cmd5F(void);
void Res_Cmd27(void);
void Res_Cmd18(void);
void Res_Cmd19(void);
void Res_Cmd8B(void);
void Res_Cmd16(void);
void Res_CmdA1(void);
void Res_CmdA2(void);
void Res_CmdA3(void);
void Vrf_SendList(void);
uint8_t Vrf_CmdJoinQueue(uint8_t cmd_type,uint8_t cmd_format,uint8_t cmd_reply);
uint8_t Vrf_CmdTakeOutQueue(struct_send_data_type *cmd_type_temp);
void Vrf_CmdJumpQueue(uint8_t cmd_type, uint8_t cmd_reply, uint8_t cmd_format);
void Vrf_CmdClearQueue(void);
uint16_t Get_RandomDat(void);
void Vrf_TempSendDeal(void);


#endif
