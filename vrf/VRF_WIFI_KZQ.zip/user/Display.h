#include "r_cg_macrodriver.h"

#ifndef _DISPLAY_H
#define _DISPLAY_H

#ifdef _EXTERN_DISPLAY_H_
#define EXT_DISPLAY  
#else 
#define EXT_DISPLAY extern 
#endif

#define LCD_BUF_LEN  35

/***********************************************************************/
/** ��תģʽ��ʾ  **/
#define SHOW_RUN_MODE_AUTO					BS(Lcd_Buf[18],0)
#define SHOW_RUN_MODE_WARM					BS(Lcd_Buf[18],1)
#define SHOW_RUN_MODE_COLD					BS(Lcd_Buf[18],2)
#define SHOW_RUN_MODE_WET					BS(Lcd_Buf[18],3)
#define SHOW_RUN_MODE_WIND					BS(Lcd_Buf[17],3)
/***********************************************************************/

/***********************************************************************/
/**  ������ʾ  **/
#define SHOW_WIND_DIR_UD_ICON			BS(Lcd_Buf[0],3)
#define SHOW_WIND_DIR_UD_AUTO  		{BS(Lcd_Buf[0],2);BS(Lcd_Buf[0],1);}
#define SHOW_WIND_DIR_UD_AUTO_STOP  BS(Lcd_Buf[0],1)
#define SHOW_WIND_DIR_UD_LEVEL1		{BS(Lcd_Buf[0],0);BS(Lcd_Buf[0],1);}
#define SHOW_WIND_DIR_UD_LEVEL2		{BS(Lcd_Buf[1],0);BS(Lcd_Buf[0],1);}
#define SHOW_WIND_DIR_UD_LEVEL3		{BS(Lcd_Buf[1],1);BS(Lcd_Buf[0],1);}
#define SHOW_WIND_DIR_UD_LEVEL4		{BS(Lcd_Buf[1],2);BS(Lcd_Buf[0],1);}
#define SHOW_WIND_DIR_UD_LEVEL5		{BS(Lcd_Buf[1],3);BS(Lcd_Buf[0],1);}
#define SHOW_WIND_DIR_UD_SET_AUTO	{BS(Lcd_Buf[0],2);BS(Lcd_Buf[0],0);BS(Lcd_Buf[1],0);BS(Lcd_Buf[1],1);BS(Lcd_Buf[1],2);BS(Lcd_Buf[1],3);BS(Lcd_Buf[0],1);}

#define SHOW_WIND_DIR_LR_ICON			BS(Lcd_Buf[2],2)
#define SHOW_WIND_DIR_LR_AUTO  		{BS(Lcd_Buf[2],3);BS(Lcd_Buf[2],1);}
#define SHOW_WIND_DIR_LR_AUTO_ATOP	 BS(Lcd_Buf[2],1)	
#define SHOW_WIND_DIR_LR_LEVEL1		{BS(Lcd_Buf[2],0);BS(Lcd_Buf[2],1);}
#define SHOW_WIND_DIR_LR_LEVEL2		{BS(Lcd_Buf[3],0);BS(Lcd_Buf[2],1);}
#define SHOW_WIND_DIR_LR_LEVEL3		{BS(Lcd_Buf[3],1);BS(Lcd_Buf[2],1);}
#define SHOW_WIND_DIR_LR_LEVEL4		{BS(Lcd_Buf[3],2);BS(Lcd_Buf[2],1);}
#define SHOW_WIND_DIR_LR_LEVEL5		{BS(Lcd_Buf[3],3);BS(Lcd_Buf[2],1);}
#define SHOW_WIND_DIR_LR_SET_AUTO	{BS(Lcd_Buf[2],3);BS(Lcd_Buf[2],0);BS(Lcd_Buf[3],0);BS(Lcd_Buf[3],1);BS(Lcd_Buf[3],2);BS(Lcd_Buf[3],3);BS(Lcd_Buf[2],1);}
/***********************************************************************/

/***********************************************************************/
/**  ������ʾ  **/
#define SHOW_WIND_SPEED_AUTO			{BS(Lcd_Buf[17],0);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_MUTE			{BS(Lcd_Buf[17],1);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_STRONG		{BS(Lcd_Buf[17],2);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_LEVEL1		{BS(Lcd_Buf[15],3);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_LEVEL2		{BS(Lcd_Buf[15],3);BS(Lcd_Buf[15],2);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_LEVEL3		{BS(Lcd_Buf[15],3);BS(Lcd_Buf[15],2);BS(Lcd_Buf[15],1);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_LEVEL4		{BS(Lcd_Buf[15],3);BS(Lcd_Buf[15],2);BS(Lcd_Buf[15],1);BS(Lcd_Buf[15],0);BS(Lcd_Buf[16],1);}
#define SHOW_WIND_SPEED_LEVEL5		{BS(Lcd_Buf[15],3);BS(Lcd_Buf[15],2);BS(Lcd_Buf[15],1);BS(Lcd_Buf[15],0);BS(Lcd_Buf[16],0);BS(Lcd_Buf[16],1);}
/***********************************************************************/

/***********************************************************************/
/**  ϵͳ������ʾ  **/
#define SHOW_MACHINEMODEL_ICON		BS(Lcd_Buf[5],3)
#define SHOW_NUMBER_ICON				BS(Lcd_Buf[9],3)

#define SHOW_SEG8A				BS(Lcd_Buf[4],3)
#define SHOW_SEG8B				BS(Lcd_Buf[5],2)
#define SHOW_SEG8C				BS(Lcd_Buf[5],0)
#define SHOW_SEG8D				BS(Lcd_Buf[4],0)
#define SHOW_SEG8E				BS(Lcd_Buf[4],1)
#define SHOW_SEG8F				BS(Lcd_Buf[4],2)
#define SHOW_SEG8G				BS(Lcd_Buf[5],1)
#define SEG8_SHOW_0				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;}
#define SEG8_SHOW_1				{SHOW_SEG8B;SHOW_SEG8C;}	
#define SEG8_SHOW_2				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8G;}
#define SEG8_SHOW_3				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8G;}
#define SEG8_SHOW_4				{SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_5				{SHOW_SEG8A;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_6				{SHOW_SEG8A;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_7				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8C;}
#define SEG8_SHOW_8				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_9				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_A				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_B				{SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}		
#define SEG8_SHOW_C				{SHOW_SEG8A;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;}
#define SEG8_SHOW_D				{SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8G;}
#define SEG8_SHOW_E				{SHOW_SEG8A;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_F				{SHOW_SEG8A;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_G				{SHOW_SEG8A;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;}
#define SEG8_SHOW_DEC				SHOW_SEG8G
#define SEG8_SHOW_H				{SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}
#define SEG8_SHOW_J				{SHOW_SEG8B;SHOW_SEG8C;SHOW_SEG8D;SHOW_SEG8E;}
#define SEG8_SHOW_L				{SHOW_SEG8D;SHOW_SEG8E;SHOW_SEG8F;}
#define SEG8_SHOW_P				{SHOW_SEG8A;SHOW_SEG8B;SHOW_SEG8E;SHOW_SEG8F;SHOW_SEG8G;}


#define SHOW_SEG9A					BS(Lcd_Buf[6],3)
#define SHOW_SEG9B					BS(Lcd_Buf[7],2)
#define SHOW_SEG9C					BS(Lcd_Buf[7],0)
#define SHOW_SEG9D					BS(Lcd_Buf[6],0)
#define SHOW_SEG9E					BS(Lcd_Buf[6],1)
#define SHOW_SEG9F					BS(Lcd_Buf[6],2)
#define SHOW_SEG9G					BS(Lcd_Buf[7],1)
#define SEG9_SHOW_0				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;}
#define SEG9_SHOW_1				{SHOW_SEG9B;SHOW_SEG9C;}	
#define SEG9_SHOW_2				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9G;}
#define SEG9_SHOW_3				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9G;}
#define SEG9_SHOW_4				{SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_5				{SHOW_SEG9A;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_6				{SHOW_SEG9A;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_7				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9C;}
#define SEG9_SHOW_8				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_9				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_A				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_B				{SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}		
#define SEG9_SHOW_C				{SHOW_SEG9A;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;}
#define SEG9_SHOW_D				{SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9G;}
#define SEG9_SHOW_E				{SHOW_SEG9A;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_F				{SHOW_SEG9A;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_G				{SHOW_SEG9A;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;}
#define SEG9_SHOW_DEC				SHOW_SEG9G
#define SEG9_SHOW_H				{SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
#define SEG9_SHOW_J				{SHOW_SEG9B;SHOW_SEG9C;SHOW_SEG9D;SHOW_SEG9E;}
#define SEG9_SHOW_L				{SHOW_SEG9D;SHOW_SEG9E;SHOW_SEG9F;}
#define SEG9_SHOW_P				{SHOW_SEG9A;SHOW_SEG9B;SHOW_SEG9E;SHOW_SEG9F;SHOW_SEG9G;}
/***********************************************************************/

/***********************************************************************/
/**  ���ڱ����ʾ  **/
#define SHOW_SYSTEM_ICON				BS(Lcd_Buf[7],3)
#define SHOW_INDOOR_ICON				BS(Lcd_Buf[11],3)

#define SHOW_SEG10A				BS(Lcd_Buf[8],3)
#define SHOW_SEG10B				BS(Lcd_Buf[9],2)
#define SHOW_SEG10C				BS(Lcd_Buf[9],0)
#define SHOW_SEG10D				BS(Lcd_Buf[8],0)
#define SHOW_SEG10E				BS(Lcd_Buf[8],1)
#define SHOW_SEG10F				BS(Lcd_Buf[8],2)
#define SHOW_SEG10G				BS(Lcd_Buf[9],1)
#define SEG10_SHOW_0				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;}
#define SEG10_SHOW_1				{SHOW_SEG10B;SHOW_SEG10C;}	
#define SEG10_SHOW_2				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10G;}
#define SEG10_SHOW_3				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10G;}
#define SEG10_SHOW_4				{SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_5				{SHOW_SEG10A;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_6				{SHOW_SEG10A;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_7				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10C;}
#define SEG10_SHOW_8				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_9				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_A				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_B				{SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}		
#define SEG10_SHOW_C				{SHOW_SEG10A;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG9F;}
#define SEG10_SHOW_D				{SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10G;}
#define SEG10_SHOW_E				{SHOW_SEG10A;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_F				{SHOW_SEG10A;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_G				{SHOW_SEG10A;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;}
#define SEG10_SHOW_DEC				SHOW_SEG10G
#define SEG10_SHOW_H				{SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}
#define SEG10_SHOW_J				{SHOW_SEG10B;SHOW_SEG10C;SHOW_SEG10D;SHOW_SEG10E;}
#define SEG10_SHOW_L				{SHOW_SEG10D;SHOW_SEG10E;SHOW_SEG10F;}
#define SEG10_SHOW_P				{SHOW_SEG10A;SHOW_SEG10B;SHOW_SEG10E;SHOW_SEG10F;SHOW_SEG10G;}


#define SHOW_SEG11A				BS(Lcd_Buf[10],3)
#define SHOW_SEG11B				BS(Lcd_Buf[11],2)
#define SHOW_SEG11C				BS(Lcd_Buf[11],0)
#define SHOW_SEG11D				BS(Lcd_Buf[10],0)
#define SHOW_SEG11E				BS(Lcd_Buf[10],1)
#define SHOW_SEG11F				BS(Lcd_Buf[10],2)
#define SHOW_SEG11G				BS(Lcd_Buf[11],1)
#define SEG11_SHOW_0				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;}
#define SEG11_SHOW_1				{SHOW_SEG11B;SHOW_SEG11C;}	
#define SEG11_SHOW_2				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11G;}
#define SEG11_SHOW_3				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11G;}
#define SEG11_SHOW_4				{SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_5				{SHOW_SEG11A;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_6				{SHOW_SEG11A;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_7				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11C;}
#define SEG11_SHOW_8				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_9				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_A				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_B				{SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}		
#define SEG11_SHOW_C				{SHOW_SEG11A;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;}
#define SEG11_SHOW_D				{SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11G;}
#define SEG11_SHOW_E				{SHOW_SEG11A;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_F				{SHOW_SEG11A;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_G				{SHOW_SEG11A;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;}
#define SEG11_SHOW_DEC				SHOW_SEG11G
#define SEG11_SHOW_H				{SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}
#define SEG11_SHOW_J				{SHOW_SEG11B;SHOW_SEG11C;SHOW_SEG11D;SHOW_SEG11E;}
#define SEG11_SHOW_L				{SHOW_SEG11D;SHOW_SEG11E;SHOW_SEG11F;}
#define SEG11_SHOW_P				{SHOW_SEG11A;SHOW_SEG11B;SHOW_SEG11E;SHOW_SEG11F;SHOW_SEG11G;}

/***********************************************************************/


/***********************************************************************/
/**  �¶Ⱥ�ʱ������ʾ  **/
#define SHOW_PROJECT						BS(Lcd_Buf[19],3)
#define SHOW_PREHEAT						BS(Lcd_Buf[19],2)
#define SHOW_DEFROST						BS(Lcd_Buf[19],1)
#define SHOW_SETTING						BS(Lcd_Buf[19],0)

#define SHOW_WIFI_SINGAL_LEVEL0			BS(Lcd_Buf[24],3)
#define SHOW_WIFI_SINGAL_LEVEL1			{BS(Lcd_Buf[24],3);BS(Lcd_Buf[24],2);}
#define SHOW_WIFI_SINGAL_LEVEL2			{BS(Lcd_Buf[24],3);BS(Lcd_Buf[24],2);BS(Lcd_Buf[24],1);}
#define SHOW_WIFI_SINGAL_LEVEL3			{BS(Lcd_Buf[24],3);BS(Lcd_Buf[24],2);BS(Lcd_Buf[24],1);BS(Lcd_Buf[24],0);}

#define SHOW_TEMPE_UNIT					BS(Lcd_Buf[25],3)
#define SHOW_REMOTE						BS(Lcd_Buf[25],2)
#define SHOW_NO_FUNC						BS(Lcd_Buf[25],1)
#define SHOW_TIMER_ON						BS(Lcd_Buf[25],0)

#define SHOW_COL							BS(Lcd_Buf[31],3)
#define SHOW_POINT							BS(Lcd_Buf[29],3)
#define SHOW_HOUR_AFTER					BS(Lcd_Buf[27],3)
#define SHOW_CLEAN							BS(Lcd_Buf[26],3)
#define SHOW_TIMER_OFF_0					BS(Lcd_Buf[26],2)
#define SHOW_CYCLE							BS(Lcd_Buf[26],1)
#define SHOW_TIMER_OFF_1					BS(Lcd_Buf[26],0)


#define SHOW_SEG1A					BS(Lcd_Buf[20],0)
#define SHOW_SEG1B					BS(Lcd_Buf[21],0)
#define SHOW_SEG1C					BS(Lcd_Buf[21],3)
#define SHOW_SEG1D					BS(Lcd_Buf[20],3)
#define SHOW_SEG1E					BS(Lcd_Buf[20],2)
#define SHOW_SEG1F					BS(Lcd_Buf[20],1)
#define SHOW_SEG1G					BS(Lcd_Buf[21],2)
#define SHOW_SEG1H					BS(Lcd_Buf[21],1)
#define SEG1_SHOW_0				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;}
#define SEG1_SHOW_1				{SHOW_SEG1B;SHOW_SEG1C;}	
#define SEG1_SHOW_2				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1G;}
#define SEG1_SHOW_3				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1G;}
#define SEG1_SHOW_4				{SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_5				{SHOW_SEG1A;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_6				{SHOW_SEG1A;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_7				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1C;}
#define SEG1_SHOW_8				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_9				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_A				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_B				{SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}		
#define SEG1_SHOW_C				{SHOW_SEG1A;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;}
#define SEG1_SHOW_D				{SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1G;}
#define SEG1_SHOW_E				{SHOW_SEG1A;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_F				{SHOW_SEG1A;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_G				{SHOW_SEG1A;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;}
#define SEG1_SHOW_DEC				SHOW_SEG1G
#define SEG1_SHOW_ADD				{SHOW_SEG1G;SHOW_SEG1H;}
#define SEG1_SHOW_H				{SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}
#define SEG1_SHOW_J				{SHOW_SEG1B;SHOW_SEG1C;SHOW_SEG1D;SHOW_SEG1E;}
#define SEG1_SHOW_L				{SHOW_SEG1D;SHOW_SEG1E;SHOW_SEG1F;}
#define SEG1_SHOW_P				{SHOW_SEG1A;SHOW_SEG1B;SHOW_SEG1E;SHOW_SEG1F;SHOW_SEG1G;}

#define SHOW_SEG2A					BS(Lcd_Buf[22],0)
#define SHOW_SEG2B					BS(Lcd_Buf[23],0)
#define SHOW_SEG2C					BS(Lcd_Buf[23],3)
#define SHOW_SEG2D					BS(Lcd_Buf[22],3)
#define SHOW_SEG2E					BS(Lcd_Buf[22],2)
#define SHOW_SEG2F					BS(Lcd_Buf[22],1)
#define SHOW_SEG2G					BS(Lcd_Buf[23],2)
#define SEG2_SHOW_0				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;}
#define SEG2_SHOW_1				{SHOW_SEG2B;SHOW_SEG2C;}	
#define SEG2_SHOW_2				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2G;}
#define SEG2_SHOW_3				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2G;}
#define SEG2_SHOW_4				{SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_5				{SHOW_SEG2A;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_6				{SHOW_SEG2A;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_7				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2C;}
#define SEG2_SHOW_8				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_9				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_A				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_B				{SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}		
#define SEG2_SHOW_C				{SHOW_SEG2A;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;}
#define SEG2_SHOW_D				{SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2G;}
#define SEG2_SHOW_E				{SHOW_SEG2A;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_F				{SHOW_SEG2A;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_G				{SHOW_SEG2A;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;}
#define SEG2_SHOW_DEC				SHOW_SEG2G
#define SEG2_SHOW_H				{SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}
#define SEG2_SHOW_J				{SHOW_SEG2B;SHOW_SEG2C;SHOW_SEG2D;SHOW_SEG2E;}
#define SEG2_SHOW_L				{SHOW_SEG2D;SHOW_SEG2E;SHOW_SEG2F;}
#define SEG2_SHOW_P				{SHOW_SEG2A;SHOW_SEG2B;SHOW_SEG2E;SHOW_SEG2F;SHOW_SEG2G;}

#define SHOW_SEG4A					BS(Lcd_Buf[34],3)
#define SHOW_SEG4B					BS(Lcd_Buf[33],2)
#define SHOW_SEG4C					BS(Lcd_Buf[33],0)
#define SHOW_SEG4D					BS(Lcd_Buf[34],0)
#define SHOW_SEG4E					BS(Lcd_Buf[34],1)
#define SHOW_SEG4F					BS(Lcd_Buf[34],2)
#define SHOW_SEG4G					BS(Lcd_Buf[33],1)
#define SEG4_SHOW_0				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;}
#define SEG4_SHOW_1				{SHOW_SEG4B;SHOW_SEG4C;}	
#define SEG4_SHOW_2				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4G;}
#define SEG4_SHOW_3				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4G;}
#define SEG4_SHOW_4				{SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_5				{SHOW_SEG4A;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_6				{SHOW_SEG4A;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_7				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4C;}
#define SEG4_SHOW_8				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_9				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_A				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_B				{SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}		
#define SEG4_SHOW_C				{SHOW_SEG4A;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;}
#define SEG4_SHOW_D				{SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4G;}
#define SEG4_SHOW_E				{SHOW_SEG4A;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_F				{SHOW_SEG4A;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_G				{SHOW_SEG4A;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;}
#define SEG4_SHOW_DEC				SHOW_SEG4G
#define SEG4_SHOW_H				{SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}
#define SEG4_SHOW_J				{SHOW_SEG4B;SHOW_SEG4C;SHOW_SEG4D;SHOW_SEG4E;}
#define SEG4_SHOW_L				{SHOW_SEG4D;SHOW_SEG4E;SHOW_SEG4F;}
#define SEG4_SHOW_P				{SHOW_SEG4A;SHOW_SEG4B;SHOW_SEG4E;SHOW_SEG4F;SHOW_SEG4G;}

#define SHOW_SEG5A					BS(Lcd_Buf[32],3)
#define SHOW_SEG5B					BS(Lcd_Buf[31],2)
#define SHOW_SEG5C					BS(Lcd_Buf[31],0)
#define SHOW_SEG5D					BS(Lcd_Buf[32],0)
#define SHOW_SEG5E					BS(Lcd_Buf[32],1)
#define SHOW_SEG5F					BS(Lcd_Buf[32],2)
#define SHOW_SEG5G					BS(Lcd_Buf[31],1)
#define SEG5_SHOW_0				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;}
#define SEG5_SHOW_1				{SHOW_SEG5B;SHOW_SEG5C;}	
#define SEG5_SHOW_2				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5G;}
#define SEG5_SHOW_3				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5G;}
#define SEG5_SHOW_4				{SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_5				{SHOW_SEG5A;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_6				{SHOW_SEG5A;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_7				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5C;}
#define SEG5_SHOW_8				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_9				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_A				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_B				{SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}		
#define SEG5_SHOW_C				{SHOW_SEG5A;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;}
#define SEG5_SHOW_D				{SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5G;}
#define SEG5_SHOW_E				{SHOW_SEG5A;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_F				{SHOW_SEG5A;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_G				{SHOW_SEG5A;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;}
#define SEG5_SHOW_DEC				SHOW_SEG5G
#define SEG5_SHOW_H				{SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}
#define SEG5_SHOW_J				{SHOW_SEG5B;SHOW_SEG5C;SHOW_SEG5D;SHOW_SEG5E;}
#define SEG5_SHOW_L				{SHOW_SEG5D;SHOW_SEG5E;SHOW_SEG5F;}
#define SEG5_SHOW_P				{SHOW_SEG5A;SHOW_SEG5B;SHOW_SEG5E;SHOW_SEG5F;SHOW_SEG5G;}

#define SHOW_SEG6A					BS(Lcd_Buf[30],3)
#define SHOW_SEG6B					BS(Lcd_Buf[29],2)
#define SHOW_SEG6C					BS(Lcd_Buf[29],0)
#define SHOW_SEG6D					BS(Lcd_Buf[30],0)
#define SHOW_SEG6E					BS(Lcd_Buf[30],1)
#define SHOW_SEG6F					BS(Lcd_Buf[30],2)
#define SHOW_SEG6G					BS(Lcd_Buf[29],1)
#define SEG6_SHOW_0				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;}
#define SEG6_SHOW_1				{SHOW_SEG6B;SHOW_SEG6C;}	
#define SEG6_SHOW_2				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6G;}
#define SEG6_SHOW_3				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6G;}
#define SEG6_SHOW_4				{SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_5				{SHOW_SEG6A;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_6				{SHOW_SEG6A;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_7				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6C;}
#define SEG6_SHOW_8				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_9				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_A				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_B				{SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}		
#define SEG6_SHOW_C				{SHOW_SEG6A;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;}
#define SEG6_SHOW_D				{SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6G;}
#define SEG6_SHOW_E				{SHOW_SEG6A;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_F				{SHOW_SEG6A;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_G				{SHOW_SEG6A;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;}
#define SEG6_SHOW_DEC				SHOW_SEG6G
#define SEG6_SHOW_H				{SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}
#define SEG6_SHOW_J				{SHOW_SEG6B;SHOW_SEG6C;SHOW_SEG6D;SHOW_SEG6E;}
#define SEG6_SHOW_L				{SHOW_SEG6D;SHOW_SEG6E;SHOW_SEG6F;}
#define SEG6_SHOW_P				{SHOW_SEG6A;SHOW_SEG6B;SHOW_SEG6E;SHOW_SEG6F;SHOW_SEG6G;}

#define SHOW_SEG7A					BS(Lcd_Buf[28],3)
#define SHOW_SEG7B					BS(Lcd_Buf[27],2)
#define SHOW_SEG7C					BS(Lcd_Buf[27],0)
#define SHOW_SEG7D					BS(Lcd_Buf[28],0)
#define SHOW_SEG7E					BS(Lcd_Buf[28],1)
#define SHOW_SEG7F					BS(Lcd_Buf[28],2)
#define SHOW_SEG7G					BS(Lcd_Buf[27],1)
#define SEG7_SHOW_0				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;}
#define SEG7_SHOW_1				{SHOW_SEG7B;SHOW_SEG7C;}	
#define SEG7_SHOW_2				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7G;}
#define SEG7_SHOW_3				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7G;}
#define SEG7_SHOW_4				{SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_5				{SHOW_SEG7A;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_6				{SHOW_SEG7A;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_7				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7C;}
#define SEG7_SHOW_8				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_9				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_A				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_B				{SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}		
#define SEG7_SHOW_C				{SHOW_SEG7A;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;}
#define SEG7_SHOW_D				{SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7G;}
#define SEG7_SHOW_E				{SHOW_SEG7A;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_F				{SHOW_SEG7A;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_G				{SHOW_SEG7A;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;}
#define SEG7_SHOW_DEC				SHOW_SEG7G
#define SEG7_SHOW_H				{SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}
#define SEG7_SHOW_J				{SHOW_SEG7B;SHOW_SEG7C;SHOW_SEG7D;SHOW_SEG7E;}
#define SEG7_SHOW_L				{SHOW_SEG7D;SHOW_SEG7E;SHOW_SEG7F;}
#define SEG7_SHOW_P				{SHOW_SEG7A;SHOW_SEG7B;SHOW_SEG7E;SHOW_SEG7F;SHOW_SEG7G;}


#define M_LED_SEG4_PORT_SET(data_B)					\
{														\
	(data_B&BIT0) ? SHOW_SEG4A:0;						\
	(data_B&BIT1) ? SHOW_SEG4B:0;						\
	(data_B&BIT2) ? SHOW_SEG4C:0;						\
	(data_B&BIT3) ? SHOW_SEG4D:0;						\
	(data_B&BIT4) ? SHOW_SEG4E:0;						\
	(data_B&BIT5) ? SHOW_SEG4F:0;						\
	(data_B&BIT6) ? SHOW_SEG4G:0;						\
}

#define M_LED_SEG5_PORT_SET(data_B)					\
{														\
	(data_B&BIT0) ? SHOW_SEG5A:0;						\
	(data_B&BIT1) ? SHOW_SEG5B:0;						\
	(data_B&BIT2) ? SHOW_SEG5C:0;						\
	(data_B&BIT3) ? SHOW_SEG5D:0;						\
	(data_B&BIT4) ? SHOW_SEG5E:0;						\
	(data_B&BIT5) ? SHOW_SEG5F:0;						\
	(data_B&BIT6) ? SHOW_SEG5G:0;						\
}

#define M_LED_SEG6_PORT_SET(data_B)					\
{														\
	(data_B&BIT0) ? SHOW_SEG6A:0;						\
	(data_B&BIT1) ? SHOW_SEG6B:0;						\
	(data_B&BIT2) ? SHOW_SEG6C:0;						\
	(data_B&BIT3) ? SHOW_SEG6D:0;						\
	(data_B&BIT4) ? SHOW_SEG6E:0;						\
	(data_B&BIT5) ? SHOW_SEG6F:0;						\
	(data_B&BIT6) ? SHOW_SEG6G:0;						\
}

#define M_LED_SEG7_PORT_SET(data_B)					\
{														\
	(data_B&BIT0) ? SHOW_SEG7A:0;						\
	(data_B&BIT1) ? SHOW_SEG7B:0;						\
	(data_B&BIT2) ? SHOW_SEG7C:0;						\
	(data_B&BIT3) ? SHOW_SEG7D:0;						\
	(data_B&BIT4) ? SHOW_SEG7E:0;						\
	(data_B&BIT5) ? SHOW_SEG7F:0;						\
	(data_B&BIT6) ? SHOW_SEG7G:0;						\
}


/***********************************************************************/

/***********************************************************************/
/**  ����������ʾ  **/
#define SHOW_NANOE					BS(Lcd_Buf[14],3)
#define SHOW_ECONAVI				BS(Lcd_Buf[14],2)
#define SHOW_SAVE_ENERGY			BS(Lcd_Buf[14],1)
#define SHOW_FRESH_AIR				BS(Lcd_Buf[14],0)
#define SHOW_TIMER					BS(Lcd_Buf[13],3)
#define SHOW_WIFI_ICON				BS(Lcd_Buf[13],2)
#define SHOW_WIFI_CONNECT_NET		BS(Lcd_Buf[13],1)
#define SHOW_WIFI_RESET			BS(Lcd_Buf[13],0)
#define SHOW_CHECK					BS(Lcd_Buf[12],3)
#define SHOW_MACHINE_CHOOSE		BS(Lcd_Buf[12],2)
#define SHOW_FILTER_RESET			BS(Lcd_Buf[12],1)
#define SHOW_TRY_RUN				BS(Lcd_Buf[12],0)
/***********************************************************************/

/***********************************************************************/
/**  �̶������ʾ  **/
#define SHOW_FIT_BOX				BS(Lcd_Buf[33],3)
/***********************************************************************/



enum
{
	SHOW_0,
	SHOW_1,
	SHOW_2,
	SHOW_3,
	SHOW_4,
	SHOW_5,
	SHOW_6,
	SHOW_7,
	SHOW_8,
	SHOW_9,
	SHOW_A,
	SHOW_B,
	SHOW_C,
	SHOW_D,
	SHOW_E,
	SHOW_F,
	SHOW_G,
	SHOW_DEC,
	SHOW_ADD,
	SHOW_H,
	SHOW_J,
	SHOW_L,
	SHOW_P,
};



/*****************************/
/*
	G_LcdFlag
*/
/*****************************/
enum
{
	LCD_FLAG_SHOW_ENABLE = BIT0,
	LCD_FLAG_1HZ_SHOW = BIT1,		// use to blink 1Hz
	LCD_FLAG_5HZ_SHOW = BIT2,		// 5Hz  
	
};

/*****************************/
/*
	GuiTaskMode
*/
/*****************************/
enum
{
	NORMAL_TAST,					// ��������    
	TEST_TAST,						// ���Խ���      
	RESET_TAST,					// ��λ����   
	PRO_TAST,						// ��ϸ�ͼ��趨����   
	REMO_SET_TAST,				// ң�������ý���   
	ERROR_INDEX_TAST,				// �쳣��ѯ����   
	SERVER_INDEX_TAST,			// ����ģ������   
	AUTO_ADDR_TAST,				// �Զ���ַ�趨����   
	MANUAL_ADDR_TAST,			// �ֶ���ַ�趨����   
	OUTDOOR_NORMAL_TAST,			// ������趨����   
	OUTDOOR_ERROR_INDEX_TAST,	// ������쳣����ģʽ    
	OUTDOOR_SERVER_INDEX_TAST,
	
	OTHER_REMO_SETTING_TAST,
};

/*****************************/
/*
	displayState
*/
/*****************************/
typedef enum
{
	DISP_OFF,
	DISP_FLASH_1HZ,
	DISP_FLASH_5HZ,
	DISP_ON,
}enum_display_state;

typedef enum
{
	ARROW_UP,
	ARROW_DOWN,	
}enum_arrow_value;

typedef struct
{
	uint8_t displayState;
	uint8_t displayValue;
}struct_lcd_nixie_tube;

typedef struct
{
	uint8_t displayState;
}struct_lcd_icon;

typedef struct
{
	struct_lcd_nixie_tube tempeHigh;			// �����1   
	struct_lcd_nixie_tube tempeLow;			// �����2  
	struct_lcd_nixie_tube timerHourHigh;		// �����4  
	struct_lcd_nixie_tube timerHourLow;		// �����5  
	struct_lcd_nixie_tube timerMinHigh;		// �����6    
	struct_lcd_nixie_tube timerMinLow;		// �����7    
	struct_lcd_nixie_tube nixieTube8;		// �����8    
	struct_lcd_nixie_tube nixieTube9;		// �����9    
	struct_lcd_nixie_tube nixieTube10;		// �����10    
	struct_lcd_nixie_tube nixieTube11;		// �����11    
	struct_lcd_nixie_tube runMode;			// ��תģʽ  
	struct_lcd_nixie_tube windSpeed;		// ����   
	struct_lcd_nixie_tube lrWindDir;		// ���ҷ���  
	struct_lcd_nixie_tube udWindDir;		// ���·���   
	struct_lcd_nixie_tube wifiSignal;		// WIFIǿ��   
	struct_lcd_icon udIcon;					// ����ͼ��    
	struct_lcd_icon lrIcon;					// ����ͼ��   
	struct_lcd_icon tempeUnit;				// ���϶ȵ�λ   
	struct_lcd_icon remote;					// Զ��    
	struct_lcd_icon project;				// ��Ŀ   
	struct_lcd_icon preheat;				// Ԥ��   
	struct_lcd_icon defrost;				// ��˪   
	struct_lcd_icon clean;					// �ྻ��   
	struct_lcd_icon setting;				// �趨��   
	struct_lcd_icon afterHour;				// Сʱ��    
	struct_lcd_icon timerOff0;				// ��ʱ��0   
	struct_lcd_icon cycle;					// ѭ��   
	struct_lcd_icon timerOff1;				// ��ʱ��1   
	struct_lcd_icon timerOn;				// ��ʱ��   
	struct_lcd_icon noFunc;					// �޴˹���   
	struct_lcd_icon nanoe;					// nanoe  
	struct_lcd_icon econavi;				// econavi 
	struct_lcd_icon saveEnergy;			// ����    
	struct_lcd_icon freshAir;				// ����   
	struct_lcd_icon timer;					// ��ʱ   
	struct_lcd_icon wifi;					// wifiͼ��   
	struct_lcd_icon connectNet;			// ����    
	struct_lcd_icon wifiReset;				// WIFI��λ   
	struct_lcd_icon check;					// ���  
	struct_lcd_icon machineModel;			// ����ѡ��   
	struct_lcd_icon filterReset;			// ��������λ   
	struct_lcd_icon tryRun;					// ����ת   
	struct_lcd_icon col;					// ʱ��ָ���  
	struct_lcd_icon point;					// С����   
	struct_lcd_icon machineNum;			// ������    
	struct_lcd_icon systemNum;				// ϵͳ        
	struct_lcd_icon indoorNum;				// ����     
}struct_lcd;


EXT_DISPLAY uint8_t GuiTaskMode;	
EXT_DISPLAY uint8_t G_LcdFlag;
EXT_DISPLAY uint8_t Lcd_Buf[LCD_BUF_LEN];

void Gui_ProShow(void);
void Gui_RemoSetShow(void);
void Lcd_FlashCount(void);
void Clear_LCD_State(void);
void Get_LCD_State(void);
void Get_FanSpeed_State(void);
void Get_RunMode_State(void);
void Get_WindDir_State(void);
void Get_Tempe_State(void);
void Get_Ir_State(void);
void Get_Timer_State(void);
void Get_ErrorCodeValue(uint8_t dat);
void Get_MachineNumbel_State(void);
void Get_FunctionArea_State(void);
void Get_Nanoe_State(void);
void Get_LCD_Buf(void);
void Lcd_Process(void);
static void Gui_Normal(void);
static void Gui_Test(void);
static void Gui_ErrorIndexShow(void);
static void Gui_ServerIndexShow(void);
static void Gui_AutoAddrShow(void);
static void Gui_ManualAddrShow(void);
static void Gui_OutdoorNormalShow(void);
static void Gui_OutdoorErrorIndexShow(void);
static void Gui_OutdoorServerIndexShow(void);
static void LCD_SegLoad(void);
void LCD_ComSet(uint8_t com);
void LCD_SegSet(uint8_t seg);
void SEG1_SHOW_ONEDIGIT(uint8_t digit);
void SEG2_SHOW_ONEDIGIT(uint8_t digit);
void SEG4_SHOW_ONEDIGIT(uint8_t digit);
void SEG5_SHOW_ONEDIGIT(uint8_t digit);
void SEG6_SHOW_ONEDIGIT(uint8_t digit);
void SEG7_SHOW_ONEDIGIT(uint8_t digit);
void SEG8_SHOW_ONEDIGIT(uint8_t digit);
void SEG9_SHOW_ONEDIGIT(uint8_t digit);
void SEG10_SHOW_ONEDIGIT(uint8_t digit);
void SEG11_SHOW_ONEDIGIT(uint8_t digit);
void Show_TimerNormal(void);
void Show_RunMode(uint8_t system_mode_dat);
void Show_WindSpeed(uint8_t wind_speed_dat);
void Show_LrWindDir(uint8_t lr_wind_dir_dat);
void Show_WindDirLrAuto(void);
void Show_UdWindDir(uint8_t ud_wind_dir_dat);
void Show_WindDirUdAuto(void);
void Show_WifiSignal(uint8_t wifi_signal_dat);

#endif


