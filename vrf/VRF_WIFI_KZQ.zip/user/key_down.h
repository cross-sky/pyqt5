#include "r_cg_macrodriver.h"

#ifndef _KEY_DOWN_H_
#define _KEY_DOWN_H_

void Key_DownDeal(void);
static void DownKey_Normal(void);
static void DownKey_Pro(void);
static void DownKey_RemoFun(void);
static void DownKey_ErrorIndex(void);
static void DownKey_ServerIndex(void);
static void DownKey_AutoAddr(void);
static void DownKey_ManualAddr(void);
static void DownKey_OutdoorNormal(void);
static void DownKey_OutdoorErrorIndex(void);
static void DownKey_OutdoorServerIndex(void);
#endif
