#include "r_cg_macrodriver.h"

#ifndef _KEY_WIND_H_
#define _KEY_WIND_H_

void Key_WindspeedDeal(void);
static void WindKey_Normal(void);
#endif
