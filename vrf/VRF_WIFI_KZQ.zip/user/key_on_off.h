#include "r_cg_macrodriver.h"

#ifndef _KEY_ON_OFF_H_
#define _KEY_ON_OFF_H_


void Key_OnOffDeal(void);

#endif

