#include "Common.h"


/**************************************************************/
/**
*	@brief	���ٰ�����������   
*/
/**************************************************************/
void Key_WindspeedDeal(void)
{
	if (GuiTaskMode == NORMAL_TAST)		/* ���ڻ�����ģʽ   */
	{
		WindKey_Normal();			
	}

}

/**************************************************************/
/**
*	@brief	�������� ����ģʽ����    
*/
/**************************************************************/
static void WindKey_Normal(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_SendFlag & SEND_FLAG_INIT)				// ���ڻ�   
			return;
		if (G_SystemStatus == SYSTEM_STATUS_OFF)	//�ػ�   
			return;
		if (G_SystemSet == 1)							
			return;
		G_KeyCount = KEY_COUNT_5S;

		// ���п��ƽ�ֹ��         
		if (G_CentralCtrBanFlag & WIND_SW_BAN)
		{
			G_CtlBanSwAction = CTL_BAN_SW_ACT;
			G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
			return;
		}

		// ����5��            
		if (G_WindSpeedGroup == WIND_SPEED_GROUP_5)
		{
			if (G_SpecWindSpeed == WIND_SPEED_SPEC_NORMAL)
			{
				if (G_WindSpeed[G_SystemMode]<WIND_SPEED_LEVEL5)
				{
					G_WindSpeed[G_SystemMode]++;
					Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
				else
				{
					G_WindSpeed[G_SystemMode] = WIND_SPEED_LEVEL5;
					G_SpecWindSpeed = WIND_SPEED_SPEC_MUTE;
					G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
					Vrf_CmdJoinQueue(CMD_TYPE_5F,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
					
				}
			}
			else if (G_SpecWindSpeed == WIND_SPEED_SPEC_MUTE)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_STRONG;
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			else
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				G_WindSpeed[G_SystemMode] = WIND_SPEED_AUTO;
				Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
		}
		// ����3��            
		else
		{
			if (G_SpecWindSpeed == WIND_SPEED_SPEC_NORMAL)
			{
				switch (G_WindSpeed[G_SystemMode])
				{
					case WIND_SPEED_AUTO:
						G_WindSpeed[G_SystemMode] = WIND_SPEED_LEVEL1;
						Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						break;
					case WIND_SPEED_LEVEL1:
						G_WindSpeed[G_SystemMode] = WIND_SPEED_LEVEL3;
						Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						break;
					case WIND_SPEED_LEVEL3:
						G_WindSpeed[G_SystemMode] = WIND_SPEED_LEVEL5;
						Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						break;
					case WIND_SPEED_LEVEL5:
						G_SpecWindSpeed = WIND_SPEED_SPEC_MUTE;
						G_Cmd5FFnc = CMD_5F_FNC_WIND_MUTE;
						Vrf_CmdJoinQueue(CMD_TYPE_5F,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						break;
					default:
						G_WindSpeed[G_SystemMode] = WIND_SPEED_LEVEL1;
						Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						break;
				}
			}
			else if (G_SpecWindSpeed == WIND_SPEED_SPEC_MUTE)
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_STRONG;
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
			else
			{
				G_SpecWindSpeed = WIND_SPEED_SPEC_NORMAL;
				G_WindSpeed[G_SystemMode] = WIND_SPEED_AUTO;
				Vrf_CmdJoinQueue(CMD_TYPE_4C_WINDSPEED, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				G_Cmd5FFnc = CMD_5F_FNC_WIND_STRONG;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			}
		}
		Buzzer_KeySoundEnable();
	}
}
