#include "r_cg_macrodriver.h"

#ifndef _I2C_24C04_H
#define _I2C_24C04_H

#define I2C_SDA_READ()				P6.1
#define I2C_SDA_HIGH()				P6.1 = 1
#define I2C_SDA_LOW() 				P6.1 = 0
#define I2C_SCL_HIGH()  			P6.0 = 1
#define I2C_SCL_LOW()             	P6.0 = 0

#define I2C_SDA_OUTPUT()       	PM6.1 = 0
#define I2C_SDA_INPUT()        	PM6.1 = 1


void delay_5us(void);
void I2C_Init(void);
void I2C_Start(void);
void I2C_Stop(void);
uint8_t I2C_WriteByte(uint8_t Byte);
uint8_t I2C_ReadByte(uint8_t ack);
#endif


