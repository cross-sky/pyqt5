#include "r_cg_macrodriver.h"

#ifndef _KEY_SET_H_
#define _KEY_SET_H_

void Key_SettingDeal(void);
static void SetKey_Normal(void);
static void Function_AreaDeal(void);
static void SetKey_Pro(void);
static void SetKey_RemoSet(void);
static void SetKey_AutoAddr(void);
static void SetKey_ManualAddr(void);

#endif