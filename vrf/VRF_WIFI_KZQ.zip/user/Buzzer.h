#include "r_cg_macrodriver.h"

#ifndef _BUZZER_H
#define _BUZZER_H

#ifdef _EXTERN_BUZZER_H_
#define EXT_BUZZER 
#else
#define EXT_BUZZER extern 
#endif

/**********************/
/*
	G_BuzzerType
*/
/**********************/
typedef enum
{
	BUZZER_TYPE_STOP,
	BUZZER_TYPE_1,
	BUZZER_TYPE_2,
	BUZZER_TYPE_3,
	BUZZER_TYPE_4,
}enum_buzzer_time_type;

/**********************/
/*
	G_BuzzerState
*/
/**********************/
typedef enum
{
	BUZZER_OFF,
	BUZZER_ON,
}enum_buzzer_state_type;

/**********************/
/*
	G_BuzzerCountTarget
*/
/**********************/
typedef enum
{
	BUZZER_COUNT_200MS = 20,
	BUZZER_COUNT_300MS = 30,
	BUZZER_COUNT_400MS = 40,
}enum_buzzer_state_type;

/**********************/
/*
	G_BZMode
*/
/**********************/
enum
{
	BZ_DISABLE,
	BZ_ENABLE,
};


EXT_BUZZER uint8_t G_BuzzerType;
EXT_BUZZER uint8_t G_BuzzerState;
EXT_BUZZER uint16_t G_BuzzerCountTarget;
EXT_BUZZER uint16_t G_BuzzerCount;
EXT_BUZZER uint8_t G_BzMode;			// ������ʹ��     


void Buzzer_Enable(uint8_t buzzer_type, uint16_t buzzer_len);
void Buzzer_KeySoundEnable(void);
void Buzzer_LongSoundEnable(void);
void Buzzer_AlarmEnable(void);
void Buzzer_process(void);
void Buzzer_Start(void);
void Buzzer_Stop(void);
void Buzzer_Type1Deal(void);
void Buzzer_Type2Deal(void);


#endif

