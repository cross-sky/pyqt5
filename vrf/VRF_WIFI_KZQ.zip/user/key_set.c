#include "Common.h"

/**************************************************************/
/**
*	@brief	�趨����������   
*/
/**************************************************************/
void Key_SettingDeal(void)
{
	switch (GuiTaskMode)
	{
		case NORMAL_TAST:			/* ���ڻ�����ģʽ   */
			SetKey_Normal();
			break;
		case PRO_TAST:				/* ��ϸ�ͼ���Ŀ�趨���� ep�趨  */
			SetKey_Pro();
			break;
		case REMO_SET_TAST:			/*	ң���������趨   */
			SetKey_RemoSet();
			break;
		case AUTO_ADDR_TAST:		/*	�Զ���ַ����  */
			SetKey_AutoAddr();
			break;
		case MANUAL_ADDR_TAST:		/*	�ֶ���ַ����  */
			SetKey_ManualAddr();
			break;
	}

}

/**************************************************************/
/**
*	@brief	�趨����   ����ģʽ����   
*/
/**************************************************************/
static void SetKey_Normal(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_SendFlag & SEND_FLAG_INIT)
			return;
		if (G_SystemStatus == SYSTEM_STATUS_OFF)
			return;
		G_KeyCount = KEY_COUNT_5S;

		G_SystemSetCount = 0;
		if (G_SystemSet == 1)
		{
			switch (G_SettingMode)
			{
				case SETTING_MODE_RUN_MODE:
					// ���п��ƽ�ֹ��         
					if (G_CentralCtrBanFlag & MODE_SW_BAN)			
					{
						G_CtlBanSwAction = CTL_BAN_SW_ACT;
						G_CtlBanIconFlashCount = CTL_BAN_ICON_FLASH_COUNTS;
						G_SystemSet = 0;
						Buzzer_KeySoundEnable();
					}
					// �Ǽ��ؽ�ֹ              
					else
					{
						G_SystemMode = G_SystemModeSet;
						if ((G_SystemMode==SYSTEM_MODE_WIND)&&(G_NanoeUnion==1))
						{
							G_NanoeStatus = 1;
							Vrf_CmdJoinQueue(CMD_TYPE_5C, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
						}
						Vrf_CmdJoinQueue(CMD_TYPE_42,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
						
						G_SystemSet = 0;
						Buzzer_KeySoundEnable();
					}
					break;
				case SETTING_MODE_LR_WIND:
					G_SystemSet = 0;
					Buzzer_KeySoundEnable();
					break;
				case SETTING_MODE_UD_WIND:
					G_SystemSet = 0;
					Buzzer_KeySoundEnable();
					break;
				case SETTING_MODE_FUNCTION:
					Function_AreaDeal();  
					break;
			}
		}
	}
}

/**************************************************************/
/**
*	@brief	�趨����  ����������   
*/
/**************************************************************/
static void Function_AreaDeal(void)
{
	switch(G_FunctionType)
	{
		case FUNCTION_NANOE:
			G_NanoeStatus ^= 1;
			G_NanoeUnion = 0;
			G_SystemSet = 0;
			Vrf_CmdJoinQueue(CMD_TYPE_5C, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_ECONAVI:
			G_EconaviStatus ^= 1;
			G_SystemSet = 0;
			Vrf_CmdJoinQueue(CMD_TYPE_58, CMD_HAVE_REPLY,CMD_FORMAT_SETTING);
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_SAVE_POWER:
			G_SaveEnergy ^= 1;
			G_SystemSet = 0;
			Vrf_CmdJoinQueue(CMD_TYPE_54, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_FRESH_AIR:
			G_FreshAir ^= 1;
			G_SystemSet = 0;
			Vrf_CmdJoinQueue(CMD_TYPE_52, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_TIMER:
			if (G_TimerSet == TIMER_SET_NO_SET)
			{
				if (G_TimerType)
				{
					G_SystemSet = 0;
					G_TimerType = TIMER_TYPE_NO_SET;
					G_TimerRemainHour = G_TimerHour = 0;
					G_TimerCount = 0;
					Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
				else
				{
					G_TimerSet = TIMER_SET_TYPE_CHOOSE;
					G_TimerTypeSet = TIMER_TYPE_ONCE_OFF;
				}
			}
			else if (G_TimerSet == TIMER_SET_TYPE_CHOOSE)
			{
				G_TimerSet = TIMER_SET_TIME_SET;
				G_TimerHourSet = 5;
			}
			else if (G_TimerSet == TIMER_SET_TIME_SET)
			{
				G_TimerSet = TIMER_SET_NO_SET;
				G_SystemSet = 0;
				G_TimerRemainHour = G_TimerHour = G_TimerHourSet;
				G_TimerCount = (uint32_t)(G_TimerRemainHour*360);
				if (G_TimerTypeSet == TIMER_TYPE_ONCE_OFF)
				{
					G_TimerType = TIMER_TYPE_ONCE_OFF;
				}
				else if (G_TimerTypeSet == TIMER_TYPE_CYCLE_OFF)
				{
					G_TimerType = TIMER_TYPE_CYCLE_OFF;
				}
				else if (G_TimerTypeSet == TIMER_TYPE_ONCE_ON)
				{
					G_TimerType = TIMER_TYPE_ONCE_ON;
					G_SystemStatus = SYSTEM_STATUS_OFF;
					Vrf_CmdJoinQueue(CMD_TYPE_41_ON_OFF,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				}
				Vrf_CmdJoinQueue(CMD_TYPE_0C_0x30,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);	
			}
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_WIFI:
			G_WifiResetState = 0;
			G_WifiState ^= 1;
			G_WifiCheckResult = WIFI_NO_CHECK;
			G_SystemSet = 0;
			G_WifiCmd5F = WIFI_CMD_5F_ON_OFF;
			G_Cmd5FFnc = CMD_5F_FNC_WIFI;
			Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			wifi_match_enable_write = 1;
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_CONNECT_NET:
			if (G_NetKeyCountdown==0)
			{
				G_WifiConnectNetState = 1;
				G_SystemSet = 0;
				G_WifiNetShowCount = WIFI_NET_SHOW_COUNT;

				G_WifiCmd5F = WIFI_CMD_5F_NET;
				G_Cmd5FFnc = CMD_5F_FNC_WIFI;
				Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				Buzzer_KeySoundEnable();
			}
			break;
		case FUNCTION_RESET:
			G_WifiResetState = 1;
			G_SystemSet = 0;
			G_WifiCheckResult = WIFI_NO_CHECK;
			G_WifiResetShowCnt = WIFI_RESET_SHOW_COUNT;
			G_WifiCmd5F = WIFI_CMD_5F_RESET;
			G_Cmd5FFnc = CMD_5F_FNC_WIFI;
			Vrf_CmdJoinQueue(CMD_TYPE_5F, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_FILTER_RESET:
			G_FilterRstSign = 0;
			Vrf_CmdJoinQueue(CMD_TYPE_4B,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);	
			Buzzer_KeySoundEnable();
			break;
		case FUNCTION_TRY_RUN:
			G_SystemSet = 0;
			G_TryRun ^= 1;
			Vrf_CmdJoinQueue(CMD_TYPE_41_TRY_RUN,CMD_HAVE_REPLY, CMD_FORMAT_SETTING);	
			Buzzer_KeySoundEnable();
			break;
	}
}


/**************************************************************/
/**
*	@brief	�趨����  eeprom��Ŀ�趨���� 
*/
/**************************************************************/
static void SetKey_Pro(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_ProSetting == PRO_NO_SET)
			return;
		if (G_ProSetting == PRO_SETTING_LEVEL1)
		{
			if (G_ProFlag == PRO_FLAG_CODE_SEND)
			{
				G_ProSetting = PRO_SETTING_LEVEL2;
				Buzzer_KeySoundEnable();
			}
		}
		else if (G_ProSetting == PRO_SETTING_LEVEL2)
		{
			if (G_ProType == PRO_TYPE_OUTDOOR_DETAIL)
			{
				if (G_ProFlag == PRO_FLAG_CODE_SEND)
				{
					G_ProSetting = PRO_SETTING_LEVEL1;
					Vrf_CmdJoinQueue(CMD_TYPE_17, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
					Buzzer_KeySoundEnable();
				}
			}
			else
			{
				G_ProSetting = PRO_SETTING_LEVEL1;
				Vrf_CmdJoinQueue(CMD_TYPE_07, CMD_HAVE_REPLY, CMD_FORMAT_SETTING);
				Buzzer_KeySoundEnable();
			}
		}
	}
}

/**************************************************************/
/**
*	@brief	�趨����   ң������Ŀ�趨����   
*/
/**************************************************************/
static void SetKey_RemoSet(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_RemoFunSet==REMO_FUN_NO_SET)
			return;
		
		if (G_RemoFunSet == REMO_FUN_SET_PROJECT)
		{
			G_RemoFunSet = REMO_FUN_SET_DATA;
			Buzzer_KeySoundEnable();
		}
		else if (G_RemoFunSet == REMO_FUN_SET_DATA)
		{
			G_RemoFunSet = REMO_FUN_SET_FINISH;
			if (G_RemoRoleBack != G_RemoRole)
			{
				G_RemoRoleBack = G_RemoRole;
				remo_role_write = 1;
			}
			G_RemoModeBack = G_RemoMode;
			if (G_ServerRoleBack != G_ServerRole)
			{
				G_ServerRoleBack = G_ServerRole;
				server_role_write = 1;
			}
			if (G_BLTimeLevelBack != G_BLTimeLevel)
			{
				G_BLTimeLevelBack = G_BLTimeLevel;
				bl_time_level_write = 1;
			}
			if (G_BLLevelBack!= G_BL.level)
			{
				G_BLLevelBack = G_BL.level;
				bl_level_write = 1;
			}
			if (G_LedLevelBack!= G_Led.level)
			{
				G_LedLevelBack = G_Led.level;
				led_level_write = 1;
			}
			if (G_BzModeBack != G_BzMode)
			{
				G_BzModeBack = G_BzMode;
				bz_mode_write = 1;
			}
			Buzzer_KeySoundEnable();
		}
	}
}

/**************************************************************/
/**
*	@brief	�趨����   �Զ���ַ�趨  
*/
/**************************************************************/
static void SetKey_AutoAddr(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_AutoAddrSet == AUTO_ADDR_SET_TYPE)
		{
			G_AutoAddrSet = AUTO_ADDR_SET_SYSTEM;
			Buzzer_KeySoundEnable();
		}
		else if (G_AutoAddrSet == AUTO_ADDR_SET_SYSTEM)
		{   
			G_AutoAddrSet = AUTO_ADDR_SET_WAIT;
			G_AddrSetStep = ADDR_SET_STEP_STOP_RUN;
			G_AutoAddrSend = 1;
			G_AddrSendTime = 0;
			Buzzer_KeySoundEnable();
		}
	}
}

/**************************************************************/
/**
*	@brief	�趨����   �ֶ���ַ����   
*/
/**************************************************************/
static void SetKey_ManualAddr(void)
{
	if (G_KeyDownType == KEY_TYPE_SHORT)
	{
		if (G_ManualAddrSet == MANUAL_ADDR_SET_SYSTEM)
		{
			G_ManualAddrSet = MANUAL_ADDR_SET_INDOOR;
			G_ManualAddrStep = MANUAL_ADDR_STEP1;
			G_ManualIndoorNum = 0;
			
			G_ManualAddrSend = 1;
			G_ManualCmdCnt = 0;
			G_ManualSendTime = 0;
			Buzzer_KeySoundEnable();
		}
		else if (G_ManualAddrSet == MANUAL_ADDR_SET_INDOOR)
		{
			if (G_ManualAddrGetFlag == 1)
			{
				G_ManualAddrSet = MANUAL_ADDR_SET_ADDR;
				Buzzer_KeySoundEnable();
			}
		}
		else if (G_ManualAddrSet == MANUAL_ADDR_SET_ADDR)
		{
			G_ManualAddrSend = 1;
			G_ManualCmdCnt = 0;
			G_ManualSendTime = 0;
			G_ManualAddrSet = MANUAL_ADDR_SET_FINISH;
			Buzzer_KeySoundEnable();
		}
	}
}
