#include "r_cg_macrodriver.h"

#ifndef _IR_H
#define _IR_H

#ifdef _EXTERN_IR_H_
#define EXT_IR
#else
#define EXT_IR extern
#endif



#define RECEVER_DATA_LENGTH_MAX		50

#define  REC P13.7

#define IR_WAVEFORM_H			422								// unit :us
#define IR_REC_TIMER_COUNT		115								// unit :us

#define IR_REC_HEADER_L				(IR_WAVEFORM_H * 12)				// ������ȡ��ǰ��ʱ��
#define IR_REC_HEADER_L_MIN			(IR_REC_HEADER_L * 9 / 10 / IR_REC_TIMER_COUNT-5)
#define IR_REC_HEADER_L_MAX			(IR_REC_HEADER_L * 11 / 10 / IR_REC_TIMER_COUNT+5)

#define IR_REC_DATA_COUNT			(IR_WAVEFORM_H * 4 / IR_REC_TIMER_COUNT + 6)

#define IR_REC_TAIL_COUNT				IR_REC_DATA_COUNT * 10

enum
{
	IR_NO_REC = 0,
	IR_REC_FINISH = 1,
};


enum
{
	IR_TYPE_LENGTH_A = 12,
	IR_TYPE_LENGTH_C = 6,
	IR_TYPE_LENGTH_D = 10,
	IR_TYPE_LENGTH_E = 11,
};

enum
{
	IR_DATA_FC0 = 4,
	IR_DATA_FC1 = 5,
	IR_DATA_FC2 = 6,
	IR_DATA_FC3 = 7,
	IR_DATA_FC4 = 8,
	IR_DATA_FC5 = 9,
	IR_DATA_FC6 = 10,

	IR_DATA_EFC0 = 13,
	IR_DATA_EFC1 = 14,
};



EXT_IR uint8_t G_IrRecStartFlag;
EXT_IR uint8_t G_IrRecStatus;
EXT_IR uint8_t G_IrRecFlag;
EXT_IR uint8_t G_IrRecLength;
EXT_IR uint8_t G_IrRecNumber;
EXT_IR uint8_t G_IrRecDate[RECEVER_DATA_LENGTH_MAX];
EXT_IR uint16_t G_IrRecCount;
EXT_IR uint8_t G_BitCount;


void Ir_Rec_Start(void);
void Ir_Rec_Stop(void);
void Ir_Rec(void);
void Ir_DataDeal(void);
void Ir_TypeA_Deal(void);
void Ir_TypeB_Deal(void);
void Ir_TypeC_Deal(void);
void Ir_TypeD_Deal(void);
void Ir_TypeE_Deal(void);
uint8_t Ir_WindSpeed_deal(uint8_t dat0,uint8_t dat1);

#endif
