#include "r_cg_macrodriver.h"

#ifndef _WIFI_H
#define _WIFI_H

#ifdef _EXTERN_WIFI_H_
#define EXT_WIFI
#else
#define EXT_WIFI extern
#endif


#define RX1_DAT_LENGTH			13

EXT_WIFI uint8_t Uart1SendBuffer[RX1_DAT_LENGTH];
EXT_WIFI uint8_t Uart1SendBufferCount;
EXT_WIFI uint8_t Uart1SendEnable;


#define RX0_DAT_LENGTH			35
EXT_WIFI uint8_t Uart0SendBuffer[RX0_DAT_LENGTH];
EXT_WIFI uint8_t Uart0SendBufferCount;
EXT_WIFI uint8_t G_Timer2MsFlag;

EXT_WIFI uint8_t G_Rx0SendFlag;
enum
{
	RX0_SEND_FLAG_NORMAL = 0x01,
	RX0_SEND_FLAG_WIFI = 0x02,
};
EXT_WIFI uint8_t G_WifiSendEnable;
EXT_WIFI uint8_t G_WifiRecFinishFlag;
EXT_WIFI uint8_t G_WifiRecStartFlag;
EXT_WIFI uint8_t G_WifiRecDat[15];
EXT_WIFI uint8_t G_WifiFunc;
EXT_WIFI uint8_t G_WifiFuncCount;
#define	WIFI_FUNC_COUNT		40		// 40s  

EXT_WIFI uint8_t eeprom_no_l;
EXT_WIFI uint8_t eeprom_no_h;


#define ERROR_LENGTH		56

void Wifi_Send(void);
uint8_t Wifi_GetSendDat(void);
void Wifi_DatParse(void);
void Wifi_RecDatDeal(void);
void Wifi_WindSpeedRec(uint8_t mute_dat, uint8_t strong_dat, uint8_t wind_dat);
void Wifi_SystemModeRec(uint8_t dat);
void Wifi_WindBoardRec(uint8_t ud_dat,uint8_t lr_dat);
void Wifi_TempeRec(uint8_t dat);
void Wifi_1sRelatedCount(void);
void Wifi_10msRelatedCount(void);
void Wifi_FuncCheckDeal(void);

#endif
