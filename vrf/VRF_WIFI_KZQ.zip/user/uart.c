#define _EXTERN_UART_H_

#include "Common.h"


/**********************************************************/
/*
*	@brief 	
*	@detail 
*/
/**********************************************************/
void Tx1_SendPocess(void)
{
	if (G_Tx1SendBusy == TX1_SEND_BUSY_FLAG)
		return;
	
	if (G_SystemScanFlag & SYSTEM_SCAN_FLAG_UART)
	{
		G_SystemScanFlag &= ~SYSTEM_SCAN_FLAG_UART;
		R_UART1_Send(G_IrRecDate,G_IrRecLength);
		G_Tx1SendBusy = TX1_SEND_BUSY_FLAG;
	}
}

/**********************************************************/
/*
*	@brief 	
*	@detail 
*/
/**********************************************************/
void Rx1_DatParse(void)
{
	uint8_t dat_temp;
	
	if (!GetUartReceiveDat(&dat_temp,&G_Rx1RecDat))
		return;
	
}

/**********************************************************/
/*
*	@brief 	
*	@detail 
*/
/**********************************************************/
uint8_t PutUartReceiveDat(uint8_t dat, struct_receive_type *rec_dat)
{
	if (rec_dat->bufferCount >= RECEIVE_BUFFER_LENGTH)
		return 0;

	rec_dat->buffer[rec_dat->bufferTail] = dat;
	rec_dat->bufferTail++;
	if (rec_dat->bufferTail >= RECEIVE_BUFFER_LENGTH)
		rec_dat->bufferTail = 0;
	rec_dat->bufferCount++;

	return 1;
}

/**********************************************************/
/*
*	@brief 	
*	@detail 
*/
/**********************************************************/
uint8_t GetUartReceiveDat(uint8_t *dat,struct_receive_type *rec_dat)
{
	if (rec_dat->bufferCount == 0)
		return 0;

	*dat = rec_dat->buffer[rec_dat->bufferHead];
	rec_dat->bufferHead++;
	if (rec_dat->bufferHead == RECEIVE_BUFFER_LENGTH)
	{
		rec_dat->bufferHead = 0;
	}
	rec_dat->bufferCount--;

	return 1;
}


