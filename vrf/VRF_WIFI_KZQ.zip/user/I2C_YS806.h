#include "r_cg_macrodriver.h"

#ifndef IIC_806_H
#define IIC_806_H


#define I2C_806_SDA_READ()			P1.1
#define I2C_806_SDA_HIGH()			P1.1 = 1
#define I2C_806_SDA_LOW() 				P1.1 = 0
#define I2C_806_SCL_HIGH()  			P1.0 = 1
#define I2C_806_SCL_LOW()             	P1.0 = 0

#define I2C_806_SDA_OUTPUT()       	PM1.1 = 0
#define I2C_806_SDA_INPUT()        	PM1.1 = 1


void I2C_806_Init(void);
void I2C_806_Start(void);
void I2C_806_Stop(void);
uint8_t I2C_806_WriteByte(uint8_t Byte);
uint8_t I2C_806_ReadByte(uint8_t ack);

#endif


