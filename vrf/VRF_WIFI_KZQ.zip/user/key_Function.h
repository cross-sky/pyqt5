#include "r_cg_macrodriver.h"

#ifndef _KEY_FUNCTION_H_
#define _KEY_FUNCTION_H_


void Key_FunctionDeal(void);
static void FunKey_Normal(void);
static void FuncKey_Pro(void);
static void FuncKey_RemoSet(void);
static void FuncKey_ErrorCheck(void);
static void FuncKey_ServerCheck(void);
static void FuncKey_AutoAddr(void);
static void FuncKey_ManualAddr(void);
static void FuncKey_OutdoorNormal(void);
static void FuncKey_OutdoorErrorCheck(void);
static void FuncKey_OutdoorServerCheck(void);
#endif
