#include "r_cg_macrodriver.h"

#ifndef _KEY_UP_H_
#define _KEY_UP_H_

void Key_UpDeal(void);
static void UpKey_Normal(void);
static void UpKey_Pro(void);
static void UpKey_RemoFun(void);
static void UpKey_ErrorIndex(void);
static void UpKey_ServerIndex(void);
static void UpKey_AutoAddr(void);
static void UpKey_ManualAddr(void);
static void UpKey_OutdoorNormal(void);
static void UpKey_OutdoorErrorIndex(void);
static void UpKey_OutdoorServerIndex(void);
#endif
