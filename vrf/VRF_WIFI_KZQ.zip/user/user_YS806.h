#include "r_cg_macrodriver.h"

#ifndef _USER_YS806_H
#define _USER_YS806_H


void YS806_Write_Byte(uint8_t devSel, uint8_t addr, uint8_t dat);
void YS806_Read_Byte(uint8_t devSel, uint8_t addr, uint8_t *pdate);
void YS806_Write_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate);
void YS806_Read_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate);

#endif


