#include "r_cg_macrodriver.h"

#ifndef _EEPROM_H
#define _EEPROM_H

#ifdef _EXTERN_EEPROM_H_
#define EXT_EEPROM  
#else 
#define EXT_EEPROM extern 
#endif


#define eeprom_init_enable_dress		0x20

#define wifi_match_enable_dress		0x30
#define remo_role_dress				0x31
#define server_role_dress				0x32
#define bl_time_dress					0x33
#define bl_level_dress					0x34
#define led_level_dress				0x35
#define bz_mode_dresss					0x36

#define error_code_dress				0x50

EXT_EEPROM uint16_t G_EepromWriteFlag1;
//EXT_EEPROM uint16_t G_EepromWriteFlag2;
//EXT_EEPROM uint16_t G_EepromWriteFlag3;
EXT_EEPROM uint8_t G_SystemDataInit;

#define	eeprom_init_enable_write		(((struct_bit_type*)&G_EepromWriteFlag1)->b0)
#define	wifi_match_enable_write		(((struct_bit_type*)&G_EepromWriteFlag1)->b1)
#define	remo_role_write				(((struct_bit_type*)&G_EepromWriteFlag1)->b2)
#define	server_role_write				(((struct_bit_type*)&G_EepromWriteFlag1)->b3)
#define	bl_time_level_write			(((struct_bit_type*)&G_EepromWriteFlag1)->b4)
#define	bl_level_write					(((struct_bit_type*)&G_EepromWriteFlag1)->b5)
#define	led_level_write				(((struct_bit_type*)&G_EepromWriteFlag1)->b6)
#define	bz_mode_write					(((struct_bit_type*)&G_EepromWriteFlag1)->b7)
//#define	error_code_write				(((struct_bit_type*)&G_EepromWriteFlag1)->b8)


void System_EepromDataInit(void);
void System_EepromWriteProcess(void);
void System_EepromReadProcess(void);
void Eeprom_TestProcess(void);


#endif
