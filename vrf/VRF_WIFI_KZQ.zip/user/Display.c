#define _EXTERN_DISPLAY_H_

#include "Common.h"

struct_lcd lcd;
struct_lcd *LCD = &lcd;


/**************************************************************/
/**
* @brief	��ʾ����    
*/
/**************************************************************/
void Lcd_Process(void)
{
	uint8_t	i;

	for(i = 0; i < LCD_BUF_LEN; i++)
		Lcd_Buf[i] = 0x00;		/*clear LCD buffer*/
	
	Clear_LCD_State();				// ���LCD��ʾ״̬    	
	switch(GuiTaskMode)
	{
		case NORMAL_TAST:
			Gui_Normal();	    	// ����ģʽ��ʾ    
			break;
		case TEST_TAST:				
			Gui_Test();			// ����ģʽ��ʾ    
			break;
		case RESET_TAST:
			SHOW_FIT_BOX;			// ��λ״̬��ʾ     
			break;
		case PRO_TAST:				
			Gui_ProShow();			// ��ϸ�ͼ���Ŀ�趨��ʾ     
			break;
		case REMO_SET_TAST:
			Gui_RemoSetShow();		// ң�����趨������ʾ     
			break;
		case ERROR_INDEX_TAST:	
			Gui_ErrorIndexShow();		// �쳣��ѯ��ʾ    
			break;
		case SERVER_INDEX_TAST:	
			Gui_ServerIndexShow();	// ����ģʽ������ʾ    
			break;
		case AUTO_ADDR_TAST:
			Gui_AutoAddrShow();		// �Զ���ַ�趨��ʾ    
			break;
		case MANUAL_ADDR_TAST:
			Gui_ManualAddrShow();		// �ֶ���ַ�趨��ʾ    
			break;
		case OUTDOOR_NORMAL_TAST:		
			Gui_OutdoorNormalShow();	// ���������ʾ    		
			break;
		case OUTDOOR_ERROR_INDEX_TAST:
			Gui_OutdoorErrorIndexShow();		// �쳣��ѯ��ʾ    
			break;
		case OUTDOOR_SERVER_INDEX_TAST:	
			Gui_OutdoorServerIndexShow();		// ����ģʽ������ʾ    
			break;
		case OTHER_REMO_SETTING_TAST:
			LCD->setting.displayState = DISP_FLASH_1HZ;			// ����ң���������趨�������ʱ����ʾ    
			Get_LCD_Buf();
			break;
		default:
			break;
	}

	LCD_SegLoad();		/*send lcd buff data to mcu lcd dispaly address */
}

/********************************************************/
/**
** @brief    ����ģʽ��ʾ    
*/
/********************************************************/
static void Gui_Normal(void)
{
	Get_LCD_State();			// ��ȡ����ģʽʱ����ʾ״̬    
	Get_LCD_Buf();				// ��ȡ��ʾ����    
}

/********************************************************/
/**
** @brief    ��Ŀ�趨��ʾ    
*/
/********************************************************/
void Gui_ProShow(void)
{
	uint8_t temp;
	LCD->setting.displayState = DISP_FLASH_1HZ;
	
	if (G_ProSetting==PRO_NO_SET)
		return;

	// �¶�88��ʾ   
	if (G_ProSetting == PRO_SETTING_LEVEL1)
	{
		// ��Ŀͼ����ʾ   
		LCD->project.displayState = DISP_ON;

		if (G_KeyReleaseType==KEY_TYPE_CONTINUE)
		{
			LCD->tempeHigh.displayState = DISP_ON;
			LCD->tempeLow.displayState = DISP_ON;
		}
		else
		{
			LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
			LCD->tempeLow.displayState = DISP_FLASH_1HZ;
		}
	}
	else if (G_ProSetting == PRO_SETTING_LEVEL2)
	{
		// ��Ŀͼ����ʾ   
		LCD->project.displayState = DISP_ON;
		LCD->tempeHigh.displayState = DISP_ON;
		LCD->tempeLow.displayState = DISP_ON;
	}
	
	if (G_ProFlag == 0)
	{
		LCD->tempeHigh.displayValue = SHOW_DEC;
		LCD->tempeLow.displayValue = SHOW_DEC;
	}
	else
	{
		LCD->tempeHigh.displayValue = G_ProCode>>4;
		LCD->tempeLow.displayValue = G_ProCode&0x0f;
	}

	// ʱ��88��ʾ   
	if (G_ProSetting==PRO_SETTING_LEVEL1)
	{
		LCD->timerHourHigh.displayState = DISP_ON;
		LCD->timerHourLow.displayState = DISP_ON;
		LCD->timerMinHigh.displayState = DISP_ON;
		LCD->timerMinLow.displayState = DISP_ON;
	}
	else if (G_ProSetting == PRO_SETTING_LEVEL2)
	{
		if (G_KeyReleaseType==KEY_TYPE_CONTINUE)
		{
			LCD->timerHourHigh.displayState = DISP_ON;
			LCD->timerHourLow.displayState = DISP_ON;
			LCD->timerMinHigh.displayState = DISP_ON;
			LCD->timerMinLow.displayState = DISP_ON;
		}
		else
		{
			LCD->timerHourHigh.displayState = DISP_FLASH_1HZ;
			LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
			LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
			LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
		}
	}
		
	if (G_ProFlag)						// ��Ŀ�趨����ֵ��ʾ    
	{
		if (G_ProData & BIT7)			// ����δ����ʱ   
		{
			LCD->timerHourHigh.displayValue = SHOW_DEC;
			temp = (int8_t)(G_ProData^0xff)+1;
			LCD->timerHourLow.displayValue = temp / 100;
			LCD->timerMinHigh.displayValue = temp % 100 / 10;
			LCD->timerMinLow.displayValue = temp % 10;
		}
		else
		{
			LCD->timerHourHigh.displayState = DISP_OFF;
			LCD->timerHourLow.displayValue = G_ProData / 100;
			LCD->timerMinHigh.displayValue = G_ProData % 100 / 10;
			LCD->timerMinLow.displayValue = G_ProData % 10;
		}
	}
	else								// ��Ŀ�趨���ݻ�δ��������ʱ��ʾ"-- --"
	{
		LCD->timerHourHigh.displayValue = SHOW_DEC;
		LCD->timerHourLow.displayValue = SHOW_DEC;
		LCD->timerMinHigh.displayValue = SHOW_DEC;
		LCD->timerMinLow.displayValue = SHOW_DEC;
	}

	// ���ڻ������ʾ   
	if ((G_ProSetting==PRO_SETTING_LEVEL1)||(G_ProSetting==PRO_SETTING_LEVEL2))
	{
		LCD->machineNum.displayState = DISP_ON;
		
		LCD->systemNum.displayState = DISP_ON;
		LCD->nixieTube8.displayState = DISP_ON;
		LCD->nixieTube9.displayState = DISP_ON;

		LCD->indoorNum.displayState = DISP_ON;
		LCD->nixieTube10.displayState = DISP_ON;
		LCD->nixieTube11.displayState = DISP_ON;


		if (G_ProType == PRO_TYPE_DETAIL)
		{
			if (G_ProSendObj == PRO_SEND_OBJ_SINGLE)
			{
				LCD->nixieTube8.displayValue = (G_SystemNumbel + 1) / 10;
				LCD->nixieTube9.displayValue = (G_SystemNumbel + 1) % 10;
				LCD->nixieTube10.displayValue = (G_IndoorNumbel+1) / 10;
				LCD->nixieTube11.displayValue = (G_IndoorNumbel+1)  % 10;
			}
			else
			{
				LCD->nixieTube8.displayState = DISP_OFF;
				LCD->nixieTube9.displayValue = SHOW_A;
				LCD->nixieTube10.displayValue = SHOW_L;
				LCD->nixieTube11.displayValue = SHOW_L;
			}
		}
		else if (G_ProType == PRO_TYPE_SIMPLE)
		{
			LCD->nixieTube8.displayState = DISP_OFF;
			LCD->nixieTube9.displayValue = SHOW_A;
			LCD->nixieTube10.displayValue = SHOW_L;
			LCD->nixieTube11.displayValue = SHOW_L;
		}
		else if (G_ProType == PRO_TYPE_OUTDOOR_DETAIL)
		{
			LCD->nixieTube8.displayValue = (G_SystemNumbel + 1) / 10;
			LCD->nixieTube9.displayValue = (G_SystemNumbel + 1) % 10;
			LCD->nixieTube10.displayValue = SHOW_0;
			LCD->nixieTube11.displayValue = SHOW_1;
		}
		
	}
	
	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    ң�����趨��ʾ    
*/
/********************************************************/
void Gui_RemoSetShow(void)
{
	if (G_RemoFunSet==REMO_FUN_NO_SET)
		return;

	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ   
	if (G_RemoFunSet == REMO_FUN_SET_PROJECT)
	{
		LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
		LCD->tempeLow.displayState = DISP_FLASH_1HZ;
	}
	else
	{
		LCD->tempeHigh.displayState = DISP_ON;
		LCD->tempeLow.displayState = DISP_ON;
	}

	// ң�����趨��Ŀ������ֵ��ʾ   
	switch (G_RemoFunStage)			
	{
		case REMO_FUN_STAGE_REMO_ADDR:		
			LCD->tempeHigh.displayValue = SHOW_0;
			LCD->tempeLow.displayValue = SHOW_1;
			break;
		case REMO_FUN_STAGE_TEST_MODE:
			LCD->tempeHigh.displayValue = SHOW_0;
			LCD->tempeLow.displayValue = SHOW_8;
			break;
		case REMO_FUN_STAGE_SERVER:
			LCD->tempeHigh.displayValue = SHOW_1;
			LCD->tempeLow.displayValue = SHOW_F;
			break;
		case REMO_FUN_STAGE_BL_TIME:
			LCD->tempeHigh.displayValue = SHOW_2;
			LCD->tempeLow.displayValue = SHOW_B;
			break;
		case REMO_FUN_STAGE_BL_LEVEL:
			LCD->tempeHigh.displayValue = SHOW_2;
			LCD->tempeLow.displayValue = SHOW_C;
			break;
		case REMO_FUN_STAGE_PW_LEVEL:
			LCD->tempeHigh.displayValue = SHOW_2;
			LCD->tempeLow.displayValue = SHOW_E;
			break;
		case REMO_FUN_STAGE_BZ_STATE:
			LCD->tempeHigh.displayValue = SHOW_2;
			LCD->tempeLow.displayValue = SHOW_F;
			break;
	}

	// ʱ��88��ʾ  
	if ((G_RemoFunSet == REMO_FUN_SET_DATA)&&(G_KeyReleaseType!=KEY_TYPE_CONTINUE))
	{
		LCD->timerHourHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
		LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
	}
	else
	{
		LCD->timerHourHigh.displayState = DISP_ON;
		LCD->timerHourLow.displayState = DISP_ON;
		LCD->timerMinHigh.displayState = DISP_ON;
		LCD->timerMinLow.displayState = DISP_ON;
	}
	switch (G_RemoFunStage)
	{
		case REMO_FUN_STAGE_REMO_ADDR:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_RemoRole / 10;
			LCD->timerMinLow.displayValue = G_RemoRole % 10;;
			break;
		case REMO_FUN_STAGE_TEST_MODE:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_RemoMode / 10;
			LCD->timerMinLow.displayValue = G_RemoMode % 10;
			break;
		case REMO_FUN_STAGE_SERVER:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_ServerRole / 10;
			LCD->timerMinLow.displayValue = G_ServerRole % 10;
			break;
		case REMO_FUN_STAGE_BL_TIME:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_BLTimeLevel / 10;
			LCD->timerMinLow.displayValue = G_BLTimeLevel % 10;
			break;
		case REMO_FUN_STAGE_BL_LEVEL:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_BL.level / 10;
			LCD->timerMinLow.displayValue = G_BL.level % 10;
			break;
		case REMO_FUN_STAGE_PW_LEVEL:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_Led.level / 10;
			LCD->timerMinLow.displayValue = G_Led.level % 10;
			break;
		case REMO_FUN_STAGE_BZ_STATE:
			LCD->timerHourHigh.displayValue = 0;
			LCD->timerHourLow.displayValue = 0;
			LCD->timerMinHigh.displayValue = G_BzMode / 10;
			LCD->timerMinLow.displayValue = G_BzMode % 10;
			break;
	}
	
	LCD->setting.displayState = DISP_FLASH_1HZ;
	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    �쳣�����ѯ��ʾ    
*/
/********************************************************/
static void Gui_ErrorIndexShow(void)
{
	if (G_ErrorCheck == 0)
		return;
	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ  
	LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
	LCD->tempeLow.displayState = DISP_FLASH_1HZ;
	LCD->tempeHigh.displayValue = (G_ErrorObj+1) / 10;
	LCD->tempeLow.displayValue = (G_ErrorObj+1) % 10;
	
	// ʱ��8888����ʾ    
	LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
	LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
	LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
	Get_ErrorCodeValue(G_ErrorIndex);


	// ϵͳ���   
	LCD->machineNum.displayState = DISP_ON;
	LCD->systemNum.displayState = DISP_ON;
	LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube9.displayState = DISP_FLASH_1HZ;
	LCD->indoorNum.displayState = DISP_ON;
	LCD->nixieTube10.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube11.displayState = DISP_FLASH_1HZ;
	if (G_ErrorIndex != 0)
	{
		LCD->nixieTube8.displayValue = (G_ErrorIndexSysNum + 1) / 10;
		LCD->nixieTube9.displayValue = (G_ErrorIndexSysNum + 1) % 10;
		LCD->nixieTube10.displayValue = (G_ErrorIndexIndoorNum+1) / 10;
		LCD->nixieTube11.displayValue = (G_ErrorIndexIndoorNum+1) % 10;
	}
	else
	{
		LCD->nixieTube8.displayValue = SHOW_DEC;
		LCD->nixieTube9.displayValue = SHOW_DEC;
		LCD->nixieTube10.displayValue = SHOW_DEC;
		LCD->nixieTube11.displayValue = SHOW_DEC;
	}
	
	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    �������ģʽ��ʾ    
*/
/********************************************************/
static void Gui_ServerIndexShow(void)
{
	uint16_t temp_16bit;
	uint8_t temp_8bit;
	if (G_ServerCheck == 0)
		return;

	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ  
	if (G_KeyReleaseType == KEY_TYPE_CONTINUE)
	{
		LCD->tempeHigh.displayState = DISP_ON;
		LCD->tempeLow.displayState = DISP_ON;
	}
	else
	{
		LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
		LCD->tempeLow.displayState = DISP_FLASH_1HZ;
	}
	LCD->tempeHigh.displayValue = G_ServerObj>>4;
	LCD->tempeLow.displayValue = G_ServerObj&0x0f;

	
	// ʱ��8888����ʾ    
	if (G_KeyReleaseType == KEY_TYPE_CONTINUE)
	{
		LCD->timerHourHigh.displayState = DISP_ON;
		LCD->timerHourLow.displayState = DISP_ON;
		LCD->timerMinHigh.displayState = DISP_ON;
		LCD->timerMinLow.displayState = DISP_ON;
	}
	else
	{
		LCD->timerHourHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
		LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
	}
	
	
	if (G_ServerObj==0x00)
	{
		temp_8bit = G_StyleTempe;
		temp_8bit = temp_8bit - 70;
		if (temp_8bit & BIT7)
		{
			temp_8bit ^= 0xff;
			temp_8bit++;
			//temp_8bit = temp_8bit>>1; 
			LCD->timerHourHigh.displayValue = SHOW_DEC;
		}
		else
		{
			LCD->timerHourHigh.displayValue = SHOW_0;
		}
		temp_8bit = temp_8bit>>1; 
		LCD->timerHourLow.displayValue = temp_8bit/100%10;
		LCD->timerMinHigh.displayValue = temp_8bit/10%10;
		LCD->timerMinLow.displayValue = temp_8bit%10;
	}
	else
	{
		if (G_ServerRecFeedBack == 0)
		{
			LCD->timerHourHigh.displayValue = SHOW_DEC;
			LCD->timerHourLow.displayValue = SHOW_DEC;
			LCD->timerMinHigh.displayValue = SHOW_DEC;
			LCD->timerMinLow.displayValue = SHOW_DEC;
		}
		else
		{
			temp_16bit = G_ServerCode;
			if (temp_16bit&0x8000)
			{
				temp_16bit ^= 0xffff;
				temp_16bit += 1;
				LCD->timerHourHigh.displayValue = SHOW_DEC;
			}
			else
			{
				LCD->timerHourHigh.displayValue = SHOW_0;
			}
			LCD->timerHourLow.displayValue = (uint8_t)(temp_16bit/100%10);
			LCD->timerMinHigh.displayValue = (uint8_t)(temp_16bit/10%10);
			LCD->timerMinLow.displayValue = (uint8_t)(temp_16bit%10);
		}
	}

	// ϵͳ���   
	LCD->machineNum.displayState = DISP_ON;
	LCD->systemNum.displayState = DISP_ON;
	LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube9.displayState = DISP_FLASH_1HZ;
	LCD->indoorNum.displayState = DISP_ON;
	LCD->nixieTube10.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube11.displayState = DISP_FLASH_1HZ;
	
	LCD->nixieTube8.displayValue = (G_SystemNumbel + 1) / 10;
	LCD->nixieTube9.displayValue = (G_SystemNumbel + 1) % 10;
	LCD->nixieTube10.displayValue = (G_IndoorNumbel + 1) / 10;
	LCD->nixieTube11.displayValue = (G_IndoorNumbel + 1) % 10;

	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    �Զ���ַ��ʾ    
*/
/********************************************************/
static void Gui_AutoAddrShow(void)
{
	uint16_t temp_16bit;
	uint8_t temp_8bit;
	if (G_AutoAddrSet == 0)
		return;

	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ  
	if (G_KeyReleaseType == KEY_TYPE_CONTINUE)
	{
		LCD->tempeHigh.displayState = DISP_ON;
		LCD->tempeLow.displayState = DISP_ON;
	}
	else
	{
		if (G_AutoAddrSet == AUTO_ADDR_SET_TYPE)
		{
			LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
			LCD->tempeLow.displayState = DISP_FLASH_1HZ;
		}
		else
		{
			LCD->tempeHigh.displayState = DISP_ON;
			LCD->tempeLow.displayState = DISP_ON;
		}
	}
	if (G_AutoAddrType == AUTO_ADDR_AA)
	{
		LCD->tempeHigh.displayValue = SHOW_A;
		LCD->tempeLow.displayValue = SHOW_A;
	}
	else
	{
		LCD->tempeHigh.displayValue = SHOW_A;
		LCD->tempeLow.displayValue = SHOW_1;
	}

	// ϵͳ���   
	LCD->systemNum.displayState = DISP_ON;
	if (G_KeyReleaseType == KEY_TYPE_CONTINUE)
	{
		LCD->nixieTube8.displayState = DISP_ON;
		LCD->nixieTube9.displayState = DISP_ON;
	}
	else
	{
		if (G_AutoAddrSet == AUTO_ADDR_SET_SYSTEM)
		{
			LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
			LCD->nixieTube9.displayState = DISP_FLASH_1HZ;	
		}
		else
		{
			LCD->nixieTube8.displayState = DISP_ON;
			LCD->nixieTube9.displayState = DISP_ON;
		}
	}

	LCD->nixieTube8.displayValue= (G_SystemType+1) / 10;
	LCD->nixieTube9.displayValue = (G_SystemType+1) % 10;


	// �쳣������ʾ           
	if ((G_ErrorCode != 0x00)	&& (G_ErrorCode != 0x49))					// ���쳣ʱ   
	{
		// �쳣������ʾ   
		LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
		LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
		Get_ErrorCodeValue(G_ErrorCode);
	}


	// �趨����ʾ  
	LCD->setting.displayState = DISP_FLASH_1HZ;

	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    �ֶ���ַ��ʾ   
*/
/********************************************************/
static void Gui_ManualAddrShow(void)
{
	uint16_t temp_16bit;
	uint8_t temp_8bit;
	if (G_ManualAddrSet == 0)
		return;
	if (G_ManualAddrSet == MANUAL_ADDR_EXIT)
		return;

	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ  
	LCD->tempeHigh.displayState = DISP_ON;
	LCD->tempeLow.displayState = DISP_ON;
	LCD->tempeHigh.displayValue = SHOW_A;
	LCD->tempeLow.displayValue = SHOW_C;

	// ϵͳ��źͻ�����   
	LCD->machineNum.displayState = DISP_ON;
	LCD->systemNum.displayState = DISP_ON;
	if (G_ManualAddrSet == MANUAL_ADDR_SET_SYSTEM)
	{
		LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
		LCD->nixieTube9.displayState = DISP_FLASH_1HZ;
	}
	else if (G_ManualAddrSet == MANUAL_ADDR_SET_INDOOR)
	{
		//LCD->machineNum.displayState = DISP_ON;
		LCD->indoorNum.displayState = DISP_ON;
		LCD->nixieTube8.displayState = DISP_ON;
		LCD->nixieTube9.displayState = DISP_ON;
		LCD->nixieTube10.displayState = DISP_FLASH_1HZ;
		LCD->nixieTube11.displayState = DISP_FLASH_1HZ;
	}
	else
	{
		//LCD->machineNum.displayState = DISP_ON;
		LCD->indoorNum.displayState = DISP_ON;
		LCD->nixieTube8.displayState = DISP_ON;
		LCD->nixieTube9.displayState = DISP_ON;
		LCD->nixieTube10.displayState = DISP_ON;
		LCD->nixieTube11.displayState = DISP_ON;
	}
	LCD->nixieTube8.displayValue = (G_ManualSystemNum+1) / 10;
	LCD->nixieTube9.displayValue = (G_ManualSystemNum+1) % 10;
	LCD->nixieTube10.displayValue = (G_LicIndoorNum[G_ManualIndoorNum]+1) / 10;
	LCD->nixieTube11.displayValue = (G_LicIndoorNum[G_ManualIndoorNum]+1) % 10;

	// ʱ��8����ʾ   
	if (G_ManualAddrSet != MANUAL_ADDR_SET_FINISH)
	{
		LCD->timerHourHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
		LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
	}
	else
	{
		LCD->timerHourHigh.displayState = DISP_ON;
		LCD->timerHourLow.displayState = DISP_ON;
		LCD->timerMinHigh.displayState = DISP_ON;
		LCD->timerMinLow.displayState = DISP_ON;
	}
	if (G_ManualAddrGetFlag == 0)
	{
		LCD->timerHourHigh.displayValue = SHOW_DEC;
		LCD->timerHourLow.displayValue = SHOW_DEC;
		LCD->timerMinHigh.displayValue = SHOW_DEC;
		LCD->timerMinLow.displayValue = SHOW_DEC;
	}
	else
	{
		LCD->timerHourHigh.displayValue = SHOW_0;
		LCD->timerHourLow.displayValue = SHOW_0;
		LCD->timerMinHigh.displayValue = (G_ManualAddr+1) / 10;
		LCD->timerMinLow.displayValue = (G_ManualAddr+1) % 10;
	}

	// �趨����ʾ  
	LCD->setting.displayState = DISP_FLASH_1HZ;

	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    �������ʾ    
*/
/********************************************************/
static void Gui_OutdoorNormalShow(void)
{

	uint8_t flsh_temp;

	// ��Ŀ����  
	// �¶�88 ��ʾ  
	LCD->tempeHigh.displayState = DISP_ON;
	LCD->tempeLow.displayState = DISP_ON;
	LCD->tempeHigh.displayValue = G_OutdoorIndex >> 4;
	LCD->tempeLow.displayValue = G_OutdoorIndex & 0x0F;
	// ʱ��88 ��ʾ  
	if (!(G_PointFlag & (BIT0+BIT1)))
	{
		M_LED_SEG4_PORT_SET(G_OutdoorErrorCodeSeg[3]);
		M_LED_SEG5_PORT_SET(G_OutdoorErrorCodeSeg[2]);
		M_LED_SEG6_PORT_SET(G_OutdoorErrorCodeSeg[1]);
		M_LED_SEG7_PORT_SET(G_OutdoorErrorCodeSeg[0]);

		if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
		{
			M_LED_SEG4_PORT_SET(G_OutdoorErrorCodeSeg[7]);
			M_LED_SEG5_PORT_SET(G_OutdoorErrorCodeSeg[6]);
			M_LED_SEG6_PORT_SET(G_OutdoorErrorCodeSeg[5]);
			M_LED_SEG7_PORT_SET(G_OutdoorErrorCodeSeg[4]);
		}
	}


	if (G_OutdoorShowFlag & SYSTEM_MODE_SHOW)
	{
		// ģʽ��ʾ      
		LCD->runMode.displayState = DISP_ON;
		LCD->runMode.displayValue = G_SystemMode;
		
		// �趨��    
		if (G_SettingFlag)
		{
			LCD->setting.displayState = DISP_ON;
		}
	}

	// ϵͳ���    
	LCD->systemNum.displayState = DISP_ON;
	LCD->nixieTube8.displayState = DISP_ON;
	LCD->nixieTube9.displayState = DISP_ON;
	LCD->nixieTube8.displayValue = (G_SystemNumbel + 1) / 10;
	LCD->nixieTube9.displayValue = (G_SystemNumbel + 1) % 10;
	LCD->nixieTube10.displayState = DISP_ON;
	LCD->nixieTube11.displayState = DISP_ON;
	LCD->nixieTube10.displayValue = SHOW_0;
	LCD->nixieTube11.displayValue = SHOW_1;
	

	Get_LCD_Buf();

}

/********************************************************/
/**
** @brief    �쳣�����ѯ��ʾ    
*/
/********************************************************/
static void Gui_OutdoorErrorIndexShow(void)
{
	if (G_ErrorCheck == 0)
		return;
	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ  
	LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
	LCD->tempeLow.displayState = DISP_FLASH_1HZ;
	LCD->tempeHigh.displayValue = (G_ErrorObj+1) / 10;
	LCD->tempeLow.displayValue = (G_ErrorObj+1) % 10;
	
	// ʱ��8888����ʾ    
	LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
	LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
	LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
	Get_ErrorCodeValue(G_ErrorIndex);


	// ϵͳ���   
	LCD->machineNum.displayState = DISP_ON;			// ������           
	LCD->systemNum.displayState = DISP_ON;			// ϵͳ     
	LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube9.displayState = DISP_FLASH_1HZ;
	//LCD->indoorNum.displayState = DISP_ON;			// ����     
	LCD->nixieTube10.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube11.displayState = DISP_FLASH_1HZ;
	if (G_ErrorIndex != 0)
	{
		LCD->nixieTube8.displayValue = (G_SystemNumbel + 1) / 10;
		LCD->nixieTube9.displayValue = (G_SystemNumbel + 1) % 10;
		LCD->nixieTube10.displayValue = SHOW_0;		
		LCD->nixieTube11.displayValue = SHOW_1;			// �����ֻ��ʾ 01
	}
	else
	{
		LCD->nixieTube8.displayValue = SHOW_DEC;
		LCD->nixieTube9.displayValue = SHOW_DEC;
		LCD->nixieTube10.displayValue = SHOW_DEC;
		LCD->nixieTube11.displayValue = SHOW_DEC;
	}
	
	Get_LCD_Buf();
}

/********************************************************/
/**
** @brief    �������ģʽ��ʾ    
*/
/********************************************************/
static void Gui_OutdoorServerIndexShow(void)
{
	uint16_t temp_16bit;
	uint8_t temp_8bit;
	if (G_ServerCheck == 0)
		return;

	// ��Ŀͼ����ʾ   
	LCD->project.displayState = DISP_ON;
	
	// �¶�88��ʾ  
	if (G_KeyReleaseType == KEY_TYPE_CONTINUE)
	{
		LCD->tempeHigh.displayState = DISP_ON;
		LCD->tempeLow.displayState = DISP_ON;
	}
	else
	{
		LCD->tempeHigh.displayState = DISP_FLASH_1HZ;
		LCD->tempeLow.displayState = DISP_FLASH_1HZ;
	}
	LCD->tempeHigh.displayValue = G_ServerObj>>4;
	LCD->tempeLow.displayValue = G_ServerObj&0x0f;

	
	// ʱ��8888����ʾ    
	if (G_KeyReleaseType == KEY_TYPE_CONTINUE)
	{
		LCD->timerHourHigh.displayState = DISP_ON;
		LCD->timerHourLow.displayState = DISP_ON;
		LCD->timerMinHigh.displayState = DISP_ON;
		LCD->timerMinLow.displayState = DISP_ON;
	}
	else
	{
		LCD->timerHourHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
		LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
		LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
	}
	
	
	if (G_ServerObj==0x00)
	{
		temp_8bit = G_StyleTempe;
		temp_8bit = temp_8bit - 70;
		if (temp_8bit & BIT7)
		{
			temp_8bit ^= 0xff;
			temp_8bit++;
			//temp_8bit = temp_8bit>>1; 
			LCD->timerHourHigh.displayValue = SHOW_DEC;
		}
		else
		{
			LCD->timerHourHigh.displayValue = SHOW_0;
		}
		temp_8bit = temp_8bit>>1; 
		LCD->timerHourLow.displayValue = temp_8bit/100%10;
		LCD->timerMinHigh.displayValue = temp_8bit/10%10;
		LCD->timerMinLow.displayValue = temp_8bit%10;
	}
	else
	{
		if (G_ServerRecFeedBack == 0)
		{
			LCD->timerHourHigh.displayValue = SHOW_DEC;
			LCD->timerHourLow.displayValue = SHOW_DEC;
			LCD->timerMinHigh.displayValue = SHOW_DEC;
			LCD->timerMinLow.displayValue = SHOW_DEC;
		}
		else
		{
			temp_16bit = G_ServerCode;
			if (temp_16bit&0x8000)
			{
				temp_16bit ^= 0xffff;
				temp_16bit += 1;
				LCD->timerHourHigh.displayValue = SHOW_DEC;
			}
			else
			{
				LCD->timerHourHigh.displayValue = SHOW_0;
			}
			LCD->timerHourLow.displayValue = (uint8_t)(temp_16bit/100%10);
			LCD->timerMinHigh.displayValue = (uint8_t)(temp_16bit/10%10);
			LCD->timerMinLow.displayValue = (uint8_t)(temp_16bit%10);
		}
	}

	// ϵͳ���   
	LCD->machineNum.displayState = DISP_ON;
	LCD->systemNum.displayState = DISP_ON;
	LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube9.displayState = DISP_FLASH_1HZ;
	LCD->indoorNum.displayState = DISP_ON;
	LCD->nixieTube10.displayState = DISP_FLASH_1HZ;
	LCD->nixieTube11.displayState = DISP_FLASH_1HZ;
	
	LCD->nixieTube8.displayValue = (G_SystemNumbel + 1) / 10;
	LCD->nixieTube9.displayValue = (G_SystemNumbel + 1) % 10;
	LCD->nixieTube10.displayValue = (G_IndoorNumbel + 1) / 10;
	LCD->nixieTube11.displayValue = (G_IndoorNumbel + 1) % 10;

	Get_LCD_Buf();
}

/**************************************************************/
/**
* @brief	��Lcd�������Ĵ�����
*/
/**************************************************************/
static void LCD_SegLoad(void)
{
	
	SEG39 = Lcd_Buf[0];
	SEG40 = Lcd_Buf[1];
	SEG41 = Lcd_Buf[2];
	SEG45 = Lcd_Buf[3];
	SEG46 = Lcd_Buf[4];
	SEG47 = Lcd_Buf[5];
	SEG48 = Lcd_Buf[6];
	SEG49 = Lcd_Buf[7];
	SEG50 = Lcd_Buf[8];
	SEG0 = Lcd_Buf[9];
	SEG1 = Lcd_Buf[10];
	SEG2 = Lcd_Buf[11];
	SEG3 = Lcd_Buf[12];
	SEG4 = Lcd_Buf[13];
	SEG5 = Lcd_Buf[14];
	SEG6 = Lcd_Buf[34];
	SEG7 = Lcd_Buf[33];
	SEG8 = Lcd_Buf[32];
	SEG9 = Lcd_Buf[31];
	SEG10 = Lcd_Buf[30];
	SEG11 = Lcd_Buf[29];
	SEG12 = Lcd_Buf[28];
	SEG13 = Lcd_Buf[27];
	SEG14 = Lcd_Buf[26];
	SEG15 = Lcd_Buf[25];
	SEG16 = Lcd_Buf[24];
	SEG17 = Lcd_Buf[23];
	SEG18 = Lcd_Buf[22];
	SEG19 = Lcd_Buf[21];
	SEG20 = Lcd_Buf[20];
	SEG21 = Lcd_Buf[19];
	SEG22 = Lcd_Buf[18];
	SEG23 = Lcd_Buf[17];
	SEG24 = Lcd_Buf[16];
	SEG25 = Lcd_Buf[15];
	
}

/**************************************************************/
/**
* @brief	LCD��˸����   
* @note		�ú���1ms����һ��    	
*/
/**************************************************************/
void Lcd_FlashCount(void)
{
	static uint8_t count_100ms_temp = 0;
	static uint8_t count_500ms_temp = 0;

	count_100ms_temp++;
	count_500ms_temp++;
	count_100ms_temp %= 10;
	count_500ms_temp %= 50;
	
	if (count_100ms_temp == 0)
	{
		G_LcdFlag ^= LCD_FLAG_5HZ_SHOW;
	}
	if (count_500ms_temp == 0)
	{
		G_LcdFlag ^= LCD_FLAG_1HZ_SHOW;
	}
}

/**************************************************************/
/**
* @brief ���LCD��ʾ״̬   
*/
/**************************************************************/
void Clear_LCD_State(void)
{
	uint8_t i;
	uint8_t *p;
	p = (uint8_t *)LCD;
	for (i=0;i<62;i++)
	{
		*p = 0;
		p++;
	}
}
/**************************************************************/
/**
* @brief ��ȡLCD��ʾ״̬   
*/
/**************************************************************/
void Get_LCD_State(void)
{
	Get_FanSpeed_State();				// ������ʾ״̬��ȡ   
	Get_RunMode_State();				// ��ת״̬��ȡ   
	Get_WindDir_State();				// ������ʾ״̬��ȡ   
	Get_Tempe_State();					// �¶���ʾ״̬��ȡ   
	Get_Ir_State();					// ���ⷢ��ͼ�꣬û�����ͼ��    
	Get_Timer_State();					// ��ʱʱ��λ��8����ʾ״̬    
	Get_MachineNumbel_State();		// ��������ʾ״̬��ȡ    
	Get_FunctionArea_State();			// ��������6����ʾ״̬��ȡ    

	
}

/**************************************************************/
/**
* @brief ��ȡ��תģʽ��ʾ״̬��ʾ״̬   
*/
/**************************************************************/
void Get_RunMode_State(void)
{
	if (G_SystemStatus == SYSTEM_STATUS_OFF)		// ����״̬����ʾ    
		return;

	if ((G_SettingMode==SETTING_MODE_RUN_MODE)&&(G_SystemSet))	// ��תģʽѡ��   
	{
		LCD->runMode.displayState = DISP_FLASH_1HZ;
		LCD->runMode.displayValue = G_SystemModeSet;
	}
	else														
	{
		LCD->runMode.displayState = DISP_ON;
		LCD->runMode.displayValue = G_SystemMode;
	}
}

/**************************************************************/
/**
* @brief ��ȡ������ʾ״̬   
*/
/**************************************************************/
void Get_FanSpeed_State(void)
{
	if (G_SystemStatus == SYSTEM_STATUS_OFF)				//����״̬����ʾ   
		return;

	LCD->windSpeed.displayState = DISP_ON;
	if (G_SpecWindSpeed == WIND_SPEED_SPEC_NORMAL)
		LCD->windSpeed.displayValue = G_WindSpeed[G_SystemMode];
	else if (G_SpecWindSpeed == WIND_SPEED_SPEC_MUTE)
	{
		LCD->windSpeed.displayValue = 6;		// ��������ʾ   
	}
	else if (G_SpecWindSpeed == WIND_SPEED_SPEC_STRONG)
	{
		LCD->windSpeed.displayValue = 7;		// ����ǿ��ʾ   
	}
}

/**************************************************************/
/**
* @brief ��ȡ������ʾ״̬   
*/
/**************************************************************/
void Get_WindDir_State(void)
{
	if (G_SystemStatus == SYSTEM_STATUS_OFF)			// ����״̬����ʾ   
		return;

	// ���ҷ�����ʾ   
	if (G_LrWindDirGroup != LR_WIND_DIR_GROUP_NO)		  
	{
		if ((G_SettingMode == SETTING_MODE_LR_WIND)&&(G_SystemSet))
		{
			LCD->lrIcon.displayState = DISP_FLASH_1HZ;
			LCD->lrWindDir.displayState = DISP_ON;
			if (G_WindDirLr[G_SystemMode]==WIND_DIR_LR_AUTO)
				LCD->lrWindDir.displayValue = WIND_DIR_LR_SET_AUTO;
			else
				LCD->lrWindDir.displayValue = G_WindDirLr[G_SystemMode];
		}
		else
		{
			LCD->lrIcon.displayState = DISP_ON;
			LCD->lrWindDir.displayState = DISP_ON;
			LCD->lrWindDir.displayValue = G_WindDirLr[G_SystemMode];
		}
	}

	// ���·�����ʾ  
	if (G_UdWindDirGroup[G_SystemMode]  != UD_WIND_DIR_GROUP_NO)
	{
		if ((G_SettingMode == SETTING_MODE_UD_WIND)&&(G_SystemSet))
		{
			LCD->udIcon.displayState = DISP_FLASH_1HZ;
			LCD->udWindDir.displayState = DISP_ON;
			if (G_WindDirUd[G_SystemMode] == WIND_DIR_UD_AUTO)
				LCD->udWindDir.displayValue = WIND_DIR_UD_SET_AUTO;
			else
				LCD->udWindDir.displayValue = G_WindDirUd[G_SystemMode];
		}
		else
		{
			LCD->udIcon.displayState = DISP_ON;
			LCD->udWindDir.displayState = DISP_ON;
			LCD->udWindDir.displayValue = G_WindDirUd[G_SystemMode];
		}
	}
}

/**************************************************************/
/**
* @brief ��ȡ���ⷢ����ʾ״̬    
*/
/**************************************************************/
void Get_Ir_State(void)
{
	if (G_SystemStatus == SYSTEM_STATUS_OFF)
		return;
}
/**************************************************************/
/**
* @brief ��ȡ��ʱ��ʾ״̬    
*/
/**************************************************************/
void Get_Timer_State(void)
{	
	uint8_t temp;
	
	if (G_SystemStatus == SYSTEM_STATUS_OFF)
	{
		Show_TimerNormal();
	}
	else
	{
		// ����ģʽ�˵��Ĺ�������    
		if ((G_SystemSet)&&(G_SettingMode==SETTING_MODE_FUNCTION))
		{
			// ��ʱ����    
			if (G_FunctionType==FUNCTION_TIMER)
			{
				switch (G_TimerSet)
				{
					case TIMER_SET_NO_SET:
						Show_TimerNormal();
						break;
					case TIMER_SET_TYPE_CHOOSE:
						LCD->timerHourLow.displayState = DISP_ON;
						LCD->timerMinHigh.displayState = DISP_ON;
						LCD->timerMinLow.displayState = DISP_ON;
						LCD->point.displayState = DISP_ON;
						LCD->afterHour.displayState = DISP_ON;
						
						LCD->timerHourLow.displayValue = SHOW_DEC;
						LCD->timerMinHigh.displayValue = SHOW_DEC;
						LCD->timerMinLow.displayValue = SHOW_DEC;
						
						if (G_TimerTypeSet==TIMER_TYPE_ONCE_OFF)
						{
							LCD->timerOff0.displayState = DISP_FLASH_1HZ;
						}
						else if (G_TimerTypeSet==TIMER_TYPE_CYCLE_OFF)
						{
							LCD->cycle.displayState = DISP_FLASH_1HZ;
							LCD->timerOff1.displayState = DISP_FLASH_1HZ;
						}
						else if (G_TimerTypeSet==TIMER_TYPE_ONCE_ON)
						{
							LCD->timerOn.displayState = DISP_FLASH_1HZ;
						}
						break;
					case TIMER_SET_TIME_SET:
						if (G_KeyReleaseType==KEY_TYPE_CONTINUE)
						{
							LCD->timerHourLow.displayState = DISP_ON;
							LCD->timerMinHigh.displayState = DISP_ON;
							LCD->timerMinLow.displayState = DISP_ON;
						}
						else
						{
							LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
							LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
							LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
						}
						LCD->point.displayState = DISP_ON;
						LCD->afterHour.displayState = DISP_ON;
						
						if (G_TimerTypeSet==TIMER_TYPE_ONCE_OFF)
						{
							LCD->timerOff0.displayState = DISP_ON;
						}
						else if (G_TimerTypeSet==TIMER_TYPE_CYCLE_OFF)
						{
							LCD->cycle.displayState = DISP_ON;
							LCD->timerOff1.displayState = DISP_ON;
						}
						else if (G_TimerTypeSet==TIMER_TYPE_ONCE_ON)
						{
							LCD->timerOn.displayState = DISP_ON;
						}
						
						if (G_TimerHourSet/100)
							LCD->timerHourLow.displayValue = (uint8_t)(G_TimerHourSet/100);
						else
							LCD->timerHourLow.displayState = DISP_OFF;
						LCD->timerMinHigh.displayValue = (uint8_t)(G_TimerHourSet%100/10);
						LCD->timerMinLow.displayValue = (uint8_t)(G_TimerHourSet%10);
						break;
				}
			}
			// �Ƕ�ʱ����    
			else
			{
				Show_TimerNormal();
			}
		}
		else
		{
			Show_TimerNormal();
		}
	}
}

/**************************************************************/
/**
* @brief ������ʾ    
*/
/**************************************************************/
void Get_MachineNumbel_State(void)
{
	if (G_SystemStatus == SYSTEM_STATUS_ON)			// ����״̬   
	{
		if (G_ErrorCode!=0x00)						// �쳣ʱ��ʾ������    
		{
			if (G_ErrorCode != 0x49)					// E09����ʾ������     
			{
				LCD->check.displayState = DISP_FLASH_1HZ;		
				LCD->machineNum.displayState = DISP_FLASH_1HZ;
				
				LCD->systemNum.displayState = DISP_FLASH_1HZ;
				LCD->nixieTube8.displayState = DISP_FLASH_1HZ;
				LCD->nixieTube9.displayState = DISP_FLASH_1HZ;
				LCD->nixieTube8.displayValue = (G_ErrorSystemNum+1) / 10;
				LCD->nixieTube9.displayValue = (G_ErrorSystemNum+1) % 10;

				LCD->indoorNum.displayState = DISP_FLASH_1HZ;
				LCD->nixieTube10.displayState = DISP_FLASH_1HZ;
				LCD->nixieTube11.displayState = DISP_FLASH_1HZ;
				LCD->nixieTube10.displayValue = (G_ErrorIndoorNum+1) / 10;
				LCD->nixieTube11.displayValue = (G_ErrorIndoorNum+1) % 10;
			}
		}
	}	
	
}

/**************************************************************/
/**
* @brief	�������������ʾ      
*/
/**************************************************************/
void Get_FunctionArea_State(void)
{	


	// ����ת   
	if (G_TryRun)
		LCD->tryRun.displayState = DISP_ON;	

	// ��Ԫ��ֹ-Զ��ͼ����ʾ           
	if (G_CentralCtrBanFlag)
	{
		if (G_CtlBanSwAction == CTL_BAN_SW_ACT)
		{
			LCD->remote.displayState = DISP_FLASH_1HZ;
		}
		else
		{
			LCD->remote.displayState = DISP_ON;
		}
	}

	if (G_SystemStatus == SYSTEM_STATUS_ON)
	{

		// Ԥ��   
		if (G_Preheat)
			LCD->preheat.displayState = DISP_ON;
		
		// ��˪    
		if (G_Defrost)
			LCD->defrost.displayState = DISP_ON;

		// ����6��ʾ   
		if ((G_SystemSet==1)&&(G_SettingMode==SETTING_MODE_FUNCTION))
		{
			if (G_FunctionType==FUNCTION_NANOE)
				LCD->nanoe.displayState = DISP_FLASH_1HZ;
			else
			{
				Get_Nanoe_State();
			}

			
			if (G_FunctionType==FUNCTION_ECONAVI)
				LCD->econavi.displayState = DISP_FLASH_1HZ;
			else
			{
				if ((G_EconaviStatus&&G_EconaviFunc))
					LCD->econavi.displayState = DISP_ON;
			}

			if (G_FunctionType==FUNCTION_SAVE_POWER)
				LCD->saveEnergy.displayState = DISP_FLASH_1HZ;
			else
			{
				if (G_SaveEnergy&&G_SaveEnergyFunc)
					LCD->saveEnergy.displayState = DISP_ON;
			}

			if (G_FunctionType==FUNCTION_FRESH_AIR)
				LCD->freshAir.displayState = DISP_FLASH_1HZ;
			else
			{
				if (G_FreshAir&&G_FreshAirFunc)
					LCD->freshAir.displayState = DISP_ON;
			}

			if (G_FunctionType==FUNCTION_TIMER)
			{
				if (G_TimerSet == TIMER_SET_NO_SET)
					LCD->timer.displayState = DISP_FLASH_1HZ;
				else
					LCD->timer.displayState = DISP_ON;
			}
			else
			{
				if (G_TimerType)
					LCD->timer.displayState = DISP_ON;
			}


			if (G_FunctionType == FUNCTION_WIFI)
				LCD->wifi.displayState = DISP_FLASH_1HZ;
			else
			{
				if (G_WifiState==1)
					LCD->wifi.displayState = DISP_ON;
			}

			if (G_FunctionType==FUNCTION_CONNECT_NET)
			{
				LCD->connectNet.displayState = DISP_FLASH_1HZ;
			}
			else
			{
				if (G_WifiState)
				{
					if (G_WifiNetShowCount > 0)
						LCD->connectNet.displayState = DISP_ON;	
					if (G_WifiOTA == 2)
					{
						LCD->wifiSignal.displayState = DISP_FLASH_5HZ;
						LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
					}
					else
					{
						if (G_WifiConnctNetError == 0)
						{
							if (G_NetStatus != 4)
							{
								switch (G_WifiConnectNet)
								{
									case 1:
										LCD->wifiSignal.displayState = DISP_FLASH_5HZ;
										LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
										break;
									case 2:
										if (G_NetStatus == 3)
										{
											LCD->wifiSignal.displayState = DISP_ON;
											LCD->wifiSignal.displayValue = G_WifiSign; 
										}
										else
										{
											LCD->wifiSignal.displayState = DISP_FLASH_5HZ;
											LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
										}
										break;
									case 3:
										LCD->wifiSignal.displayState = DISP_FLASH_1HZ;
										LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
										break;
								}
							}
							else
							{
								LCD->wifiSignal.displayState = DISP_FLASH_1HZ;
								LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
							}
						}
					}
				}
			}

			if (G_FunctionType==FUNCTION_RESET)
			{
				LCD->wifiReset.displayState = DISP_FLASH_1HZ;
			}

			if (G_FunctionType==FUNCTION_FILTER_RESET)
				LCD->filterReset.displayState = DISP_FLASH_1HZ;
			else
			{
				if (G_FilterRstSign)
					LCD->filterReset.displayState = DISP_FLASH_1HZ;
			}

			if (G_FunctionType==FUNCTION_TRY_RUN)
				LCD->tryRun.displayState = DISP_FLASH_1HZ;
		}
		else
		{
			// nanoe ״̬   
			Get_Nanoe_State();
			// econavi״̬   
			if (G_EconaviStatus&&G_EconaviFunc)
				LCD->econavi.displayState = DISP_ON;
			// ����    
			if (G_SaveEnergy&&G_SaveEnergyFunc)
				LCD->saveEnergy.displayState = DISP_ON;
			// ����   
			if (G_FreshAir&&G_FreshAirFunc)
				LCD->freshAir.displayState = DISP_ON;
			// ��ʱͼ��    
			if (G_TimerType)
				LCD->timer.displayState = DISP_ON;
			// wifiͼ��   
			if (G_WifiState==1)
				LCD->wifi.displayState = DISP_ON;
			// ����������ʾ    
			if (G_WifiState)
			{
				if (G_WifiNetShowCount > 0)
					LCD->connectNet.displayState = DISP_ON;	
				if (G_WifiOTA == 2)
				{
					LCD->wifiSignal.displayState = DISP_FLASH_5HZ;
					LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
				}
				else
				{
					if (G_WifiConnctNetError == 0)
					{
						if (G_NetStatus != 4)
						{
							switch (G_WifiConnectNet)
							{
								case 1:
									LCD->wifiSignal.displayState = DISP_FLASH_5HZ;
									LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
									break;
								case 2:
									if (G_NetStatus == 3)
									{
										LCD->wifiSignal.displayState = DISP_ON;
										LCD->wifiSignal.displayValue = G_WifiSign; 
									}
									else
									{
										LCD->wifiSignal.displayState = DISP_FLASH_5HZ;
										LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
									}
									break;
								case 3:
									LCD->wifiSignal.displayState = DISP_FLASH_1HZ;
									LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
									break;
							}
						}
						else
						{
							LCD->wifiSignal.displayState = DISP_FLASH_1HZ;
							LCD->wifiSignal.displayValue = WIFI_SIGNAL_LEVEL3; 
						}
					}
				}
			}

			if (G_WifiResetShowCnt > 0)
				LCD->wifiReset.displayState = DISP_ON;
			
			// ��������λ�ź�   
			if (G_FilterRstSign)
				LCD->filterReset.displayState = DISP_FLASH_1HZ;
		}
	}

	// �ྻ��      
	if (G_Cleanning)
	{
		LCD->clean.displayState = DISP_ON;	
		Get_Nanoe_State();
	}
	
}
/**************************************************************/
/**
* @brief	nanoeͼ�����ʾ   
*/
/**************************************************************/
void Get_Nanoe_State(void)
{
	// nanoe״̬   
	if (G_NanoeFunc)				// ��������   
	{	
		if (G_NanoeStatus||G_Cleanning)		// nanoe��  ��  �ྻ�п�ʱ��Ҫ��ʾnanoe    
		{
			if (G_NanoeGAb)
			{
				// nanoe״̬   
				if ((G_NanoeAb==1)&&(G_NanoeAbCnt>=NANOE_ERROR_2MIN))
				{
					if (flash_2500ms_off_2500ms_on)
						LCD->nanoe.displayState = DISP_ON;
					else
						LCD->nanoe.displayState = DISP_OFF;
				}
				else
				{
					if (flash_500ms_off_500ms_on)
						LCD->nanoe.displayState = DISP_ON;
					else
						LCD->nanoe.displayState = DISP_OFF;
				}
			}
			else
			{
				// nanoe״̬   
				if ((G_NanoeAb==1)&&(G_NanoeAbCnt>=NANOE_ERROR_2MIN))
				{
					if (flash_500ms_off_2500ms_on)
						LCD->nanoe.displayState = DISP_ON;
					else
						LCD->nanoe.displayState = DISP_OFF;
				}
				else
				{
					LCD->nanoe.displayState = DISP_ON;
				}
			}
		}
	}
}

/**************************************************************/
/**
* @brief ��ȡ�¶ȵ�״̬        
*/
/**************************************************************/
void Get_Tempe_State(void)
{
	uint8_t temp;

	if (G_SystemStatus == SYSTEM_STATUS_OFF)			// ����״̬����ʾ   
		return;

	if (G_TryRun)										// ����תʱ����ʾ�¶�    
		return;
	
	if (G_SystemMode != SYSTEM_MODE_WIND)				// �ͷ�ģʽ����ʾ�¶�   
	{
		LCD->tempeHigh.displayState = DISP_ON;
		LCD->tempeLow.displayState = DISP_ON;
		LCD->tempeUnit.displayState = DISP_ON;
		LCD->tempeHigh.displayValue = G_SystemTemp[G_SystemMode] / 10;
		LCD->tempeLow.displayValue = G_SystemTemp[G_SystemMode] % 10;
	}

}


/**************************************************************/
/**
* @brief ��ȡLCD��ʾ����        
*/
/**************************************************************/
void Get_LCD_Buf(void)
{
	
	// �����1  
	switch (LCD->tempeHigh.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG1_SHOW_ONEDIGIT(LCD->tempeHigh.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG1_SHOW_ONEDIGIT(LCD->tempeHigh.displayValue);
			break;
	}
	// �����2  
	switch (LCD->tempeLow.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG2_SHOW_ONEDIGIT(LCD->tempeLow.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG2_SHOW_ONEDIGIT(LCD->tempeLow.displayValue);
			break;
	}
	// �����4  
	switch (LCD->timerHourHigh.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG4_SHOW_ONEDIGIT(LCD->timerHourHigh.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG4_SHOW_ONEDIGIT(LCD->timerHourHigh.displayValue);
			break;
	}
	// �����5  
	switch (LCD->timerHourLow.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG5_SHOW_ONEDIGIT(LCD->timerHourLow.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG5_SHOW_ONEDIGIT(LCD->timerHourLow.displayValue);
			break;
	}
	// �����6  
	switch (LCD->timerMinHigh.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG6_SHOW_ONEDIGIT(LCD->timerMinHigh.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG6_SHOW_ONEDIGIT(LCD->timerMinHigh.displayValue);
			break;
	}
	// �����7  
	switch (LCD->timerMinLow.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG7_SHOW_ONEDIGIT(LCD->timerMinLow.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG7_SHOW_ONEDIGIT(LCD->timerMinLow.displayValue);
			break;
	}
	// �����8  
	switch (LCD->nixieTube8.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG8_SHOW_ONEDIGIT(LCD->nixieTube8.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG8_SHOW_ONEDIGIT(LCD->nixieTube8.displayValue);
			break;
	}
	// �����9  
	switch (LCD->nixieTube9.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG9_SHOW_ONEDIGIT(LCD->nixieTube9.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG9_SHOW_ONEDIGIT(LCD->nixieTube9.displayValue);
			break;
	}
	// �����10  
	switch (LCD->nixieTube10.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG10_SHOW_ONEDIGIT(LCD->nixieTube10.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG10_SHOW_ONEDIGIT(LCD->nixieTube10.displayValue);
			break;
	}
	// �����11  
	switch (LCD->nixieTube11.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SEG11_SHOW_ONEDIGIT(LCD->nixieTube11.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SEG11_SHOW_ONEDIGIT(LCD->nixieTube11.displayValue);
			break;
	}
	// ��תģʽ    
	switch (LCD->runMode.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			Show_RunMode(LCD->runMode.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				Show_RunMode(LCD->runMode.displayValue);
			break;
	}
	// ����    
	switch (LCD->windSpeed.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			Show_WindSpeed(LCD->windSpeed.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				Show_WindSpeed(LCD->windSpeed.displayValue);
			break;
	}
	// ���ҷ���         
	switch (LCD->lrWindDir.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			Show_LrWindDir(LCD->lrWindDir.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				Show_LrWindDir(LCD->lrWindDir.displayValue);
			break;
	}
	// ����ICON
	switch (LCD->lrIcon.displayState)
	{
		case DISP_ON:
			SHOW_WIND_DIR_LR_ICON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_WIND_DIR_LR_ICON;
			break;
	}
	
	// ���·���      
	switch (LCD->udWindDir.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			Show_UdWindDir(LCD->udWindDir.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				Show_UdWindDir(LCD->udWindDir.displayValue);
			break;
	}
	// ����ICON
	switch (LCD->udIcon.displayState)
	{
		case DISP_ON:
			SHOW_WIND_DIR_UD_ICON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_WIND_DIR_UD_ICON;
			break;
	}
	
	// WIFIǿ��       
	switch (LCD->wifiSignal.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			Show_WifiSignal(LCD->wifiSignal.displayValue);
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				Show_WifiSignal(LCD->wifiSignal.displayValue);
			break;
		case DISP_FLASH_5HZ:
			if (G_LcdFlag & LCD_FLAG_5HZ_SHOW)
				Show_WifiSignal(LCD->wifiSignal.displayValue);
			break;
	}
	// �¶ȵ�λ      
	switch (LCD->tempeUnit.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_TEMPE_UNIT;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_TEMPE_UNIT;
			break;
	}
	// Զ��  
	switch (LCD->remote.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_REMOTE;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_REMOTE;
			break;
	}
	// ��Ŀ    
	switch (LCD->project.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_PROJECT;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_PROJECT;
			break;
	}
	
	// Ԥ��  
	switch (LCD->preheat.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_PREHEAT;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_PREHEAT;
			break;
	}
	// ��˪   
	switch (LCD->defrost.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_DEFROST;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_DEFROST;
			break;
	}
	// �趨��  
	switch (LCD->setting.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_SETTING;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_SETTING;
			break;
	}
	// Сʱ��  
	switch (LCD->afterHour.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_HOUR_AFTER;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_HOUR_AFTER;
			break;
	}
	// ��0 
	switch (LCD->timerOff0.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_TIMER_OFF_0;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_TIMER_OFF_0;
			break;
	}
	// cycle  
	switch (LCD->cycle.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_CYCLE;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_CYCLE;
			break;
	}
	// ��1  
	switch (LCD->timerOff1.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_TIMER_OFF_1;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_TIMER_OFF_1;
			break;
	}
	// ��   
	switch (LCD->timerOn.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_TIMER_ON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_TIMER_ON;
			break;
	}
	// �޴˹���   
	switch (LCD->noFunc.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_NO_FUNC;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_NO_FUNC;
			break;
	}
	// nanoe   
	switch (LCD->nanoe.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_NANOE;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_NANOE;
			break;
	}
	// econavi  
	switch (LCD->econavi.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_ECONAVI;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_ECONAVI;
			break;
	}
	// ����   
	switch (LCD->saveEnergy.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_SAVE_ENERGY;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_SAVE_ENERGY;
			break;
	}	
	// ����   
	switch (LCD->freshAir.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_FRESH_AIR;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_FRESH_AIR;
			break;
	}	
	// ��ʱ  
	switch (LCD->timer.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_TIMER;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_TIMER;
			break;
	}
	// wifi 
	switch (LCD->wifi.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_WIFI_ICON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_WIFI_ICON;
			break;
	}	
	// ����  
	switch (LCD->connectNet.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_WIFI_CONNECT_NET;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_WIFI_CONNECT_NET;
			break;
	}	
	// ��λ   
	switch (LCD->wifiReset.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_WIFI_RESET;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_WIFI_RESET;
			break;
	}
	// ���  
	switch (LCD->check.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_CHECK;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_CHECK;
			break;
	}

	// ����ѡ��   
	switch (LCD->machineModel.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_MACHINE_CHOOSE;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_MACHINE_CHOOSE;
			break;
	}

	// ������      
	switch (LCD->machineNum.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_MACHINEMODEL_ICON;
			SHOW_NUMBER_ICON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
			{
				SHOW_MACHINEMODEL_ICON;
				SHOW_NUMBER_ICON;
			}
			break;
	}

	// ϵͳ   
	switch (LCD->systemNum.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_SYSTEM_ICON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
			{
				SHOW_SYSTEM_ICON;
			}
			break;
	}

	// ����      
	switch (LCD->indoorNum.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_INDOOR_ICON;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
			{
				SHOW_INDOOR_ICON;
			}
			break;
	}

	
	// ������λ   
	switch (LCD->filterReset.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_FILTER_RESET;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_FILTER_RESET;
			break;
	}
	// ����ת  
	switch (LCD->tryRun.displayState)
	{
		case DISP_OFF:
			break;
		case DISP_ON:
			SHOW_TRY_RUN;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_TRY_RUN;
			break;
	}

	switch (LCD->col.displayState)
	{
		case DISP_ON:
			SHOW_COL;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_COL;
			break;
	}

	switch (LCD->point.displayState)
	{
		case DISP_ON:
			SHOW_POINT;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_POINT;
			break;
	}
	// �ྻ��     
	switch (LCD->clean.displayState)
	{
		case DISP_ON:
			SHOW_CLEAN;
			break;
		case DISP_FLASH_1HZ:
			if (G_LcdFlag & LCD_FLAG_1HZ_SHOW)
				SHOW_CLEAN;
			break;
	}
	
	
	// �̶�����ʾ   
	SHOW_FIT_BOX;
}

/********************************************************/
/**
** @brief    ���趨ģʽ�Ķ�ʱ��ʾ   
*/
/********************************************************/
void Show_TimerNormal(void)
{
	if (G_ErrorCode != 0x00)						// ���쳣ʱ   
	{
		if (G_SystemStatus == SYSTEM_STATUS_ON)	// ����ʱ    
		{
			// �쳣������ʾ   
			LCD->timerHourLow.displayState = DISP_FLASH_1HZ;
			LCD->timerMinHigh.displayState = DISP_FLASH_1HZ;
			LCD->timerMinLow.displayState = DISP_FLASH_1HZ;
			Get_ErrorCodeValue(G_ErrorCode);
		}
	}
	else	// û���쳣ʱ   		
	{
		if (G_TimerType == TIMER_TYPE_NO_SET)		// ����ʱ���趨ʱ�˳�     
			return;
		
		if ((G_TimerType==TIMER_TYPE_ONCE_OFF)||(G_TimerType==TIMER_TYPE_CYCLE_OFF))
		{
			// ��ʱ���趨��ѭ����ʱ���趨   
			if (G_SystemStatus == SYSTEM_STATUS_ON)		// ����״̬
			{
				LCD->timerHourLow.displayState = DISP_ON;
				LCD->timerMinHigh.displayState = DISP_ON;
				LCD->timerMinLow.displayState = DISP_ON;
				LCD->point.displayState = DISP_ON;
				LCD->afterHour.displayState = DISP_ON;
				
				if (G_TimerType==TIMER_TYPE_CYCLE_OFF)		
				{
					LCD->cycle.displayState = DISP_ON;
					LCD->timerOff1.displayState = DISP_ON;
				}
				else
					LCD->timerOff0.displayState = DISP_ON;
			}
		}
		else if(G_TimerType==TIMER_TYPE_ONCE_ON)		// ��ʱ���趨   
		{
			if (G_SystemStatus == SYSTEM_STATUS_OFF)	// ����״̬   
			{
				LCD->timerHourLow.displayState = DISP_ON;
				LCD->timerMinHigh.displayState = DISP_ON;
				LCD->timerMinLow.displayState = DISP_ON;
				LCD->point.displayState = DISP_ON;
				LCD->afterHour.displayState = DISP_ON;
				LCD->timerOn.displayState = DISP_ON;
			}
		}

		if (G_TimerRemainHour/100)
			LCD->timerHourLow.displayValue = (uint8_t)(G_TimerRemainHour/100);
		else
			LCD->timerHourLow.displayState = DISP_OFF;
		LCD->timerMinHigh.displayValue = (uint8_t)(G_TimerRemainHour%100/10);
		LCD->timerMinLow.displayValue = (uint8_t)(G_TimerRemainHour%10);
	}
}


/**************************************************************/
/**
* @brief 	�쳣�������        
*/
/**************************************************************/
void Get_ErrorCodeValue(uint8_t dat)
{
	if (dat == 0)
	{
		LCD->timerHourHigh.displayValue = SHOW_DEC;
		LCD->timerHourLow.displayValue = SHOW_DEC;
		LCD->timerMinHigh.displayValue = SHOW_DEC;
		LCD->timerMinLow.displayValue = SHOW_DEC;
	}
	else if ((dat>0x00)&&(dat<0x20))
	{
		LCD->timerHourLow.displayValue = SHOW_A;
		LCD->timerMinHigh.displayValue = dat / 10;
		LCD->timerMinLow.displayValue = dat % 10;
	}
	else if ((dat>=0x20)&&(dat<0x40))
	{
		LCD->timerHourLow.displayValue = SHOW_C;
		LCD->timerMinHigh.displayValue = (dat - 0x20) / 10;
		LCD->timerMinLow.displayValue = (dat - 0x20) % 10;
	}
	else if ((dat>=0x40)&&(dat<0x60))
	{
		LCD->timerHourLow.displayValue = SHOW_E;
		LCD->timerMinHigh.displayValue = (dat - 0x40) / 10;
		LCD->timerMinLow.displayValue = (dat - 0x40) % 10;
	}
	else if ((dat>=0x60)&&(dat<0x80))
	{
		LCD->timerHourLow.displayValue = SHOW_F;
		LCD->timerMinHigh.displayValue = (dat - 0x60) / 10;
		LCD->timerMinLow.displayValue = (dat - 0x60) % 10;
	}
	else if ((dat>=0x80)&&(dat<0xA0))
	{
		LCD->timerHourLow.displayValue = SHOW_H;
		LCD->timerMinHigh.displayValue = (dat - 0x80) / 10;
		LCD->timerMinLow.displayValue = (dat - 0x80) % 10;
	}
	else if ((dat>=0xA0)&&(dat<0xC0))
	{
		LCD->timerHourLow.displayValue = SHOW_J;
		LCD->timerMinHigh.displayValue = (dat - 0xA0) / 10;
		LCD->timerMinLow.displayValue = (dat - 0xA0) % 10;
	}
	else if ((dat>=0xC0)&&(dat<0xE0))
	{
		LCD->timerHourLow.displayValue = SHOW_L;
		LCD->timerMinHigh.displayValue = (dat - 0xC0) / 10;
		LCD->timerMinLow.displayValue = (dat - 0xC0) % 10;
	}
	else if ((dat>=0xE0)&&(dat<=0xFF))
	{
		LCD->timerHourLow.displayValue = SHOW_P;
		LCD->timerMinHigh.displayValue = (dat - 0xE0) / 10;
		LCD->timerMinLow.displayValue = (dat - 0xE0) % 10;
	}
}

/********************************************************/
/**
** @brief    ��תģʽ��ʾ   
*/
/********************************************************/
void Show_RunMode(uint8_t run_mode_dat)
{
	switch (run_mode_dat)
	{
		case SYSTEM_MODE_AUTO:
			SHOW_RUN_MODE_AUTO;
			break;
		case SYSTEM_MODE_WARM:
			SHOW_RUN_MODE_WARM;
			break;
		case SYSTEM_MODE_COLD:
			SHOW_RUN_MODE_COLD;
			break;
		case SYSTEM_MODE_WET:
			SHOW_RUN_MODE_WET;
			break;
		case SYSTEM_MODE_WIND:
			SHOW_RUN_MODE_WIND;
			break;
	}
}

/********************************************************/
/**
** @brief    ������ʾ   
*/
/********************************************************/
void Show_WindSpeed(uint8_t wind_speed_dat)
{
	switch (wind_speed_dat)
	{
		case WIND_SPEED_AUTO:
			SHOW_WIND_SPEED_AUTO;
			break;
		case WIND_SPEED_LEVEL1:
			SHOW_WIND_SPEED_LEVEL1;
			break;
		case WIND_SPEED_LEVEL2:
			SHOW_WIND_SPEED_LEVEL2;
			break;
		case WIND_SPEED_LEVEL3:
			SHOW_WIND_SPEED_LEVEL3;
			break;
		case WIND_SPEED_LEVEL4:
			SHOW_WIND_SPEED_LEVEL4;
			break;
		case WIND_SPEED_LEVEL5:
			SHOW_WIND_SPEED_LEVEL5;
			break;
		case 6:
			SHOW_WIND_SPEED_MUTE;
			break;
		case 7:
			SHOW_WIND_SPEED_STRONG;
			break;
	}
}

/********************************************************/
/**
** @brief    ���ҷ�����ʾ    
*/
/********************************************************/
void Show_LrWindDir(uint8_t lr_wind_dir_dat)
{
	switch (lr_wind_dir_dat)
	{
		case WIND_DIR_LR_AUTO:
			Show_WindDirLrAuto();
			break;
		case WIND_DIR_LR_AUTO_STOP:
			SHOW_WIND_DIR_LR_AUTO_ATOP;
			break;
		case WIND_DIR_LR_LEVEL1:
			SHOW_WIND_DIR_LR_LEVEL1;
			break;
		case WIND_DIR_LR_LEVEL2:
			SHOW_WIND_DIR_LR_LEVEL2;
			break;
		case WIND_DIR_LR_LEVEL3:
			SHOW_WIND_DIR_LR_LEVEL3;
			break;
		case WIND_DIR_LR_LEVEL4:
			SHOW_WIND_DIR_LR_LEVEL4;
			break;
		case WIND_DIR_LR_LEVEL5:
			SHOW_WIND_DIR_LR_LEVEL5;
			break;
		case WIND_DIR_LR_SET_AUTO:
			SHOW_WIND_DIR_LR_SET_AUTO;
			break;
	}
}

/********************************************************/
/**
** @brief   ���ҷ����Զ��ڶ�   
*/
/********************************************************/
void Show_WindDirLrAuto(void)
{
	SHOW_WIND_DIR_LR_AUTO;
	switch (G_WindDirLrSwing)
	{
		case 0:
			SHOW_WIND_DIR_LR_LEVEL1;
			break;
		case 1:
			SHOW_WIND_DIR_LR_LEVEL2;
			break;
		case 2:
			SHOW_WIND_DIR_LR_LEVEL3;
			break;
		case 3:
			SHOW_WIND_DIR_LR_LEVEL4;
			break;
		case 4:
			SHOW_WIND_DIR_LR_LEVEL5;
			break;
			
	}
}

/********************************************************/
/**
** @brief    ���·�����ʾ   
*/
/********************************************************/
void Show_UdWindDir(uint8_t ud_wind_dir_dat)
{
	switch (ud_wind_dir_dat)
	{
		case WIND_DIR_UD_AUTO:
			Show_WindDirUdAuto();
			break;
		case WIND_DIR_UD_AUTO_STOP:
			SHOW_WIND_DIR_UD_AUTO_STOP;
			break;
		case WIND_DIR_UD_LEVEL1:
			SHOW_WIND_DIR_UD_LEVEL1;
			break;
		case WIND_DIR_UD_LEVEL2:
			SHOW_WIND_DIR_UD_LEVEL2;
			break;
		case WIND_DIR_UD_LEVEL3:
			SHOW_WIND_DIR_UD_LEVEL3;
			break;
		case WIND_DIR_UD_LEVEL4:
			SHOW_WIND_DIR_UD_LEVEL4;
			break;
		case WIND_DIR_UD_LEVEL5:
			SHOW_WIND_DIR_UD_LEVEL5;
			break;
		case WIND_DIR_UD_SET_AUTO:
			SHOW_WIND_DIR_UD_SET_AUTO;
			break;
	}
}

/********************************************************/
/**
** @brief   ���·����Զ��ڶ�  
*/
/********************************************************/
void Show_WindDirUdAuto(void)
{
	SHOW_WIND_DIR_UD_AUTO;
	switch (G_WindDirUdSwing)
	{
		case 0:
			SHOW_WIND_DIR_UD_LEVEL1;
			break;
		case 1:
			SHOW_WIND_DIR_UD_LEVEL2;
			break;
		case 2:
			SHOW_WIND_DIR_UD_LEVEL3;
			break;
		case 3:
			SHOW_WIND_DIR_UD_LEVEL4;
			break;
		case 4:
			SHOW_WIND_DIR_UD_LEVEL5
			break;
	}
}

/********************************************************/
/**
** @brief    wifi��ʾ  
*/
/********************************************************/
void Show_WifiSignal(uint8_t wifi_signal_dat)
{
	switch (wifi_signal_dat)
	{
		case WIFI_SIGNAL_LEVEL0:
			SHOW_WIFI_SINGAL_LEVEL0;
			break;
		case WIFI_SIGNAL_LEVEL1:
			SHOW_WIFI_SINGAL_LEVEL1;
			break;
		case WIFI_SIGNAL_LEVEL2:
			SHOW_WIFI_SINGAL_LEVEL2;
			break;
		case WIFI_SIGNAL_LEVEL3:
			SHOW_WIFI_SINGAL_LEVEL3;
			break;
	}
}

/********************************************************/
/**
** @brief    ����ģʽ��ʾ   
*/
/********************************************************/
static void Gui_Test(void)
{
	uint8_t i;
	if (G_TestMode==0)			// ���ǲ���ģʽ�˳�   
		return;
	
	switch (G_TestStage)
	{
		case TEST_STAGE_LCD:
			if (G_TestLength==0)
			{
				
			}
			else if (G_TestLength == 1)
			{
				for(i = 0; i < LCD_BUF_LEN; i++)
    				Lcd_Buf[i] = BIT0;		/* ��ʾCOM0 */
			}
			else if (G_TestLength == 2)
			{
				for(i = 0; i < LCD_BUF_LEN; i++)
    				Lcd_Buf[i] = BIT1;		/* ��ʾCOM1 */
			}
			else if (G_TestLength == 3)
			{
				for(i = 0; i < LCD_BUF_LEN; i++)
    				Lcd_Buf[i] = BIT2;		/* ��ʾCOM2 */
			}
			else if (G_TestLength == 4)
			{
				for(i = 0; i < LCD_BUF_LEN; i++)
    				Lcd_Buf[i] = BIT3;		/* ��ʾCOM3 */
			}
			else if (G_TestLength == 5)
			{
				for(i = 0; i < LCD_BUF_LEN; i++)
    				Lcd_Buf[i] = 0x0f;	/*  ȫ��  */
			}
			else if (G_TestLength == 6)
			{
				for(i = 0; i < LCD_BUF_LEN; i++)
    				Lcd_Buf[i] = 0x00;	/*  ����ʾ  */
			}
			break;
		case TEST_STAGE_SW:
			if (G_EepromTestErr)
			{
				SHOW_FILTER_RESET;
			}
			if (G_WifiTestErr)
			{
				SHOW_WIFI_SINGAL_LEVEL3;
			}
			if (G_VrfComTestErr)
			{
				SHOW_REMOTE;
			}

			// ����������ʾ    
			SEG1_SHOW_ONEDIGIT(G_KeyTestCount/10);
			SEG2_SHOW_ONEDIGIT(G_KeyTestCount%10);

			// �汾����ʾ   
			SEG4_SHOW_ONEDIGIT(SHOW_G);
			SEG5_SHOW_ONEDIGIT(SOFTWARE_VERSION / 100);
			SEG6_SHOW_ONEDIGIT(SOFTWARE_VERSION % 100 / 10);
			SEG7_SHOW_ONEDIGIT(SOFTWARE_VERSION %10);
			break;
	}
}




/**************************************************************/
/**
* @brief	��LCD������seg��com bit����
*/
/**************************************************************/
void LCD_ComSet(uint8_t com)
{
	uint8_t i;
	for(i=0; i<LCD_BUF_LEN; i++)
		Lcd_Buf[i] = com;
}

/**************************************************************/
/**
* @brief	LCDseg����ʾ   
*/
/**************************************************************/
void LCD_SegSet(uint8_t seg)
{
	uint8_t i;
	if (seg%2)
	{
		for(i=0; i<LCD_BUF_LEN; i+=2)
			Lcd_Buf[i] = BIT0+BIT2;
	}
	else
	{
		for(i=1; i<LCD_BUF_LEN; i+=2)
			Lcd_Buf[i] = BIT1+BIT3;
	}
}

/********************************************************/
/**
** @brief    �����1��ʾ  
*/
/********************************************************/
void SEG1_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG1_SHOW_0;
			break;
		case 1:
			SEG1_SHOW_1;
			break;
		case 2:
			SEG1_SHOW_2;
			break;
		case 3:
			SEG1_SHOW_3;
			break;
		case 4:
			SEG1_SHOW_4;
			break;
		case 5:
			SEG1_SHOW_5;
			break;
		case 6:
			SEG1_SHOW_6;
			break;
		case 7:
			SEG1_SHOW_7;
			break;
		case 8:
			SEG1_SHOW_8;
			break;
		case 9:
			SEG1_SHOW_9;
			break;
		case 10:
			SEG1_SHOW_A;
			break;
		case 11:
			SEG1_SHOW_B;
			break;
		case 12:
			SEG1_SHOW_C;
			break;
		case 13:
			SEG1_SHOW_D;
			break;
		case 14:
			SEG1_SHOW_E;
			break;
		case 15:
			SEG1_SHOW_F;
			break;
		case 16:
			SEG1_SHOW_G;
			break;
		case 17:
			SEG1_SHOW_DEC;
			break;
		case 18:
			SEG1_SHOW_ADD;
			break;
	}
}

/********************************************************/
/**
** @brief    �����2��ʾ  
*/
/********************************************************/
void SEG2_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG2_SHOW_0;
			break;
		case 1:
			SEG2_SHOW_1;
			break;
		case 2:
			SEG2_SHOW_2;
			break;
		case 3:
			SEG2_SHOW_3;
			break;
		case 4:
			SEG2_SHOW_4;
			break;
		case 5:
			SEG2_SHOW_5;
			break;
		case 6:
			SEG2_SHOW_6;
			break;
		case 7:
			SEG2_SHOW_7;
			break;
		case 8:
			SEG2_SHOW_8;
			break;
		case 9:
			SEG2_SHOW_9;
			break;
		case 10:
			SEG2_SHOW_A;
			break;
		case 11:
			SEG2_SHOW_B;
			break;
		case 12:
			SEG2_SHOW_C;
			break;
		case 13:
			SEG2_SHOW_D;
			break;
		case 14:
			SEG2_SHOW_E;
			break;
		case 15:
			SEG2_SHOW_F;
			break;
		case 16:
			SEG2_SHOW_G;
			break;
		case 17:
			SEG2_SHOW_DEC;
			break;
	}
}

/********************************************************/
/**
** @brief    �����3��ʾ  
*/
/********************************************************/
void SEG4_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG4_SHOW_0;
			break;
		case 1 :
			SEG4_SHOW_1;
			break;
		case 2:
			SEG4_SHOW_2;
			break;
		case 3:
			SEG4_SHOW_3;
			break;
		case 4:
			SEG4_SHOW_4;
			break;
		case 5:
			SEG4_SHOW_5;
			break;
		case 6:
			SEG4_SHOW_6;
			break;
		case 7:
			SEG4_SHOW_7;
			break;
		case 8:
			SEG4_SHOW_8;
			break;
		case 9:
			SEG4_SHOW_9;
			break;
		case 10:
			SEG4_SHOW_A;
			break;
		case 11:
			SEG4_SHOW_B;
			break;
		case 12:
			SEG4_SHOW_C;
			break;
		case 13:
			SEG4_SHOW_D;
			break;
		case 14:
			SEG4_SHOW_E;
			break;
		case 15:
			SEG4_SHOW_F;
			break;
		case 16:
			SEG4_SHOW_G;
			break;
		case 17:
			SEG4_SHOW_DEC;
			break;
		case SHOW_H:
			SEG4_SHOW_H;
			break;
		case SHOW_J:
			SEG4_SHOW_J;
			break;
		case SHOW_L:
			SEG4_SHOW_L;
			break;
		case SHOW_P:
			SEG4_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����5��ʾ  
*/
/********************************************************/
void SEG5_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG5_SHOW_0;
			break;
		case 1 :
			SEG5_SHOW_1;
			break;
		case 2:
			SEG5_SHOW_2;
			break;
		case 3:
			SEG5_SHOW_3;
			break;
		case 4:
			SEG5_SHOW_4;
			break;
		case 5:
			SEG5_SHOW_5;
			break;
		case 6:
			SEG5_SHOW_6;
			break;
		case 7:
			SEG5_SHOW_7;
			break;
		case 8:
			SEG5_SHOW_8;
			break;
		case 9:
			SEG5_SHOW_9;
			break;
		case 10:
			SEG5_SHOW_A;
			break;
		case 11:
			SEG5_SHOW_B;
			break;
		case 12:
			SEG5_SHOW_C;
			break;
		case 13:
			SEG5_SHOW_D;
			break;
		case 14:
			SEG5_SHOW_E;
			break;
		case 15:
			SEG5_SHOW_F;
			break;
		case 16:
			SEG5_SHOW_G;
			break;
		case 17:
			SEG5_SHOW_DEC;
			break;
		case SHOW_H:
			SEG5_SHOW_H;
			break;
		case SHOW_J:
			SEG5_SHOW_J;
			break;
		case SHOW_L:
			SEG5_SHOW_L;
			break;
		case SHOW_P:
			SEG5_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����6��ʾ  
*/
/********************************************************/
void SEG6_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG6_SHOW_0;
			break;
		case 1 :
			SEG6_SHOW_1;
			break;
		case 2:
			SEG6_SHOW_2;
			break;
		case 3:
			SEG6_SHOW_3;
			break;
		case 4:
			SEG6_SHOW_4;
			break;
		case 5:
			SEG6_SHOW_5;
			break;
		case 6:
			SEG6_SHOW_6;
			break;
		case 7:
			SEG6_SHOW_7;
			break;
		case 8:
			SEG6_SHOW_8;
			break;
		case 9:
			SEG6_SHOW_9;
			break;
		case 10:
			SEG6_SHOW_A;
			break;
		case 11:
			SEG6_SHOW_B;
			break;
		case 12:
			SEG6_SHOW_C;
			break;
		case 13:
			SEG6_SHOW_D;
			break;
		case 14:
			SEG6_SHOW_E;
			break;
		case 15:
			SEG6_SHOW_F;
			break;
		case 16:
			SEG6_SHOW_G;
			break;
		case 17:
			SEG6_SHOW_DEC;
			break;
		case SHOW_H:
			SEG6_SHOW_H;
			break;
		case SHOW_J:
			SEG6_SHOW_J;
			break;
		case SHOW_L:
			SEG6_SHOW_L;
			break;
		case SHOW_P:
			SEG6_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����7��ʾ  
*/
/********************************************************/
void SEG7_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG7_SHOW_0;
			break;
		case 1 :
			SEG7_SHOW_1;
			break;
		case 2:
			SEG7_SHOW_2;
			break;
		case 3:
			SEG7_SHOW_3;
			break;
		case 4:
			SEG7_SHOW_4;
			break;
		case 5:
			SEG7_SHOW_5;
			break;
		case 6:
			SEG7_SHOW_6;
			break;
		case 7:
			SEG7_SHOW_7;
			break;
		case 8:
			SEG7_SHOW_8;
			break;
		case 9:
			SEG7_SHOW_9;
			break;
		case 10:
			SEG7_SHOW_A;
			break;
		case 11:
			SEG7_SHOW_B;
			break;
		case 12:
			SEG7_SHOW_C;
			break;
		case 13:
			SEG7_SHOW_D;
			break;
		case 14:
			SEG7_SHOW_E;
			break;
		case 15:
			SEG7_SHOW_F;
			break;
		case 16:
			SEG7_SHOW_G;
			break;
		case 17:
			SEG7_SHOW_DEC;
			break;
		case SHOW_H:
			SEG7_SHOW_H;
			break;
		case SHOW_J:
			SEG7_SHOW_J;
			break;
		case SHOW_L:
			SEG7_SHOW_L;
			break;
		case SHOW_P:
			SEG7_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����8��ʾ  
*/
/********************************************************/
void SEG8_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG8_SHOW_0;
			break;
		case 1 :
			SEG8_SHOW_1;
			break;
		case 2:
			SEG8_SHOW_2;
			break;
		case 3:
			SEG8_SHOW_3;
			break;
		case 4:
			SEG8_SHOW_4;
			break;
		case 5:
			SEG8_SHOW_5;
			break;
		case 6:
			SEG8_SHOW_6;
			break;
		case 7:
			SEG8_SHOW_7;
			break;
		case 8:
			SEG8_SHOW_8;
			break;
		case 9:
			SEG8_SHOW_9;
			break;
		case 10:
			SEG8_SHOW_A;
			break;
		case 11:
			SEG8_SHOW_B;
			break;
		case 12:
			SEG8_SHOW_C;
			break;
		case 13:
			SEG8_SHOW_D;
			break;
		case 14:
			SEG8_SHOW_E;
			break;
		case 15:
			SEG8_SHOW_F;
			break;
		case 16:
			SEG8_SHOW_G;
			break;
		case 17:
			SEG8_SHOW_DEC;
			break;
		case SHOW_H:
			SEG8_SHOW_H;
			break;
		case SHOW_J:
			SEG8_SHOW_J;
			break;
		case SHOW_L:
			SEG8_SHOW_L;
			break;
		case SHOW_P:
			SEG8_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����9��ʾ  
*/
/********************************************************/
void SEG9_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG9_SHOW_0;
			break;
		case 1 :
			SEG9_SHOW_1;
			break;
		case 2:
			SEG9_SHOW_2;
			break;
		case 3:
			SEG9_SHOW_3;
			break;
		case 4:
			SEG9_SHOW_4;
			break;
		case 5:
			SEG9_SHOW_5;
			break;
		case 6:
			SEG9_SHOW_6;
			break;
		case 7:
			SEG9_SHOW_7;
			break;
		case 8:
			SEG9_SHOW_8;
			break;
		case 9:
			SEG9_SHOW_9;
			break;
		case 10:
			SEG9_SHOW_A;
			break;
		case 11:
			SEG9_SHOW_B;
			break;
		case 12:
			SEG9_SHOW_C;
			break;
		case 13:
			SEG9_SHOW_D;
			break;
		case 14:
			SEG9_SHOW_E;
			break;
		case 15:
			SEG9_SHOW_F;
			break;
		case 16:
			SEG9_SHOW_G;
			break;
		case 17:
			SEG9_SHOW_DEC;
			break;
		case SHOW_H:
			SEG9_SHOW_H;
			break;
		case SHOW_J:
			SEG9_SHOW_J;
			break;
		case SHOW_L:
			SEG9_SHOW_L;
			break;
		case SHOW_P:
			SEG9_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����10��ʾ  
*/
/********************************************************/
void SEG10_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG10_SHOW_0;
			break;
		case 1 :
			SEG10_SHOW_1;
			break;
		case 2:
			SEG10_SHOW_2;
			break;
		case 3:
			SEG10_SHOW_3;
			break;
		case 4:
			SEG10_SHOW_4;
			break;
		case 5:
			SEG10_SHOW_5;
			break;
		case 6:
			SEG10_SHOW_6;
			break;
		case 7:
			SEG10_SHOW_7;
			break;
		case 8:
			SEG10_SHOW_8;
			break;
		case 9:
			SEG10_SHOW_9;
			break;
		case 10:
			SEG10_SHOW_A;
			break;
		case 11:
			SEG10_SHOW_B;
			break;
		case 12:
			SEG10_SHOW_C;
			break;
		case 13:
			SEG10_SHOW_D;
			break;
		case 14:
			SEG10_SHOW_E;
			break;
		case 15:
			SEG10_SHOW_F;
			break;
		case 16:
			SEG10_SHOW_G;
			break;
		case 17:
			SEG10_SHOW_DEC;
			break;
		case SHOW_H:
			SEG10_SHOW_H;
			break;
		case SHOW_J:
			SEG10_SHOW_J;
			break;
		case SHOW_L:
			SEG10_SHOW_L;
			break;
		case SHOW_P:
			SEG10_SHOW_P;
			break;
	}
}

/********************************************************/
/**
** @brief    �����11��ʾ  
*/
/********************************************************/
void SEG11_SHOW_ONEDIGIT(uint8_t digit)
{
	switch (digit)
	{
		case 0:
			SEG11_SHOW_0;
			break;
		case 1 :
			SEG11_SHOW_1;
			break;
		case 2:
			SEG11_SHOW_2;
			break;
		case 3:
			SEG11_SHOW_3;
			break;
		case 4:
			SEG11_SHOW_4;
			break;
		case 5:
			SEG11_SHOW_5;
			break;
		case 6:
			SEG11_SHOW_6;
			break;
		case 7:
			SEG11_SHOW_7;
			break;
		case 8:
			SEG11_SHOW_8;
			break;
		case 9:
			SEG11_SHOW_9;
			break;
		case 10:
			SEG11_SHOW_A;
			break;
		case 11:
			SEG11_SHOW_B;
			break;
		case 12:
			SEG11_SHOW_C;
			break;
		case 13:
			SEG11_SHOW_D;
			break;
		case 14:
			SEG11_SHOW_E;
			break;
		case 15:
			SEG11_SHOW_F;
			break;
		case 16:
			SEG11_SHOW_G;
			break;
		case 17:
			SEG11_SHOW_DEC;
			break;
		case SHOW_H:
			SEG11_SHOW_H;
			break;
		case SHOW_J:
			SEG11_SHOW_J;
			break;
		case SHOW_L:
			SEG11_SHOW_L;
			break;
		case SHOW_P:
			SEG11_SHOW_P;
			break;
	}
}


