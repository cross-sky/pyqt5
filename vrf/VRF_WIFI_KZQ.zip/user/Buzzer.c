#define _EXTERN_BUZZER_H_

#include "Common.h"


/**************************************************************/ 
/**
* @brief	����������   
*/
/**************************************************************/
void Buzzer_Enable(uint8_t buzzer_type, uint16_t buzzer_len)
{
	R_PCLBUZ1_Stop();
	G_BuzzerType = buzzer_type;
	G_BuzzerCountTarget = buzzer_len;
	G_BuzzerCount = 0;
	G_BuzzerState = BUZZER_ON;
}

/**************************************************************/ 
/**
* @brief	������������    
*/
/**************************************************************/
void Buzzer_KeySoundEnable(void)
{
	if (G_BzMode == BZ_DISABLE)
		return;
	if (G_StandbySound == 1)
		return;
	Buzzer_Enable(1,100);
}

/**************************************************************/ 
/**
* @brief	�������ػ���     
*/
/**************************************************************/
void Buzzer_LongSoundEnable(void)
{
	if (G_BzMode == BZ_DISABLE)
		return;
	G_StandbySound = 1;
	Buzzer_Enable(1,250);
}

/**************************************************************/ 
/**
* @brief	����������     
*/
/**************************************************************/
void Buzzer_AlarmEnable(void)
{
	if (G_BzMode == BZ_DISABLE)
		return;
	G_StandbySound = 0;
	Buzzer_Enable(2,100);
}

/**************************************************************/ 
/**
* @brief	��������������
* @note		1ms����һ�Σ���Ҫ��1ms��ʱ���ڵ��ô˺���
*/
/**************************************************************/
void Buzzer_process(void)
{
	switch (G_BuzzerType)
	{
		case BUZZER_TYPE_STOP:
			Buzzer_Stop();
			break;
		case BUZZER_TYPE_1:
			Buzzer_Type1Deal();
			break;
		case BUZZER_TYPE_2:
			Buzzer_Type2Deal();
			break;
		case BUZZER_TYPE_3:
			break;
	}
	if (G_BuzzerType)
		G_BuzzerCount++;
}

/**************************************************************/ 
/**
* @brief	��������
*/
/**************************************************************/
void Buzzer_Start(void)
{
	if (G_BuzzerState == BUZZER_ON)
	{
		G_BuzzerState = BUZZER_OFF;
		R_PCLBUZ1_Start();
	}
}

/**************************************************************/ 
/**
* @brief	�������ر�
*/
/**************************************************************/
void Buzzer_Stop(void)
{
	R_PCLBUZ1_Stop();
	G_BuzzerCount = 0;
	G_BuzzerType = 0;
}

/**************************************************************/ 
/**
* @brief	��������һ��
*/
/**************************************************************/
void Buzzer_Type1Deal(void)
{
	Buzzer_Start();
	if (G_BuzzerCount >= G_BuzzerCountTarget)
	{
		Buzzer_Stop();
		if (G_StandbySound == 1)
			G_StandbySound = 0;
	}
}

/**************************************************************/ 
/**
* @brief	������,����
*/
/**************************************************************/
void Buzzer_Type2Deal(void)
{
	Buzzer_Start();
	if (G_BuzzerCount == 200)
	{
		R_PCLBUZ1_Stop();
	}
	else if (G_BuzzerCount == 250)
	{
		G_BuzzerState = BUZZER_ON;
	}
	else if (G_BuzzerCount == 600)
	{
		Buzzer_Stop();
	}
}


