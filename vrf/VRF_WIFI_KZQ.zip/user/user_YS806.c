#include "Common.h"

/*****************************************************/ 
/**
** @brief	EEPROM write a byte 
*/
/*****************************************************/
void YS806_Write_Byte(uint8_t devSel, uint8_t addr, uint8_t dat)
{
	I2C_806_Start();
	I2C_806_WriteByte(devSel);
	I2C_806_WriteByte(addr);
	I2C_806_WriteByte(dat);
	I2C_806_Stop();
	delay_ms(10);
}

/*****************************************************/ 
/**
** @brief	EEPROM read a byte 
*/
/*****************************************************/
void YS806_Read_Byte(uint8_t devSel, uint8_t addr, uint8_t *pdate)
{
	I2C_806_Start();
	I2C_806_WriteByte(devSel);
	I2C_806_WriteByte(addr);

	I2C_806_Start();
	I2C_806_WriteByte(devSel|0x01);
	*pdate = I2C_806_ReadByte(1);
	I2C_806_Stop();
	delay_ms(10);
}

/*****************************************************/ 
/**
** @brief	EEPROM write string
*/
/*****************************************************/
void YS806_Write_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate)
{
	I2C_806_Start();
	I2C_806_WriteByte(devSel);
	I2C_806_WriteByte(addr);
	if (len==0)
	{
		I2C_806_Stop();
	}
	else
	{
		while (len--)
		{
			I2C_806_WriteByte(*pdate);	
			pdate++;
		}
		I2C_806_Stop();
	}
	delay_ms(10);
}

/*****************************************************/ 
/**
** @brief	EEPROM read string
*/
/*****************************************************/
void YS806_Read_String(uint8_t devSel, uint8_t addr, uint8_t len, uint8_t *pdate)
{
	I2C_806_Start();
	I2C_806_WriteByte(devSel);
	I2C_806_WriteByte(addr);

	I2C_806_Start();
	I2C_806_WriteByte(devSel|0x01);
	if (len==0)
	{
		I2C_806_Stop();
	}
	else
	{
		for (;len>=2;len--)
		{
			*pdate = I2C_806_ReadByte(0);
			pdate++;
		}
		*pdate = I2C_806_ReadByte(1);
		I2C_806_Stop();
	}
	//delay_ms(10);
}

