#define _EXTERN_KEY_H_

#include "Common.h"



/********************************************************************************/
/* 
*	@brief  ���������ȼĴ���д��      
*	@detail 300s�ް�������д�롢���������ȸı�1s��д��  
*/
/********************************************************************************/
void Key_ConfWrite(void)
{
	const uint8_t table[4] = {8,18,28,38};
	uint8_t i;

	// 300s �ް������������³�ʼ������    
	G_TouchWriteCount++;
	if (G_TouchWriteCount >= 600) // 300s
	{
		G_TouchWriteCount = 0;
		G_TouchWriteFlag = 1;
	}
	

	#if 0
	// ���������ȸı��ҳ���1s�ް�������,���³�ʼ�������Ĵ���    
	if ((G_TouchLevelBack!=G_TouchLevel) && (G_TouchWriteCount>100))
	{
		G_TouchWriteFlag = 1;
		G_TouchLevelBack = G_TouchLevel;
	}
	#endif

	// ������ʼ��    
    if (G_TouchWriteFlag)
	{
		G_TouchWriteFlag = 0;

		if (G_TouchLevel > 3)
			G_TouchLevel = 0;

		G_KeyConf[0] = 0;
		G_KeyConf[1] = 0;
		G_KeyConf[2] = 0x08;
		G_KeyConf[3] = 0xf0;
		G_KeyConf[4] = 0x81;
		G_KeyConf[5] = 0xc4;		// BIT7:��̬У׼  BIT5:�ఴ��   
		G_KeyConf[6] = 0x00;
		G_KeyConf[7] = 0x00;

		G_KeyConf[8] = table[G_TouchLevel] + 2;		// cs1
		G_KeyConf[9] = table[G_TouchLevel];		// cs2
		G_KeyConf[10] = table[G_TouchLevel];		// cs3
		G_KeyConf[11] = table[G_TouchLevel];		// cs4
		G_KeyConf[12] = table[G_TouchLevel];		// cs5
		G_KeyConf[13] = table[G_TouchLevel];		// cs6
		G_KeyConf[14] = table[G_TouchLevel];
		G_KeyConf[15] = table[G_TouchLevel];
		G_KeyConf[16] = 0;
		for (i=0; i<16; i++)
		{
			G_KeyConf[16] += G_KeyConf[i];
		}
		YS806_Write_String(0xa0,0xD0,17,G_KeyConf);
		
	}
}


void Key_GetState(void)
{
	uint8_t temp_key_value[2];
	static uint8_t key_last_value = 0;
	static uint8_t key_now_value = 0; 

	/**************************start*************************/
	// ��ȡ����ֵ   

	YS806_Read_String(0xA0,0x08,2,temp_key_value);
	key_now_value = temp_key_value[0];
	/**************************stop*************************/

	/**************************start*************************/
	// ����״̬��ȡ       
	switch (G_Key.state)
	{
		case KEY_STATE_NONE:
			if (key_now_value)
			{
				key_last_value = key_now_value;
				G_Key.state = KEY_STATE_DOWM;
				G_Key.count = 0;
			}
			break;
		case KEY_STATE_DOWM:
			if (key_now_value == key_last_value)
			{
				G_Key.value = key_now_value;
				G_Key.count++;
				if (G_Key.count >= 1000)
					G_Key.count = 1000;
			}
			else
			{
				key_last_value = key_now_value;
				G_Key.flag = KEY_FLAG_RELEASE;
				G_Key.count = 0;
			}
			break;
	}
	/**************************stop*************************/
}

/**************************************************************/
/**
*	@brief	�ް���������а���״̬    
*/
/**************************************************************/
void Key_StatusClear(void)
{
	if ((G_Key.state==KEY_STATE_NONE)||(G_Key.flag&KEY_FLAG_RELEASE))
	{
		G_Key.flag = KEY_FLAG_NONE;
		G_Key.state= KEY_STATE_NONE;
		G_Key.value = KEY_VALUE_NONE;
		G_Key.count = 0;
	}
}

/**************************************************************/
/**
*	@brief		����ɨ��������          
*   @details	������ֵ��ȡ���������ܡ�����״̬���
*				3������   
*	@note		�˺���10ms����һ��   
*/
/**************************************************************/
void Key_DealProgram(void)
{
	static uint8_t count_10ms = 0;

	count_10ms++;
	if (count_10ms < 2)
		return;
	count_10ms = 0;
	
	// 20ms����һ��  
	Key_GetState();
	Key_AllFeatureDeal();
	Key_StatusClear();

	if (G_Key.state == KEY_STATE_NONE)
		G_KeyReleaseType = KEY_TYPE_NONE;
}


/**************************************************************/
/**
*	@brief		��������            
*/
/**************************************************************/
void Key_AllFeatureDeal(void)
{
	
	G_KeyDownType = KEY_TYPE_NONE;

	if (G_WdtReset == 1)
		return;
	if (G_TestMode == 1)
	{
		TestMode_KeyDeal();
	}
	else
	{
		switch (G_Key.value)
		{
			case KEY_VALUE_NONE:
				break;
			case KEY_VALUE_ON_OFF:
				if (G_Key.count == 5)
				{
					Key_PressType(KEY_TYPE_SHORT);
				}
				Key_OnOffDeal();
				break;
			case KEY_VALUE_FUNCTION:
				if (G_Key.count == 5)
				{
					Key_PressType(KEY_TYPE_SHORT);
				}

				Key_FunctionDeal();
				break;
			case KEY_VALUE_SET:
				if (G_Key.count == 5)
				{
					Key_PressType(KEY_TYPE_SHORT);
				}

				Key_SettingDeal();
				break;
			case KEY_VALUE_WINDSPEED:
				if (G_Key.count == 5)
				{
					Key_PressType(KEY_TYPE_SHORT);
				}

				Key_WindspeedDeal();
				break;
			case KEY_VALUE_UP:
				if (G_Key.count == 5)
				{
					Key_PressType(KEY_TYPE_SHORT);
				}

				// ��������   
				if (G_Key.count == 100)
				{
					if (G_ProSetting||G_ServerCheck)
						G_Key.count = 83;
					else
						G_Key.count = 90;
					Key_PressType(KEY_TYPE_CONTINUE);
				}

				Key_UpDeal();
				break;
			case KEY_VALUE_DOWN:
				if (G_Key.count == 5)
				{
					Key_PressType(KEY_TYPE_SHORT);
				}

				// ��������   
				if (G_Key.count == 100)
				{
					if (G_ProSetting||G_ServerCheck)
						G_Key.count = 83;
					else
						G_Key.count = 90;
					Key_PressType(KEY_TYPE_CONTINUE);
					
				}

				Key_DownDeal();
				break;
			case KEY_VALUE_PRO_DETAIL:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_DetailProSetDeal();
				break;;
			case KEY_VALUE_PRO_SIMPLE:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_SimpleProSetDeal();
				break;
			case KEY_VALUE_REMO_SET:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_RemoSetFunction();
				break;
			case KEY_VALUE_CHECK:
				if (G_Key.count == 150)
				{
					Key_PressType(KEY_TYPE_3S);
				}
				Key_Check();
				break;
			case KEY_VALUE_ERROR_INDEX:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_ErrorIndex();
				break;
			case KEY_VALUE_SERVER_SIM:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_ServerIndex();
				break;
			case KEY_VALUE_AUTO_ADDR:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_AutoAddr();
				break;
			case KEY_VALUE_MANUAL_ADDR:
				if (G_Key.count == 250)
				{
					Key_PressType(KEY_TYPE_5S);
				}
				Key_ManualAddr();
				break;
		}
	}

	// �а������µ�������   
	if (G_KeyDownType != KEY_TYPE_NONE)
	{
		G_TouchWriteCount = 0;		// �ް�������ʱ����0   
		BL_On();
	}

	// �����ͷ�ʱ��������־��������Ч�ģ��������� 
	if ((G_KeyReleaseType==KEY_TYPE_CONTINUE)&&(G_Key.flag & KEY_FLAG_RELEASE))
	{
		if (G_KeyReleaseBz == 1)
			Buzzer_KeySoundEnable();
		else
			G_KeyReleaseBz = 0;
	}
}

void Key_PressType(uint8_t key_type)
{
	G_KeyDownType = key_type;
	G_KeyReleaseType = key_type;
}

/*************************************/
/*
	@brief	���°���1s���޷�����81״̬�ı�ָ��   
*/
/*************************************/
void Key_PressCount(void)
{
	if (G_KeyCount > 0)
		G_KeyCount--;
}


