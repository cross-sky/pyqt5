#include "r_cg_macrodriver.h"

#ifndef _KEY_H
#define _KEY_H

#ifdef _EXTERN_KEY_H_
#define EXT_KEY
#else
#define EXT_KEY extern
#endif

typedef struct 
{    
    uint8_t state;           
	uint8_t value;      
    uint16_t count;   
	uint8_t flag;
	
}struct_key_type;

// ����״̬   
typedef enum
{
	KEY_STATE_NONE,
	KEY_STATE_DOWM,
}enum_key_state_type;

// ����ֵ    
typedef enum
{
	KEY_VALUE_NONE = 0,
	KEY_VALUE_ON_OFF = BIT5,
	KEY_VALUE_FUNCTION = BIT4,
	KEY_VALUE_SET = BIT1,
	KEY_VALUE_WINDSPEED = BIT2,
	KEY_VALUE_UP = BIT3,
	KEY_VALUE_DOWN = BIT0,
	KEY_VALUE_PRO_DETAIL = KEY_VALUE_FUNCTION+KEY_VALUE_WINDSPEED+KEY_VALUE_DOWN,			// ��Ŀ��ϸ�趨   
	KEY_VALUE_PRO_SIMPLE = KEY_VALUE_SET+KEY_VALUE_WINDSPEED,								// ��Ŀ���趨   
	KEY_VALUE_REMO_SET = KEY_VALUE_FUNCTION+KEY_VALUE_SET+KEY_VALUE_UP,						// ң�����趨   
	KEY_VALUE_CHECK = KEY_VALUE_FUNCTION+KEY_VALUE_UP+KEY_VALUE_DOWN,						// ���   
	KEY_VALUE_ERROR_INDEX = KEY_VALUE_FUNCTION+KEY_VALUE_WINDSPEED,						// �쳣����   
	KEY_VALUE_SERVER_SIM = KEY_VALUE_FUNCTION+KEY_VALUE_SET,									// ����ģʽ�趨  
	KEY_VALUE_AUTO_ADDR = KEY_VALUE_FUNCTION+KEY_VALUE_UP,									// �Զ���ַ�趨   
	KEY_VALUE_MANUAL_ADDR = KEY_VALUE_FUNCTION+KEY_VALUE_DOWN,							// �ֶ���ַ�趨    
	
}enum_key_value_type;

// ������־    
typedef enum
{
	KEY_FLAG_NONE,
	KEY_FLAG_RELEASE = BIT0,
};

enum
{
	KEY_TYPE_NONE,
	KEY_TYPE_SHORT,
	KEY_TYPE_2S,
	KEY_TYPE_3S,
	KEY_TYPE_4S,
	KEY_TYPE_5S,
	KEY_TYPE_6S,
	KEY_TYPE_7S,
	KEY_TYPE_8S,
	KEY_TYPE_9S,
	KEY_TYPE_10S,
	KEY_TYPE_CONTINUE,
};



#define		KEY_COUNT_5S     500
EXT_KEY uint16_t G_KeyCount;		


EXT_KEY struct_key_type G_Key;
EXT_KEY uint8_t G_KeyDownType;			// �����ͷŴ�����    
EXT_KEY uint8_t G_KeyReleaseType;		// �ͷŴ�������Ҫ�ô˱�־    
EXT_KEY uint8_t G_KeyReleaseBz;		// �����ͷŰ����� 
EXT_KEY uint8_t G_KeyConf[17];			// �Ĵ���д�뻺��   
EXT_KEY uint8_t G_TouchLevel;			// ����������ˮƽ    
EXT_KEY uint8_t G_TouchLevelBack;		// �ϴΰ�����������   
EXT_KEY uint8_t G_TouchWriteCount;
EXT_KEY uint8_t G_TouchWriteFlag;


void Key_ConfWrite(void);
void Key_GetState(void);
void Key_StatusClear(void);
void Key_DealProgram(void);
void Key_AllFeatureDeal(void);
void Key_PressType(uint8_t key_type);
void Key_PressCount(void);

#endif


